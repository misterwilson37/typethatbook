// learn.js v2.2.3
//
// Lesson-mode engine, separate from game.js. Same write-ahead-log and
// coalesced-flush persistence pattern.
//
// ── Full history: CHANGELOG.md § learn.js ─────────────────────────────────
// ── Why it looks like this: PEDAGOGY-AUDIT.md ─────────────────────────────
//
// v2.2.3 — beginStep()'s out-of-range guard called finishLesson(), which does not
//          exist in this file or anywhere in the repo. It threw a ReferenceError
//          from the one branch written to rescue the situation, abandoning
//          beginStep() before the intro was hidden or the keyboard wired: a dead
//          drill screen, no record written, nothing for a student to report. Now
//          clears the stale checkpoint and returns to the map. Also untangled the
//          `!x === false` resume condition, which was correct and unreadable.
// v2.2.2 — Firefox Quick Find fix, matching game.js 3.9.3. #drill-keyboard is a
//          div, so it absorbs nothing, and lessons drill punctuation on purpose.
// v2.2.1 — flushStats()'s re-entrancy guard was `if`, which serialises two
//          callers and lets three or more overlap. Now `while`. v2.2.0 added
//          the guard and got the shape wrong; this is the same one-word fix
//          as game.js 3.9.2, which had the identical defect.
// v2.2.0 — Read caching, backported from game.js. This page had NONE and was
//          the most-used one: ~115 reads per load became ~3. Lessons cache is
//          validated by a count aggregation (1 read, not 80); loadLessons()
//          double-fired on most loads and now shares an in-flight promise;
//          flushStats() got a re-entrancy guard and the hidden-tab flush a
//          60s floor.
// v2.1.0 — Batch B: every finished run writes runAttempts / runFailures /
//          furthestRunIdx / lastSeenAt, queued onto the existing flush. A
//          grade F now leaves a record; previously the students in the most
//          trouble left no trace at all.
// v2.0.0 — Batch A, the stall fix. Long steps chunked into runs under 150
//          chars, run position persisted, net WPM, idle-aware graded clock,
//          accuracy-gated advancement, per-step gates inferred from type.
//
// ── Load-bearing ──────────────────────────────────────────────────────────
//
//   * saveProgress() uses merge:true. Without it, completing a lesson erases
//     every run-level field.
//   * ttb_learnwal_v1 and ttb_learnpos_v1 both carry an explicit `v`. Bump it
//     rather than changing the payload shape, or a mid-run student on the old
//     shape gets a corrupt resume.
//   * Do NOT scale gates by grade level. An 8th grader may have had this
//     teacher twice or never; unit position is the only honest signal.
import { db, auth } from "./firebase-config.js";
import {
    collection, getDocs, doc, getDoc, setDoc, addDoc, deleteDoc,
    // Aggregation query. Firestore bills getCountFromServer at ONE read per up
    // to 1000 matched index entries, which is what makes the lessons cache
    // validation cost 1 read instead of ~80. Available since SDK v9.11.
    getCountFromServer
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import {
    onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signOut
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
    FINGER_COLORS, FINGER_NAMES, LAYOUTS, KB_VERSION,
    createKeyboard, buildFingerMap, getFingerInfo,
    createHandGuide, buildFingerSVG, setHandGuideToChar, setHandGuideToChars,
    resetHandGuideToHome, colorKeyboardKeys, flashFingerPressed,
    getHomePositions, getKeyCenterInKB, toggleKeyboardCase
} from "./keyboard.js";

// ─── Constants ────────────────────────────────────────────────────────────────
const LEARN_VERSION = "2.2.3";

const ADMIN_EMAILS = [
    "jacob.wilson@sumnerk12.net",
    "jacob.v.wilson@gmail.com",
];

// Game Genie state (admin only, session-scoped)
let ggAllowMistakes = false;
let ggBypassIdle    = false; // bump z every deploy to confirm cache cleared
const LAYOUT = localStorage.getItem('keyboardLayout') || 'qwerty';
const INTRO_ANIM_MS   = 1400;   // ms per animation frame (home ↔ reach)

// ─── State ────────────────────────────────────────────────────────────────────
let currentUser = null;
let allLessons   = [];   // sorted lesson objects from Firestore
let userProgress = {};   // lessonId → progress doc

// Anon session tracking — accumulates until sign-in
let anonPromptShown       = false;
let anonSecondsAccum      = 0;
let anonLessonsCompleted  = 0;
let anonLessonProgress    = {};
const ANON_REMIND_AFTER_LESSONS = 2;
const ANON_REMIND_AFTER_SECONDS = 120;

// ─── Stats & Goals (mirrors game.js — writes to same Firestore path) ────────
let statsData = { secondsToday:0, secondsWeek:0, charsToday:0, charsWeek:0,
                  mistakesToday:0, mistakesWeek:0, lastDate:'', weekStart:0 };
let goals     = { dailySeconds: 0, weeklySeconds: 0 };
let classInfo = { id: '', name: '', dailySeconds: 0, weeklySeconds: 0 };
let dailyGoalCelebrated  = false;
let weeklyGoalCelebrated = false;
let learnActiveSeconds   = 0;   // active seconds this step (for HUD display)
let learnTickInterval    = null;
let learnLastInputTime   = 0;
const LEARN_IDLE_THRESHOLD = 3000; // 3s idle = paused

// ─── Drill session state ─────────────────────────────────────────────────────
let currentLesson  = null;

// ─── Runs, not steps (v2.0.0) ────────────────────────────────────────────────
// A lesson's authored steps are expanded at lesson start into a flat list of
// "runs". A short step becomes one run; a long one is split into several. Runs are
// what the engine actually executes, grades, and counts pips for — currentStepIdx
// indexes currentRuns, NOT currentLesson.steps.
//
// Why this exists: six authored steps were longer than a 10-minute class period at
// the pace required to pass them (u6_l2 step 1 is 789 chars at a 20 WPM gate =
// 10.5 minutes of flawless typing), and nothing survived the bell. Chunking in the
// engine rather than the data fixes all 47 existing lessons without touching a
// single Firestore document. See PEDAGOGY-AUDIT.md §3.2.
const CHUNK_TARGET = 150;   // ≈30–60s at these gates; matches game.js sprint length
const CHUNK_SLACK  = 1.30;  // a 180-char step stays whole rather than becoming 150+30

let currentRuns    = [];  // expanded + chunked runs for the current lesson
let currentStepIdx = 0;   // index into currentRuns
let currentStep    = null;// currentRuns[currentStepIdx]
let drillSequence  = [];  // array of chars to type for current run
let drillPos       = 0;   // index into drillSequence
let mistakes       = 0;
let chars          = 0;
let stepStartTime  = 0;
let stepSeconds    = 0;
let timerInterval  = null;
let introAnimTimer = null;
let introAnimFrame = 0;   // 0 = home, 1 = reach
let fingerMap      = buildFingerMap(LAYOUT);
let missedChars    = {};  // char → count for this lesson

// Per-character done states — mirrors game.js currentLetterStatus logic
let drillCharStates      = [];      // 'upcoming' | 'perfect' | 'fixed' | 'dirty' per char
let drillLetterStatus    = 'clean'; // 'clean' | 'error' | 'fixed'
let drillBackspaceOrigin = -1;      // furthest pos reached during a backspace run
let drillConsecutiveMistakes = 0;   // resets on any correct key
let drillIsHardStop      = false;   // timer paused, waiting for correct key
// DRILL_STOP_TIME_THRESHOLD (was 3) removed in v2.0.0 — it did not do what its name
// or comment claimed. See the note in handleDrillKey's error branch.
const DRILL_HARD_STOP_THRESHOLD = 5;  // consecutive errors before hard stop overlay (matches game.js)
const DRILL_SPAM_THRESHOLD      = 10; // consecutive errors to restart step entirely

// ─── DOM ─────────────────────────────────────────────────────────────────────
const mapView        = document.getElementById('map-view');
const drillView      = document.getElementById('drill-view');
const introPanel     = document.getElementById('intro-panel');
const activeDrill    = document.getElementById('active-drill');
const lessonMapEl    = document.getElementById('lesson-map');
const introKeysEl    = document.getElementById('intro-keys');
const introTitleEl   = document.getElementById('intro-title');
const introTextEl    = document.getElementById('intro-text');
const introStartBtn  = document.getElementById('intro-start-btn');
const introKeyboard  = document.getElementById('intro-keyboard');
const drillTextEl    = document.getElementById('drill-text');
const stepLabelEl    = document.getElementById('step-label');
const stepProgressEl = document.getElementById('step-progress-bar');
const drillModal     = document.getElementById('drill-modal');
const drillKeyboard  = document.getElementById('virtual-keyboard');
const wpmDisplay     = document.getElementById('wpm-display');
const accDisplay     = document.getElementById('acc-display');
const mapProgressEl  = document.getElementById('map-progress-summary');
const graduateLink   = document.getElementById('graduate-link');
const backBtn        = document.getElementById('back-btn');
const hudLessonLabel = document.getElementById('hud-lesson-label');
const hudTimer       = document.getElementById('hud-timer');

// ─── Auth ─────────────────────────────────────────────────────────────────────
document.getElementById('login-btn').onclick = async () => {
    try { await signInWithPopup(auth, new GoogleAuthProvider()); } catch(e) { console.error(e); }
};
document.getElementById('logout-btn').onclick = async () => {
    try { await signOut(auth); } catch(e) { console.error(e); }
};
onAuthStateChanged(auth, async user => {
    currentUser = user;
    const userInfo = document.getElementById('user-info');
    const loginBtn = document.getElementById('login-btn');
    if (user) {
        document.getElementById('user-name').textContent = user.displayName || user.email;
        userInfo.classList.remove('hidden'); loginBtn.style.display = 'none';
        // Game Genie button — admin only
        if (!document.getElementById('learn-genie-btn')) {
            const gg = document.createElement('button');
            gg.id = 'learn-genie-btn';
            gg.innerHTML = '<span style="font-size:1.1em;">\uD83D\uDD25</span>' +
                '<span class="gg-fire">G</span><span class="gg-fire gg-fire2">G</span>' +
                '<span style="font-size:1.1em;">\uD83D\uDD25</span>';
            gg.title = 'Game Genie (admin)';
            gg.style.cssText = 'position:fixed;bottom:12px;left:12px;z-index:9999;' +
                'background:#111;border:1px solid #ff6600;color:#ff6600;' +
                'padding:4px 8px;cursor:pointer;border-radius:4px;font-family:monospace;' +
                'font-size:0.85rem;font-weight:bold;';
            gg.onclick = openLearnGenie;
            document.body.appendChild(gg);
        }
        const ggBtn = document.getElementById('learn-genie-btn');
        if (ggBtn) ggBtn.style.display = ADMIN_EMAILS.includes(user.email) ? '' : 'none';
        // ⚠️ NO length check here any more. loadLessons() is idempotent and
        // returns the in-flight promise if the module-load call is still
        // running, so awaiting it unconditionally is both correct and cheaper
        // than the guard it replaces. See the comment on _lessonsInFlight.
        await loadLessons();
        await retroactiveSaveAnonSession(user);
        await loadUserProgress();
        await loadUserStats();
        walRecoverLearn();   // replay unflushed lesson time from a dead session
        await loadGoals();
        // ⚠️ ORDER CHANGED: goals now runs FIRST so classInfo is populated, and
        // the pending-assignment lookup is skipped entirely for the ~99% of
        // students who already have a class. That read was firing on every
        // single login, for every student, forever, to find nothing.
        if (!(classInfo && classInfo.id)) await applyPendingClassAssignment(user);
    } else {
        userInfo.classList.add('hidden'); loginBtn.style.display = '';
        userProgress = {};
        // Load lessons if needed for signed-out view
        if (allLessons.length === 0) await loadLessons();
    }
    renderMap();
});


// ─── Anon Login Reminder ──────────────────────────────────────────────────────
function checkAnonLoginPrompt() {
    if (anonPromptShown || currentUser) return;
    if (anonLessonsCompleted >= ANON_REMIND_AFTER_LESSONS ||
        anonSecondsAccum    >= ANON_REMIND_AFTER_SECONDS) {
        anonPromptShown = true;
        // Slight delay so the lesson result modal finishes first
        setTimeout(showAnonLoginPrompt, 800);
    }
}

function showAnonLoginPrompt() {
    if (currentUser) return; // signed in while waiting

    // Pause any active drill
    clearInterval(timerInterval);
    clearInterval(learnTickInterval);

    const mins = Math.round(anonSecondsAccum / 60);
    const timeStr = mins >= 1 ? mins + ' minute' + (mins !== 1 ? 's' : '') : 'a bit';

    // Show over whatever is currently visible using a fixed overlay
    const overlay = document.createElement('div');
    overlay.id = 'anon-login-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,0.55);' +
        'display:flex;align-items:center;justify-content:center;';

    overlay.innerHTML =
        '<div style="background:#fff;border-radius:8px;padding:28px 32px;max-width:360px;' +
        'text-align:center;box-shadow:0 8px 32px rgba(0,0,0,0.3);font-family:"Courier Prime",monospace;">' +
        '<div style="font-size:1.5rem;margin-bottom:8px;">\uD83D\uDCAA Nice work!</div>' +
        '<div style="color:#444;font-size:0.92rem;margin-bottom:16px;line-height:1.5;">' +
        'You’ve been typing for ' + timeStr + '.' +
        '<br>Sign in to <strong>save your progress</strong> and have it count toward your goals!' +
        '</div>' +
        '<button id="anon-signin-btn" style="width:100%;padding:12px;background:var(--carolina-blue);' +
        'color:white;border:none;border-radius:5px;font-size:1rem;font-weight:bold;' +
        'cursor:pointer;font-family:inherit;margin-bottom:8px;">Sign In with Google</button>' +
        '<button id="anon-skip-btn" style="width:100%;padding:8px;background:none;border:none;' +
        'color:#aaa;font-size:0.82rem;cursor:pointer;font-family:inherit;">Continue without signing in</button>' +
        '</div>';

    document.body.appendChild(overlay);

    document.getElementById('anon-skip-btn').onclick = () => {
        overlay.remove();
        // Resume if mid-drill: the drill view is showing and no modal is over it.
        //
        // v2.2.3 rewrote the second half from `!drillModal.classList.contains(
        // 'hidden') === false`. That is EQUIVALENT — unary ! binds tighter than
        // ===, so (!contains) === false reduces to contains === true, i.e. the
        // modal is hidden — but it is shaped exactly like a typo, and the next
        // person to touch it will "fix" it into its own negation.
        const onDrill    = !drillView.classList.contains('hidden');
        const modalIsUp  = !drillModal.classList.contains('hidden');
        if (onDrill && !modalIsUp) {
            beginStep(currentStepIdx); // restarts current step fresh — acceptable
        }
    };

    document.getElementById('anon-signin-btn').onclick = async () => {
        const signinBtn = document.getElementById('anon-signin-btn');
        signinBtn.textContent = 'Signing in…'; signinBtn.disabled = true;
        try {
            await signInWithPopup(auth, new GoogleAuthProvider());
            // onAuthStateChanged fires — retroactive save handled there
            overlay.remove();
        } catch(e) {
            signinBtn.textContent = 'Sign In with Google'; signinBtn.disabled = false;
            if (e.code !== 'auth/popup-closed-by-user') console.warn('Sign-in failed:', e);
        }
    };
}

async function retroactiveSaveAnonSession(user) {
    if (!user || user.isAnonymous) return;
    if (!anonSecondsAccum && !Object.keys(anonLessonProgress).length) return;

    try {
        const today = new Date();
        const dateStr = today.getFullYear() + '-' +
            String(today.getMonth()+1).padStart(2,'0') + '-' +
            String(today.getDate()).padStart(2,'0');
        const weekStart = getWeekStart(today);

        // Merge accumulated time into their stats
        const statsRef = doc(db, 'users', user.uid, 'stats', 'time_tracking');
        const statsSnap = await getDoc(statsRef);
        if (statsSnap.exists()) {
            const data = statsSnap.data();
            if (data.lastDate === dateStr) {
                statsData.secondsToday += data.secondsToday || 0;
                statsData.charsToday   += data.charsToday   || 0;
                statsData.mistakesToday+= data.mistakesToday|| 0;
            }
            if ((data.weekStart || '') === weekStart) {
                statsData.secondsWeek  += data.secondsWeek  || 0;
                statsData.charsWeek    += data.charsWeek    || 0;
                statsData.mistakesWeek += data.mistakesWeek || 0;
            }
        }
        statsData.lastDate  = dateStr;
        statsData.weekStart = weekStart;
        await setDoc(statsRef, statsData, { merge: true });

        // Save lesson progress accumulated during anon session
        const GRADE_ORDER = ['F','D','C','B','A', 'A' + String.fromCodePoint(0x1F525)];
        for (const [lessonId, record] of Object.entries(anonLessonProgress)) {
            const progRef  = doc(db, 'users', user.uid, 'lessonProgress', lessonId);
            const progSnap = await getDoc(progRef);
            if (progSnap.exists()) {
                // Keep best grade between what was saved and this anon session
                const existing = progSnap.data();
                const existGrade  = existing.grade || 'F';
                const anonGrade   = record.grade   || 'F';
                const bestGrade   = GRADE_ORDER.indexOf(anonGrade) > GRADE_ORDER.indexOf(existGrade)
                    ? anonGrade : existGrade;
                await setDoc(progRef, {
                    ...record,
                    grade:   bestGrade,
                    passed:  record.passed || existing.passed || false,
                    attempts: (existing.attempts || 0) + (record.attempts || 1),
                    timeSpentSeconds: (existing.timeSpentSeconds || 0) + (record.timeSpentSeconds || 0),
                }, { merge: false });
            } else {
                await setDoc(progRef, record);
            }
            userProgress[lessonId] = record;
        }

        // Clear anon accumulators
        anonSecondsAccum = 0;
        anonLessonProgress = {};

        console.log('[TTB] Retroactive anon session saved:', Object.keys(anonLessonProgress).length, 'lessons');
    } catch(e) { console.warn('[TTB] Retroactive save failed:', e); }
}

// ═════════════════════════════════════════════════════════════════════════════
// READ CACHING  (v2.2.0)
// ═════════════════════════════════════════════════════════════════════════════
//
// Every fix in this block exists in game.js already and never got backported.
// The result was that the MOST-USED page in the app was the only one with no
// caching at all. A returning student cost ~5 reads in game.js and ~115 in
// learn.js, for the same ten minutes of typing.
//
// What was read on EVERY learn.js load, uncached:
//   the whole `lessons` collection        (~80 docs)
//   the whole `lessonProgress` subcoll    (~30 docs mid-curriculum)
//   users/{uid} + classes/{id}            (2 docs, for goals)
//   pendingClassAssignments/{email}       (1 doc, almost always absent)
//
// ⚠️ Cache invalidation strategy differs per collection and the reasons matter:
//
//   lessons        — shared, edited rarely, by an adult. Validated with an
//                    aggregation COUNT query, which Firestore bills as ONE read
//                    per 1000 matched index entries. So the check costs 1 read
//                    instead of 80. A count catches added/removed lessons
//                    instantly; edits to an EXISTING lesson are caught by the
//                    TTL below. That is the deliberate trade.
//   lessonProgress — per-student, and this tab is normally the only writer, so
//                    the local copy stays true. Shorter TTL because a student
//                    on a second device is possible.
//   goals          — verbatim port of game.js GOALS_CACHE_KEY.
//
// ⚠️ Every cache key is namespaced by uid. A shared cart Chromebook must never
// hand one student's progress to the next one who sits down.

const LESSONS_CACHE_KEY   = 'ttb_lessonsCache_v1';
const LESSONS_CACHE_MS    = 4 * 3600 * 1000;    // content edits land within 4h
const PROGRESS_CACHE_KEY  = 'ttb_lessonProgCache_v1';
const PROGRESS_CACHE_MS   = 8 * 3600 * 1000;    // one school day
const LEARN_GOALS_KEY     = 'ttb_goalsCache_v1'; // SAME key game.js uses — one
                                                 // read serves both pages
const LEARN_GOALS_MS      = 24 * 3600 * 1000;

// Read a namespaced cache entry, or null. Never throws: a corrupt or absent
// cache must degrade to a real read, never to a broken page.
function cacheRead(key, maxAgeMs, uid) {
    try {
        const raw = localStorage.getItem(key);
        if (!raw) return null;
        const c = JSON.parse(raw);
        if (uid !== undefined && c.uid !== uid) return null;
        if ((Date.now() - c.at) > maxAgeMs) return null;
        return c;
    } catch (_) { return null; }
}

// Write a cache entry. A quota failure drops OUR keys and gives up quietly —
// the cache is an optimisation and must never break a page load.
function cacheWrite(key, payload) {
    try {
        localStorage.setItem(key, JSON.stringify({ at: Date.now(), ...payload }));
    } catch (e) {
        try {
            Object.keys(localStorage)
                .filter(k => k.startsWith('ttb_lessonsCache') ||
                             k.startsWith('ttb_lessonProgCache'))
                .forEach(k => localStorage.removeItem(k));
        } catch (_) {}
    }
}

// Admin escape hatch, wired into the Game Genie. After editing a lesson, Jake
// can drop every cache and reload rather than waiting out the TTL.
function ttbClearLearnCaches() {
    [LESSONS_CACHE_KEY, PROGRESS_CACHE_KEY, LEARN_GOALS_KEY].forEach(k => {
        try { localStorage.removeItem(k); } catch (_) {}
    });
}
window.ttbClearLearnCaches = ttbClearLearnCaches;

// ─── Load Lessons ─────────────────────────────────────────────────────────────
//
// ⚠️ IN-FLIGHT PROMISE, NOT A LENGTH CHECK. The old guard was
// `if (allLessons.length === 0) await loadLessons()` in the auth handler, with a
// fire-and-forget loadLessons() at module load. Auth settles in ~200ms; the
// collection fetch takes ~300ms. So the guard tested a length that had not been
// populated yet and ran the app's single biggest read A SECOND TIME, on most
// loads. The comment on the old guard acknowledged the race; the guard did not
// close it. A promise handle is the only thing that does.
let _lessonsInFlight = null;

async function loadLessons() {
    if (_lessonsInFlight) return _lessonsInFlight;
    _lessonsInFlight = (async () => {
        try {
            const cached = cacheRead(LESSONS_CACHE_KEY, LESSONS_CACHE_MS);
            if (cached && Array.isArray(cached.lessons) && cached.lessons.length) {
                // Validate with a count aggregation: 1 billed read instead of ~80.
                let liveCount = null;
                try {
                    const agg = await getCountFromServer(collection(db, 'lessons'));
                    liveCount = agg.data().count;
                } catch (_) { /* aggregation unavailable — trust the TTL */ }
                if (liveCount === null || liveCount === cached.lessons.length) {
                    allLessons = cached.lessons;
                    afterLessonsLoaded();
                    return;
                }
            }

            const snap = await getDocs(collection(db, 'lessons'));
            allLessons = [];
            snap.forEach(d => allLessons.push(d.data()));
            allLessons.sort((a, b) => {
                if (a.unit !== b.unit) return a.unit - b.unit;
                return a.lesson - b.lesson;
            });
            cacheWrite(LESSONS_CACHE_KEY, { lessons: allLessons });
            afterLessonsLoaded();
        } catch(e) {
            // Last resort: an expired cache beats an error screen. A student
            // with no connection can still see the map they saw this morning.
            const stale = cacheRead(LESSONS_CACHE_KEY, Infinity);
            if (stale && Array.isArray(stale.lessons) && stale.lessons.length) {
                allLessons = stale.lessons;
                afterLessonsLoaded();
                console.warn('Lessons fetch failed; serving expired cache.', e);
                return;
            }
            lessonMapEl.innerHTML = '<div style="color:#888; text-align:center; padding:40px;">Could not load lessons. Check your connection.</div>';
            console.error(e);
        }
    })();
    try { await _lessonsInFlight; }
    finally { _lessonsInFlight = null; }
}

function afterLessonsLoaded() {
    // If the map is already visible but was rendered before lessons loaded, refresh it
    if (!mapView.classList.contains('hidden') &&
        lessonMapEl.querySelectorAll('.map-lesson-card').length === 0) {
        renderMap();
    }
}

async function loadUserProgress() {
    if (!currentUser) return;
    userProgress = {};

    const cached = cacheRead(PROGRESS_CACHE_KEY, PROGRESS_CACHE_MS, currentUser.uid);
    if (cached && cached.progress && typeof cached.progress === 'object') {
        userProgress = cached.progress;
        return;
    }

    try {
        const snap = await getDocs(collection(db, 'users', currentUser.uid, 'lessonProgress'));
        snap.forEach(d => { userProgress[d.id] = d.data(); });
        cacheWrite(PROGRESS_CACHE_KEY, { uid: currentUser.uid, progress: userProgress });
    } catch(e) { console.warn('Could not load lesson progress:', e); }
}

// Called after every local progress write so the cache tracks what this tab
// already knows. Without this the cache would go stale the instant a student
// finished a lesson, and the next load would show them un-completing it.
function refreshProgressCache() {
    if (!currentUser) return;
    cacheWrite(PROGRESS_CACHE_KEY, { uid: currentUser.uid, progress: userProgress });
}

// ─── Lesson Map ───────────────────────────────────────────────────────────────
function renderMap() {
    lessonMapEl.innerHTML = '';
    if (allLessons.length === 0) {
        lessonMapEl.innerHTML = '<div style="color:#888; text-align:center; padding:40px;">No lessons loaded.</div>';
        return;
    }

    const completed = new Set(Object.keys(userProgress).filter(id => userProgress[id]?.passed));
    const totalLessons = allLessons.length;
    const doneCount = completed.size;
    mapProgressEl.textContent = currentUser
        ? `${doneCount} of ${totalLessons} lessons complete`
        : 'Sign in to save your progress';

    // Build by unit
    // "Continue" button — find first incomplete unlocked lesson
    const continueLesson = allLessons.find(l => !completed.has(l.id) && isUnlocked(l));
    const continueBtnEl = document.getElementById('map-continue-btn');
    if (continueBtnEl) {
        if (continueLesson) {
            const keys = (continueLesson.newKeys || []).length
                ? continueLesson.newKeys.map(k => k.toUpperCase()).join(' ') : '↺';
            continueBtnEl.textContent = '▶ Continue: ' + (continueLesson.title || continueLesson.id);
            continueBtnEl.style.display = '';
            continueBtnEl.onclick = () => startLesson(continueLesson);
        } else {
            continueBtnEl.style.display = 'none';
        }
    }

    // Show today's time in map header
    const timeEl = document.getElementById('map-time-today');
    if (timeEl && statsData.secondsToday > 0) {
        const dailyDone = goals.dailySeconds > 0 && statsData.secondsToday >= goals.dailySeconds;
        timeEl.innerHTML = 'Today: <strong>' + formatTime(statsData.secondsToday) + '</strong>' +
            (dailyDone ? ' <span class="goal-badge goal-daily" style="display:inline-flex;width:18px;height:18px;font-size:0.65rem;">✓</span>' : '');
        timeEl.style.display = '';
    }

    const byUnit = {};
    allLessons.forEach(l => {
        const u = l.unit || 0;
        if (!byUnit[u]) byUnit[u] = [];
        byUnit[u].push(l);
    });

    const UNIT_LABELS = {
        1: 'Unit 1 — Home Row',
        2: 'Unit 2 — Index Fingers',
        3: 'Unit 3 — Middle & Ring Up',
        4: 'Unit 4 — Remaining Letters',
        5: 'Unit 5 — Number Row',
        6: 'Unit 6 — Shift & Capitals',
        7: 'Unit 7 — Graduation',
    };

    // Find first unlocked-and-incomplete lesson to highlight
    let firstActiveId = null;
    let prevUnlocked = true;
    for (const lesson of allLessons) {
        if (!completed.has(lesson.id) && prevUnlocked) { firstActiveId = lesson.id; break; }
        prevUnlocked = completed.has(lesson.id);
    }

    Object.keys(byUnit).sort((a,b) => a-b).forEach(unit => {
        const header = document.createElement('div');
        header.className = 'map-unit-header';
        header.textContent = UNIT_LABELS[unit] || `Unit ${unit}`;
        lessonMapEl.appendChild(header);

        const row = document.createElement('div');
        row.className = 'map-lesson-row';

        byUnit[unit].forEach(lesson => {
            const prog = userProgress[lesson.id];
            const isDone = prog?.passed;
            const grade = prog?.grade || (prog?.stars ? ['','B','A','A🔥'][Math.min(prog.stars,3)] : '');
            const isLocked = !isDone && !isUnlocked(lesson);
            const isNext = lesson.id === firstActiveId;

            const card = document.createElement('div');
            card.className = 'map-lesson-card' +
                (isLocked ? ' locked' : '') +
                (isDone   ? ' completed' : '') +
                (isNext   ? ' active-next' : '');

            const keysLabel = (lesson.newKeys || []).length
                ? lesson.newKeys.map(k => k.toUpperCase()).join(' ')
                : (lesson.unit === 7 ? '★' : '↺');

            card.innerHTML = `
                <div class="mlc-keys">${keysLabel}</div>
                <div class="mlc-title">${escHtml(lesson.title || lesson.id)}</div>
                <div class="mlc-meta">${mapMeta(lesson)}</div>
                <div class="mlc-stars">${gradeOnMap(grade)}</div>
                ${isLocked ? '<div class="mlc-lock">🔒</div>' : ''}
            `;

            if (!isLocked) {
                card.addEventListener('click', () => startLesson(lesson));
            }
            row.appendChild(card);
        });

        lessonMapEl.appendChild(row);
    });

    // Graduate button: show if all non-Unit-7 lessons complete
    const graduateable = allLessons.filter(l => l.unit < 7).every(l => completed.has(l.id));
    graduateLink.classList.toggle('hidden', !graduateable);
}

// Map card subtitle. Reports the number of runs a student will actually type — a
// 2-step lesson can be 12 runs after chunking — and the accuracy target, which is
// the gate that governs advancement everywhere. Speed is shown only where it's
// graded, so the card can't advertise a WPM number the lesson won't enforce.
function mapMeta(lesson) {
    const runs = buildRunList(lesson).length;
    const g    = lesson.gates || {};
    const acc  = g.minAccuracy == null ? 85 : g.minAccuracy;
    const prose = (lesson.steps || []).some(s => !DRILL_TYPES.has(s.type));
    const wpm  = g.minWPM == null ? 15 : g.minWPM;
    return runs + (runs === 1 ? ' run · ' : ' runs · ') + acc + '%' +
           (prose ? ' · ' + wpm + ' WPM' : '');
}

function isUnlocked(lesson) {
    // A lesson is unlocked if it's the first in its unit, or the previous lesson is complete
    const idx = allLessons.findIndex(l => l.id === lesson.id);
    if (idx === 0) return true;
    const prev = allLessons[idx - 1];
    // Different unit: first of new unit needs previous unit's last lesson done
    return userProgress[prev.id]?.passed === true;
}

const FIRE_GRADE = 'A' + String.fromCodePoint(0x1F525); // A🔥

// v2.0.0 grade model.
//
// Accuracy is the gate. Speed sets the badge. Three things changed and each fixes a
// specific way the old model punished the wrong student:
//
//   1. C now ADVANCES. Under the old model both gates had to be met, so 14 WPM at
//      100% accuracy failed while 15 WPM at 85% passed — the more careful typist
//      was the one held back. Accuracy met + speed short is a pass with a C.
//   2. D/F depend on accuracy alone. Being slow is never failing.
//   3. A🔥 is reachable. It was 2× the WPM gate at 95% accuracy, which on a 49-char
//      drill meant 30 WPM at 0.40s/keystroke — an adult touch-typist number sitting
//      permanently on the lesson map where every student could see it and none
//      could earn it. On drill runs it is now a clean run (zero mistakes), fully
//      inside the student's control. On prose runs it is 1.5× rather than 2×.
//
// `minWPM: null` (every key-drill run) means speed is measured and displayed but
// not graded. `clean` is a true zero-mistake flag, not rounded accuracy — 99.6%
// rounds to 100 and should not earn a badge that says perfect.
function calculateGrade(wpm, acc, minWPM, minAcc, clean) {
    if (acc < minAcc) return acc < minAcc * 0.80 ? 'F' : 'D';

    // Accuracy-only run: the badge is about how clean it was.
    if (minWPM == null) {
        if (clean)     return FIRE_GRADE;
        if (acc >= 95) return 'A';
        return 'B';
    }

    if (wpm >= minWPM) {
        if (wpm >= minWPM * 1.5  && acc >= 95) return FIRE_GRADE;
        if (wpm >= minWPM * 1.15 && acc >= 90) return 'A';
        return 'B';
    }
    return 'C';   // accuracy met, speed short — advances
}

// Advancement, in one place so the modals can't disagree about it.
function gradeAdvances(grade, gates) {
    if (grade === 'D' || grade === 'F') return false;
    if (grade === 'C' && gates && gates.strictSpeed) return false;
    return true;
}

// Feedback text. The old version's C and D branches told students to speed up, which
// on a paused-clock or accuracy-only run was simply false information — and being
// told to try harder at something you already did is how a student concludes the
// problem is them. Every message below names a cause the student can act on, and no
// message asks for speed on a run where speed isn't gated.
function getGradeMessage(wpm, acc, minWPM, minAcc, grade) {
    function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
    const speedGated = (minWPM != null);
    const accShort   = minAcc - acc;

    if (grade === FIRE_GRADE) return pick([
        speedGated ? 'On fire! Fast AND clean.' : 'A perfect run. Not one mistake.',
        'Outstanding — that\u2019s as good as it gets.',
        'Absolutely blazing. Keep it up!'
    ]);
    if (grade === 'A') return pick([
        'Excellent work \u2014 really clean typing.',
        speedGated ? 'Strong pace and strong accuracy. Well done!'
                   : 'Very nearly perfect. Go for a clean run next time!',
        'A-level work. Keep pushing for that fire.'
    ]);
    if (grade === 'B') return pick([
        'Nice job \u2014 you passed!',
        'Solid typing. On to the next one.',
        'That\u2019s a pass. Keep it going!'
    ]);
    // C only happens on a speed-gated run: accuracy was fine, pace was short.
    if (grade === 'C') return pick([
        'Passed \u2014 accuracy is where it needs to be. Speed will come with practice.',
        'Good, accurate typing. You\u2019re through; the pace builds on its own.',
        'That counts. Accuracy first is exactly the right order.'
    ]);
    if (grade === 'D') return pick([
        'So close \u2014 ' + accShort + '% more accuracy and this one is done.',
        'Accuracy is at ' + acc + '%, and you need ' + minAcc + '%. Slow right down; there\u2019s no clock pressure here.',
        'Nearly there. Find each key before you press it \u2014 going slower actually helps.'
    ]);
    return pick([
        'Let\u2019s slow way down and focus on hitting the right keys. Take your time \u2014 the timer pauses when you pause.',
        'Take a breath. Find the key, press the key, repeat. Speed is not the goal yet.',
        'Every expert was once a beginner. Slow and correct beats fast and messy.'
    ]);
}


function gradeHTML(grade) {
    const map = {
        'A🔥': { color:'#ff6600', label:'A 🔥', bg:'rgba(255,100,0,0.12)' },
        'A':   { color:'#22c55e', label:'A',    bg:'rgba(34,197,94,0.12)'  },
        'B':   { color:'#4B9CD3', label:'B',    bg:'rgba(75,156,211,0.12)' },
        'C':   { color:'#FFD700', label:'C',    bg:'rgba(255,215,0,0.12)'  },
        'D':   { color:'#FF9800', label:'D',    bg:'rgba(255,152,0,0.12)'  },
        'F':   { color:'#888',    label:'F',    bg:'rgba(128,128,128,0.08)'},
    };
    const g = map[grade] || map['F'];
    return '<span class="grade-badge" style="color:' + g.color + ';background:' + g.bg + ';">' + g.label + '</span>';
}

function gradeOnMap(grade) {
    // Compact version for the lesson map card
    if (!grade) return '';
    if (grade === 'A🔥') return '<span style="color:#ff6600;font-weight:bold;font-size:0.85rem;">A🔥</span>';
    const colors = { A:'#22c55e', B:'#4B9CD3', C:'#FFD700', D:'#FF9800', F:'#888' };
    return '<span style="color:' + (colors[grade] || '#888') + ';font-weight:bold;font-size:0.85rem;">' + grade + '</span>';
}

// ─── Start Lesson ─────────────────────────────────────────────────────────────
function startLesson(lesson) {
    currentLesson  = lesson;
    currentRuns    = buildRunList(lesson);
    currentStepIdx = 0;
    mistakes       = 0;
    chars          = 0;
    missedChars    = {};
    hudLessonLabel.textContent = lesson.title || '';
    backBtn.href = '#'; backBtn.onclick = () => { stopLesson(); return false; };

    showView('drill');

    // Resume mid-lesson if there's a saved position for this lesson: skip the intro
    // and drop straight back where the bell interrupted them. The intro is a
    // re-read they didn't ask for, and replaying it was part of what made an
    // interrupted lesson feel like starting from zero.
    const pending = peekPendingRun(lesson.id);
    if (pending && pending.runIdx < currentRuns.length) {
        introPanel.classList.add('hidden');
        beginStep(pending.runIdx);
        return;
    }

    showIntro(lesson);
}

function showIntro(lesson) {
    introPanel.classList.remove('hidden');
    // Keep active-drill visible but collapse it so the drill keyboard
    // gets laid out in the DOM with real pixel dimensions while the intro shows.
    // This eliminates the race condition where beginStep() builds the keyboard
    // on a zero-size element that Safari hasn't reflowed yet.
    activeDrill.classList.remove('hidden');
    activeDrill.style.position = 'absolute';
    activeDrill.style.top = '0';
    activeDrill.style.left = '0';
    activeDrill.style.width = '100%';
    activeDrill.style.height = '100%';
    activeDrill.style.opacity = '0';
    activeDrill.style.pointerEvents = 'none';
    drillModal.classList.add('hidden');
    document.getElementById('drill-keyboard-wrap').style.display = '';
    stopIntroAnim();

    // Key badges
    introKeysEl.innerHTML = (lesson.newKeys || []).length
        ? lesson.newKeys.map(k => '<div class="intro-key-badge">' + escHtml(k.toUpperCase()) + '</div>').join('')
        : '<div class="intro-key-badge" style="font-size:1rem;">All Keys</div>';

    introTitleEl.textContent = lesson.title || '';
    introTextEl.textContent  = lesson.intro || '';

    // Build intro keyboard
    createKeyboard(introKeyboard, LAYOUT);
    createHandGuide(introKeyboard, fingerMap, LAYOUT, true);

    // Pre-build the drill keyboard NOW while it has real dimensions in the DOM.
    // By the time the student hits Start, the keyboard has been laid out for
    // several seconds and beginStep() just needs to show and focus it.
    requestAnimationFrame(() => {
        createKeyboard(drillKeyboard, LAYOUT);
        createHandGuide(drillKeyboard, fingerMap, LAYOUT, true);
        console.log('[TTB] Drill keyboard pre-built during intro — keys:', drillKeyboard.querySelectorAll('.key').length);
        startIntroAnim(lesson);
    });

    introStartBtn.onclick = () => {
        stopIntroAnim();
        document.removeEventListener('keydown', introEnterHandler);
        beginStep(0);
    };

    // Enter key activates Start Lesson from the intro screen
    function introEnterHandler(e) {
        if (e.key === 'Enter' && !introPanel.classList.contains('hidden')) {
            e.preventDefault();
            document.removeEventListener('keydown', introEnterHandler);
            stopIntroAnim();
            beginStep(0);
        }
    }
    document.addEventListener('keydown', introEnterHandler);
}

// ─── Intro Animation ──────────────────────────────────────────────────────────
function startIntroAnim(lesson) {
    const newKeys = lesson.newKeys || [];
    if (newKeys.length === 0) {
        resetHandGuideToHome(introKeyboard, LAYOUT);
        return;
    }

    introAnimFrame = 0;
    runIntroAnimFrame(newKeys);
    introAnimTimer = setInterval(() => {
        introAnimFrame = 1 - introAnimFrame;
        runIntroAnimFrame(newKeys);
    }, INTRO_ANIM_MS);
}

function runIntroAnimFrame(newKeys) {
    if (introAnimFrame === 0) {
        // Frame A: all fingers resting at home
        resetHandGuideToHome(introKeyboard, LAYOUT);
    } else {
        // Frame B: all target fingers reach simultaneously
        // setHandGuideToChars resets once then activates all — no second reset clobbers the first
        setHandGuideToChars(introKeyboard, fingerMap, LAYOUT, newKeys);
    }
}

function stopIntroAnim() {
    if (introAnimTimer) { clearInterval(introAnimTimer); introAnimTimer = null; }
}

// ─── Step Engine ──────────────────────────────────────────────────────────────

// The graded clock. stepSeconds is the WPM denominator, so it must not run while
// the student isn't typing — before v2.0.0 it incremented unconditionally, which
// meant a teacher talking for fifteen seconds mid-drill could put the gate out of
// arithmetic reach and the app would then tell the student to type faster.
// LEARN_IDLE_THRESHOLD and learnLastInputTime already existed; the graded timer
// simply never consulted them.
function isDrillIdle() {
    if (!learnLastInputTime) return true;   // nothing typed yet this run
    return (Date.now() - learnLastInputTime) > LEARN_IDLE_THRESHOLD;
}

function startGradedTimer() {
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        if (drillPos > 0 && !isDrillIdle()) stepSeconds++;
        updateHUD();
    }, 1000);
}

// ⚠️ THE OUT-OF-RANGE GUARD CALLED A FUNCTION THAT DOES NOT EXIST (v2.2.3).
//
// This read `if (!currentStep) { finishLesson(); return; }` and there has never
// been a finishLesson() in this file — the completion path is finishStep() ->
// showLessonResultModal(). So the guard threw a ReferenceError, which is worse
// than no guard at all: the throw abandons beginStep() before the intro panel is
// hidden or the keyboard is wired, leaving the student on a dead drill screen
// with no modal, no error and no way back except the browser Back button. Nothing
// is written, so it is also invisible from the teacher side — the failure mode
// this whole round of instrumentation exists to eliminate.
//
// Reachable two ways, both real:
//   * the Game Genie's step jump calls beginStep(parseInt(select.value)) with no
//     bounds check;
//   * a saved run checkpoint can outlive a lesson edit. Re-chunking a five-run
//     step into three leaves a resume pointing at run 4 of 3. startLesson()
//     bounds-checks the resume, but the checkpoint itself survives, and
//     recordRunOutcome/renderMap both index by run.
//
// Recovery is stopLesson(), not completion. `!currentStep` means the run list and
// the index disagree, and grading a run that does not exist would write a score
// for work nobody did. stopLesson() clears the timers, reloads progress and puts
// the student back on the map, which is where the ← Map button sends them anyway.
// clearRunPosition() goes with it so a stale checkpoint cannot bounce them
// straight back out again.
function beginStep(stepIdx) {
    currentStepIdx = stepIdx;
    currentStep = currentRuns[stepIdx];
    if (!currentStep) {
        console.warn('[TTB] beginStep: run ' + stepIdx + ' does not exist in a ' +
                     currentRuns.length + '-run lesson — clearing the checkpoint ' +
                     'and returning to the map.');
        clearRunPosition();
        stopLesson();
        return;
    }

    introPanel.classList.add('hidden');
    // Restore active-drill to normal flow (was kept visible but hidden during intro)
    activeDrill.style.position = '';
    activeDrill.style.top = '';
    activeDrill.style.left = '';
    activeDrill.style.width = '';
    activeDrill.style.height = '';
    activeDrill.style.opacity = '';
    activeDrill.style.pointerEvents = '';
    drillModal.classList.add('hidden');

    // Keyboard was pre-built during intro — only rebuild if it somehow ended up empty
    if (drillKeyboard.querySelectorAll('.key').length === 0) {
        console.warn('[TTB] beginStep: keyboard empty, rebuilding (pre-build failed)');
        createKeyboard(drillKeyboard, LAYOUT);
        createHandGuide(drillKeyboard, fingerMap, LAYOUT, true);
    }
    drillKeyboard.focus();

    // Progress pips — one per run, so a chunked step shows its parts
    stepProgressEl.innerHTML = currentRuns.map((r, i) => {
        const cls = i < stepIdx ? 'done' : i === stepIdx ? 'active' : '';
        return `<div class="step-pip ${cls}"></div>`;
    }).join('');
    stepLabelEl.textContent = currentStep.label || `Step ${stepIdx + 1}`;

    // The run carries its own baked sequence (see buildRunList).
    drillSequence = currentStep.sequence.slice();
    drillPos  = 0;
    mistakes  = 0;
    chars     = 0;

    // Resume: a matching saved position restores mid-run progress rather than
    // starting over. Consumed once, so a later retry of the same run starts clean.
    const resume = takePendingRun(stepIdx);
    if (resume) {
        drillSequence = resume.seq.split('');
        drillPos  = Math.min(resume.drillPos, drillSequence.length);
        mistakes  = resume.mistakes || 0;
        chars     = resume.chars || 0;
    }
    drillCharStates     = new Array(drillSequence.length).fill('upcoming');
    for (let i = 0; i < drillPos; i++) drillCharStates[i] = 'perfect';
    drillLetterStatus   = 'clean';
    drillBackspaceOrigin = -1;
    drillConsecutiveMistakes = 0;
    drillIsHardStop = false;
    stepStartTime = Date.now();
    stepSeconds   = resume ? (resume.stepSeconds || 0) : 0;

    learnActiveSeconds = 0;
    learnLastInputTime = 0;
    clearInterval(timerInterval);
    clearInterval(learnTickInterval);

    startGradedTimer();

    // Active-time tracking (same pattern as game.js gameTick)
    learnTickInterval = setInterval(() => {
        if (!learnLastInputTime) return;
        const idle = Date.now() - learnLastInputTime;
        if (idle < LEARN_IDLE_THRESHOLD) {
            learnActiveSeconds++;
            statsData.secondsToday++;
            statsData.secondsWeek++;
            if (!currentUser) {
                anonSecondsAccum++;
                checkAnonLoginPrompt();
            }
            // Midnight rollover
            const todayStr = getLocalDateStr();
            if (statsData.lastDate && statsData.lastDate !== todayStr) {
                statsData.secondsToday = 1; statsData.charsToday = 0; statsData.mistakesToday = 0;
                statsData.lastDate = todayStr; dailyGoalCelebrated = false;
                const ws = getWeekStart(new Date());
                if (statsData.weekStart !== ws) {
                    statsData.secondsWeek = 1; statsData.charsWeek = 0; statsData.mistakesWeek = 0;
                    statsData.weekStart = ws; weeklyGoalCelebrated = false;
                }
            }
            // Goal celebrations
            if (goals.dailySeconds > 0 && !dailyGoalCelebrated && statsData.secondsToday >= goals.dailySeconds) {
                dailyGoalCelebrated = true; launchConfetti();
            }
            if (goals.weeklySeconds > 0 && !weeklyGoalCelebrated && statsData.secondsWeek >= goals.weeklySeconds) {
                weeklyGoalCelebrated = true; launchFireworks();
            }
            // Update HUD timer
            if (hudTimer) {
                const m = Math.floor(statsData.secondsToday / 60), s = statsData.secondsToday % 60;
                hudTimer.textContent = m + ':' + String(s).padStart(2,'0');
            }
            updateWeeklyHUD();
        }
    }, 1000);

    renderDrillText();
    advanceHandGuide();

    // Set up keypress handling
    drillKeyboard.onkeydown = handleDrillKey;
    // Defer focus until after the browser has painted the keyboard.
    // Then immediately verify it rendered — if not, rebuild right away
    // rather than waiting for the 2-second periodic check.
    // Single rAF for focus — keyboard was pre-built during intro so no timing games needed
    requestAnimationFrame(() => {
        drillKeyboard.focus();
        _hideKeyboardRecovery();
    });

    // Show a static anchor hint below the step label when anchorEnforced is true.
    // This replaces the reactive popup — it informs without alarming.
    const anchorHint = document.getElementById('anchor-hint');
    if (anchorHint) {
        if (currentStep.anchorEnforced && (currentLesson.anchorKeys || []).length) {
            anchorHint.textContent = '💡 Rest your other fingers lightly on the home keys between strokes.';
            anchorHint.style.display = 'block';
        } else {
            anchorHint.style.display = 'none';
        }
    }
}

function buildSequence(step) {
    switch (step.type) {
        case 'key_pattern':
            return step.text.split('');
        case 'key_pattern_auto':
            return generateReachPattern(step.keySet || [], step.groupSize || 4, step.groupCount || 10);
        case 'key_random':
            return generateRandom(step.keySet || [], step.groupSize || 4, step.groupCount || 12);
        case 'word_list':
            return (step.words || []).join(' ').split('');
        case 'sentence_list':
            return (step.sentences || []).join(' ').split('');
        case 'passage':
            return (step.text || '').split('');
        default:
            return [];
    }
}

// ─── Chunking ────────────────────────────────────────────────────────────────
// Split a character array into runs of roughly CHUNK_TARGET, breaking only at
// spaces so no word or drill group is ever cut in half. Leading spaces are dropped
// from each chunk after the first, so a chunk never opens by asking for a space.
function chunkSequence(seq) {
    if (seq.length <= CHUNK_TARGET * CHUNK_SLACK) return [seq];

    // Aim for equal-sized chunks rather than filling to the brim and leaving a
    // stub: 320 chars becomes 160+160, not 150+150+20.
    const n      = Math.ceil(seq.length / CHUNK_TARGET);
    const target = Math.ceil(seq.length / n);
    const chunks = [];
    let start = 0;

    const STUB = Math.floor(target * 0.5);   // don't leave a fragment behind

    while (start < seq.length) {
        while (start < seq.length && seq[start] === ' ') start++;   // trim leading space
        if (start >= seq.length) break;

        let end = start + target;
        if (end >= seq.length) { chunks.push(seq.slice(start)); break; }

        // Walk back to the nearest space so the break lands between words/groups.
        let cut = end;
        while (cut > start && seq[cut] !== ' ') cut--;
        // No space in range (one very long token) — fall forward instead of
        // producing a zero-length chunk, which would loop forever.
        if (cut === start) {
            cut = end;
            while (cut < seq.length && seq[cut] !== ' ') cut++;
        }
        // If what's left would be a stub, swallow it now. Otherwise the last run of
        // a chunked step ends up being five characters with its own results modal,
        // which reads as a bug even though the arithmetic is fine.
        if (seq.length - cut <= STUB) { chunks.push(seq.slice(start)); break; }

        chunks.push(seq.slice(start, cut));
        start = cut;
    }
    return chunks.filter(c => c.length > 0);
}

// Which step types are pure key drills. These are graded on accuracy only — speed
// on random letter groups is not a meaningful measure of anything, and gating it
// made the new-key drill the hardest thing in its own lesson.
const DRILL_TYPES = new Set(['key_pattern', 'key_pattern_auto', 'key_random']);

// Effective gates for a run. Precedence: explicit step.gates > type default >
// lesson gates. `minWPM: null` means speed is recorded but not gated.
function gatesForRun(run) {
    const lg  = currentLesson ? (currentLesson.gates || {}) : {};
    const acc = lg.minAccuracy == null ? 85 : lg.minAccuracy;
    const wpm = lg.minWPM     == null ? 15 : lg.minWPM;

    // strictSpeed makes a short-on-speed result (grade C) block advancement again.
    // Nothing sets it today. Add `"gates": { ..., "strictSpeed": true }` to the
    // Unit 7 graduation lessons via Import JSON if you ever want 25 WPM enforced
    // rather than advisory — the engine already honours it.
    const strict = !!lg.strictSpeed;

    if (run && run.gates) {
        return { minAccuracy: run.gates.minAccuracy == null ? acc : run.gates.minAccuracy,
                 minWPM:     run.gates.minWPM     === undefined ? wpm : run.gates.minWPM,
                 strictSpeed: run.gates.strictSpeed == null ? strict : !!run.gates.strictSpeed };
    }
    if (run && DRILL_TYPES.has(run.type)) {
        return { minAccuracy: acc, minWPM: null, strictSpeed: false };
    }
    return { minAccuracy: acc, minWPM: wpm, strictSpeed: strict };
}

// Expand authored steps into the run list the engine executes.
function buildRunList(lesson) {
    const runs = [];
    (lesson.steps || []).forEach((step, stepIdx) => {
        const chunks = chunkSequence(buildSequence(step));
        chunks.forEach((seq, chunkIdx) => {
            runs.push({
                stepId:     step.id,
                stepIdx,
                chunkIdx,
                chunkCount: chunks.length,
                type:       step.type,
                anchorEnforced: !!step.anchorEnforced,
                gates:      step.gates || null,   // per-step override, optional
                // Baked, not regenerated. key_random and key_pattern_auto produce a
                // fresh random sequence every call, so a run has to carry its own
                // characters — otherwise a resume would restore a position into a
                // different sequence.
                sequence:   seq,
                label:      chunks.length > 1
                    ? (step.label || `Step ${stepIdx + 1}`) + ` (${chunkIdx + 1}/${chunks.length})`
                    : (step.label || `Step ${stepIdx + 1}`),
            });
        });
    });
    return runs;
}

// Generates a reach pattern: reach→home→reach→home groups for each new key,
// then mixed groups that interleave all keys together.
// Example with g/h: gfgf jhjh fggf jhhj gfhj fgjh fhgj ...
function generateReachPattern(keySet, groupSize, groupCount) {
    if (!keySet.length) return [];
    groupSize = groupSize || 4;
    groupCount = groupCount || 10;

    // Split into reach keys and home keys (some lessonsets may be pure home row)
    const reachKeys = keySet.filter(k => REACH_HOME_COMPANION[k.toLowerCase()]);
    const homeKeys  = keySet.filter(k => !REACH_HOME_COMPANION[k.toLowerCase()]);

    // Build companion pairs: each reach key paired with its home companion
    const pairs = reachKeys.map(k => ({
        reach: k,
        home: REACH_HOME_COMPANION[k.toLowerCase()]
    }));

    // If no reach keys, fall through to pure random
    if (!pairs.length) return generateRandom(keySet, groupSize, groupCount);

    const groups = [];

    // Phase 1: isolated pairs — reach home reach home for each key separately
    // e.g. gfgf, jhjh
    pairs.forEach(({reach, home}) => {
        const g = [];
        for (let i = 0; i < groupSize; i++) g.push(i % 2 === 0 ? reach : home);
        groups.push(g);
    });

    // Phase 2: reversed pairs — home reach reach home (tests finding the reach from home)
    // e.g. fggf, jhhj
    pairs.forEach(({reach, home}) => {
        const g = [];
        for (let i = 0; i < groupSize; i++) {
            if (i === 0 || i === groupSize - 1) g.push(home);
            else g.push(reach);
        }
        groups.push(g);
    });

    // Phase 3: cross pairs — mix all keys together
    // e.g. gfhj fgjh hgfj
    const allKeys = reachKeys.concat(pairs.map(p => p.home)).concat(homeKeys);
    const uniqueKeys = [...new Set(allKeys)];
    const remaining = groupCount - groups.length;
    for (let i = 0; i < remaining; i++) {
        const g = [];
        // Shuffle-ish: pick keys ensuring reach keys appear often
        for (let j = 0; j < groupSize; j++) {
            const pool = j % 2 === 0 ? reachKeys : uniqueKeys;
            g.push(pool[Math.floor(Math.random() * pool.length)]);
        }
        groups.push(g);
    }

    // Flatten with spaces between groups
    const chars = [];
    groups.forEach((g, i) => {
        if (i > 0) chars.push(' ');
        g.forEach(c => chars.push(c));
    });
    return chars;
}

// Home-key companions: for any reach key, the same finger's home-row key.
// Using the same indices as keyboard.js getHomePositions (rows[1] positions 0-9).
const REACH_HOME_COMPANION = {
    'q':'a','z':'a',                         // left-pinky reaches → a
    'w':'s','x':'s',                         // left-ring reaches → s
    'e':'d','c':'d',                         // left-middle reaches → d
    'r':'f','t':'f','g':'f','v':'f','b':'f', // left-index reaches → f
    'y':'j','u':'j','h':'j','n':'j','m':'j', // right-index reaches → j
    'i':'k',',':'k',                         // right-middle reaches → k
    'o':'l','.':'l',                         // right-ring reaches → l
    'p':';','[':';',']':';','\\':';','\'':';','/':';', // right-pinky reaches → ;
    // Number row — same finger as the letter below
    '1':'a','2':'s','3':'d','4':'f','5':'f',
    '6':'j','7':'j','8':'k','9':'l','0':';'
};

function expandKeySetWithHomeCompanions(keySet) {
    // For each reach key in the set, automatically include its home-row companion
    // so students must use correct finger placement and not cheat with index fingers.
    const expanded = new Set(keySet);
    keySet.forEach(k => {
        const companion = REACH_HOME_COMPANION[k.toLowerCase()];
        if (companion) expanded.add(companion);
    });
    return Array.from(expanded);
}

function generateRandom(keySet, groupSize, groupCount) {
    if (!keySet.length) return [];
    // Always include home companions for reach keys
    const effectiveKeySet = expandKeySetWithHomeCompanions(keySet);
    const chars = [];
    for (let g = 0; g < groupCount; g++) {
        if (g > 0) chars.push(' ');
        for (let i = 0; i < groupSize; i++) {
            chars.push(effectiveKeySet[Math.floor(Math.random() * effectiveKeySet.length)]);
        }
    }
    return chars;
}

// ─── Keypress Handler ─────────────────────────────────────────────────────────
function handleDrillKey(e) {
    // Ignore modifier keys
    if (e.key === 'Shift' || e.key === 'Control' || e.key === 'Alt' || e.key === 'Meta') return;
    if (e.key === 'CapsLock') return;

    // ⚠️ SAME FIREFOX QUICK FIND FIX AS game.js 3.9.3. This handler is bound to
    // #drill-keyboard, which is a DIV — a div does not absorb keystrokes the way an
    // <input> does, so Firefox is still free to act on anything we do not cancel.
    // `'` opens Quick Find (links only) and `/` opens Quick Find, and lessons drill
    // punctuation deliberately. Cancel everything we consume; never cancel a
    // modifier combo, or Ctrl+R and Cmd+Tab stop working.
    if (!e.ctrlKey && !e.metaKey && !e.altKey &&
        (e.key.length === 1 || e.key === 'Tab' || e.key === 'Enter' ||
         e.key === 'Backspace')) {
        e.preventDefault();
    }

    const anchors = (currentStep?.anchorEnforced && currentLesson?.anchorKeys) || [];

    // Silently consume anchor key presses — but never block the key the drill
    // is currently asking for. key_pattern_auto adds home companions (e.g. d for e,
    // k for i) which appear in anchorKeys but must be typeable when required.
    if (anchors.length && e.key.length === 1 && anchors.includes(e.key.toLowerCase())) {
        const expectedNow = drillSequence[drillPos];
        if (e.key !== expectedNow) { e.preventDefault(); return; }
    }

    // Anchor key reminder is shown as a static hint (not reactive) — see beginStep()

    if (drillPos >= drillSequence.length) return;
    const expected = drillSequence[drillPos];

    // If in hard stop, only the correct key resumes — anything else is ignored
    if (drillIsHardStop) {
        const expected = drillSequence[drillPos];
        const typed = (e.key === 'Enter') ? '\n' : (e.key === 'Tab') ? '\t' : (e.key.length === 1 ? e.key : null);
        if (typed === expected) {
            drillIsHardStop = false;
            drillConsecutiveMistakes = 0;
            // Clear the hard stop overlay and re-enable timer
            const hsEl = document.getElementById('drill-hardstop');
            if (hsEl) hsEl.remove();
            clearInterval(timerInterval);
            startGradedTimer();
            learnLastInputTime = Date.now();
            // Now process the correct key normally
            flashFingerPressed(drillKeyboard);
            if (drillLetterStatus === 'clean')      drillCharStates[drillPos] = 'perfect';
            else if (drillLetterStatus === 'fixed') drillCharStates[drillPos] = 'fixed';
            else                                     drillCharStates[drillPos] = 'dirty';
            drillPos++;
            if (drillBackspaceOrigin >= 0 && drillPos <= drillBackspaceOrigin) {
                drillLetterStatus = 'fixed';
            } else { drillBackspaceOrigin = -1; drillLetterStatus = 'clean'; }
            renderDrillText();
            if (drillPos >= drillSequence.length) { finishStep(); return; }
            advanceHandGuide();
            updateHUD();
        }
        e.preventDefault(); return;
    }

    let typed = '';
    if (e.key === 'Enter')     typed = '\n';
    else if (e.key === 'Tab')  typed = '\t';
    else if (e.key === 'Backspace') {
        if (drillLetterStatus === 'error') {
            // First backspace: clear current error, become 'fixed'
            drillLetterStatus = 'fixed';
            if (drillBackspaceOrigin < 0) drillBackspaceOrigin = drillPos;
            renderDrillText(false);  // re-render without error highlight
        } else if (drillPos > 0) {
            // Additional backspaces: step back, mark status fixed
            if (drillBackspaceOrigin < 0) drillBackspaceOrigin = drillPos;
            drillPos--;
            drillLetterStatus = 'fixed';
            drillCharStates[drillPos] = 'upcoming'; // un-done the char we stepped back to
            renderDrillText();
            advanceHandGuide();
        }
        e.preventDefault(); return;
    } else if (e.key.length === 1) {
        typed = e.key;
    } else {
        e.preventDefault(); return;
    }
    e.preventDefault();

    // Idle-resume space skip: if the student was idle (> LEARN_IDLE_THRESHOLD)
    // and the current position is a space, skip it once so they don't have to
    // type a space as their first character back. During active typing every
    // space is required as normal.
    const wasIdle = learnLastInputTime > 0 && (Date.now() - learnLastInputTime) > LEARN_IDLE_THRESHOLD;
    if (wasIdle && drillPos < drillSequence.length && drillSequence[drillPos] === ' ') {
        drillPos++;
        if (drillPos >= drillSequence.length) { finishStep(); return; }
    }
    const newExpected = drillSequence[drillPos];

    chars++;
    if (typed === newExpected) {
        flashFingerPressed(drillKeyboard);
        drillConsecutiveMistakes = 0; // reset on any correct key
        learnLastInputTime = Date.now();
        statsData.charsToday++;  statsData.charsWeek++;

        if (drillLetterStatus === 'clean')       drillCharStates[drillPos] = 'perfect';
        else if (drillLetterStatus === 'fixed')  drillCharStates[drillPos] = 'fixed';
        else                                     drillCharStates[drillPos] = 'dirty';

        drillPos++;

        // Keep 'fixed' status until we re-pass the backspace origin
        if (drillBackspaceOrigin >= 0 && drillPos <= drillBackspaceOrigin) {
            drillLetterStatus = 'fixed';
        } else {
            drillBackspaceOrigin = -1;
            drillLetterStatus = 'clean';
        }

        renderDrillText();
        if (drillPos >= drillSequence.length) {
            finishStep();
            return;
        }
        // Checkpoint the run every few characters so the bell can't erase it.
        if (drillPos % 5 === 0) saveRunPosition();
        advanceHandGuide();
    } else {
        mistakes++;
        drillConsecutiveMistakes++;
        learnLastInputTime = Date.now();
        statsData.mistakesToday++; statsData.mistakesWeek++;
        if (newExpected !== ' ') {
            missedChars[newExpected] = (missedChars[newExpected] || 0) + 1;
        }
        if (drillLetterStatus === 'clean') drillLetterStatus = 'error';
        flashTargetKey();
        renderDrillText(true);

        // v2.0.0 removed a `learnLastInputTime = 0` here. Its comment said it
        // stopped the clock at DRILL_STOP_TIME_THRESHOLD to protect the score, but
        // learnLastInputTime drives the *time-on-task* counter, not the graded one.
        // The effect was that a struggling student stopped earning credit toward
        // their daily goal while the graded clock kept running — penalised twice,
        // protected never. The graded clock now pauses on idle (startGradedTimer)
        // and the hard stop below stops it outright, so nothing is left to do here.

        if (!ggAllowMistakes && drillConsecutiveMistakes >= DRILL_SPAM_THRESHOLD) {
            const stepIdx = currentStepIdx;
            clearInterval(timerInterval);
            clearInterval(learnTickInterval);
            const hsEl = document.getElementById('drill-hardstop');
            if (hsEl) hsEl.remove();
            setTimeout(() => beginStep(stepIdx), 400);
            return;
        }
        if (!ggAllowMistakes && drillConsecutiveMistakes >= DRILL_HARD_STOP_THRESHOLD) {
            drillIsHardStop = true;
            clearInterval(timerInterval);
            _showHardStopOverlay(newExpected);
        }
    }
    updateHUD();
}

// Maintain a set of currently held keys
const heldKeys = new Set();
window.addEventListener('keydown', e => { if (e.key.length === 1) heldKeys.add(e.key.toLowerCase()); });
window.addEventListener('keyup',   e => { if (e.key.length === 1) heldKeys.delete(e.key.toLowerCase()); });



function flashTargetKey() {
    const expected = drillSequence[drillPos];
    if (!expected) return;
    const info = getFingerInfo(fingerMap, expected);
    if (!info) return;
    const el = document.getElementById(`key-${info.keyChar}`);
    if (!el) return;
    const orig = el.style.backgroundColor;
    el.style.backgroundColor = '#c62828';
    setTimeout(() => { el.style.backgroundColor = orig; }, 200);
}

// ─── Render Drill Text ────────────────────────────────────────────────────────
function renderDrillText(showError = false) {
    const seq = drillSequence;

    // Render exactly like the book: every character (including space) is the same
    // .dt-char inline-block span with identical min-width and padding.
    // State classes change color only — never dimensions.
    // Groups of non-space chars are wrapped in a nowrap container so CSS
    // line-wrapping never splits a group mid-character. Each trailing space
    // is attached to the end of its preceding group so lines never start
    // with a bare space.

    // Build groups: each group is a run of chars ending with optional space
    const groups = [];
    let cur = [];
    seq.forEach((ch, i) => {
        cur.push({ch, i});
        if (ch === ' ') {
            groups.push(cur);
            cur = [];
        }
    });
    if (cur.length) groups.push(cur);

    let html = '';
    groups.forEach(group => {
        // Wrap group in nowrap so it never splits across lines
        html += '<span style="display:inline-block;white-space:nowrap;">';
        group.forEach(({ch, i}) => {
            // Space displays as &nbsp; — invisible but identical width to any letter
            const disp = (ch === ' ') ? '&nbsp;' : (ch === '\n' ? '↵' : escHtml(ch));
            let cls;
            if (i === drillPos) {
                const errClass = (showError || drillLetterStatus === 'error') ? 'dt-error' : 'dt-current';
                cls = 'dt-char ' + errClass;
                html += '<span class="' + cls + '" id="dt-cursor">' + disp + '</span>';
                return;
            }
            const state = drillCharStates[i] || 'upcoming';
            if      (state === 'perfect')  cls = 'dt-char dt-done';
            else if (state === 'fixed')    cls = 'dt-char dt-fixed';
            else if (state === 'dirty')    cls = 'dt-char dt-dirty';
            else                           cls = 'dt-char dt-upcoming';
            // Spaces: add background-tint class so the state is visible (text is invisible)
            if (ch === ' ' && state === 'fixed') cls += ' dt-space-fixed';
            if (ch === ' ' && state === 'dirty') cls += ' dt-space-dirty';
            html += '<span class="' + cls + '">' + disp + '</span>';
        });
        html += '</span>';
    });

    drillTextEl.innerHTML = html;

    // Scroll cursor into view
    requestAnimationFrame(() => {
        centerDrillView();
    });
}

// ─── Center current character vertically — mirrors game.js centerView() ───────
function centerDrillView() {
    const cursor  = document.getElementById('dt-cursor');
    const textEl  = drillTextEl;
    const areaEl  = document.getElementById('drill-text-area');
    if (!cursor || !textEl || !areaEl) return;
    const cursorTop  = cursor.offsetTop;
    const areaHeight = areaEl.clientHeight;
    const targetTop  = Math.round(areaHeight / 2 - cursorTop - cursor.offsetHeight / 2);
    textEl.style.top = targetTop + 'px';
}


function advanceHandGuide() {
    if (drillPos >= drillSequence.length) return;
    const ch = drillSequence[drillPos];
    setHandGuideToChar(drillKeyboard, fingerMap, LAYOUT, ch);
    const info = getFingerInfo(fingerMap, ch);
    toggleKeyboardCase(drillKeyboard, info?.shift || false);

    // Highlight target key. Space bar uses space-active only (shows thumb circles).
    // 'target' is for letter keys only — adding it to space caused persistent dots.
    // Clear space-active only when moving away from a space, not when landing on one
    if (ch !== ' ') {
        const spaceKey = drillKeyboard.querySelector('.key.space');
        if (spaceKey) spaceKey.classList.remove('space-active', 'space-pressed');
    }

    drillKeyboard.querySelectorAll('.key').forEach(k => k.classList.remove('target'));
    if (ch !== ' ' && info) {
        const el = Array.from(drillKeyboard.querySelectorAll('[data-char]'))
            .find(k => k.dataset.char === info.keyChar);
        if (el) el.classList.add('target');
    }
    // space-active is set by setHandGuideToChar (called above) — no extra work needed

    // Space bar cue: show a small hint so students don't wonder what to press
    const spaceHint = document.getElementById('space-hint');
    if (spaceHint) spaceHint.style.visibility = (ch === ' ') ? 'visible' : 'hidden';
}

// ─── HUD ─────────────────────────────────────────────────────────────────────
// `chars` counts every keystroke including wrong ones, because that is the correct
// denominator for accuracy. It was also the WPM numerator, which meant errors
// *raised* reported speed: three deliberate mistakes could turn a failing 14 WPM
// perfect run into a passing 15 WPM one. WPM is now net — correct keystrokes only.
function netWPM() {
    if (stepSeconds <= 0) return 0;
    const correct = Math.max(0, chars - mistakes);
    return Math.round((correct / 5) / (stepSeconds / 60));
}
function accuracyPct() {
    return chars > 0 ? Math.round(((chars - mistakes) / chars) * 100) : 100;
}

function updateHUD() {
    wpmDisplay.textContent = netWPM();
    accDisplay.textContent = accuracyPct() + '%';
}

// ─── Finish Step ─────────────────────────────────────────────────────────────
function finishStep() {
    clearInterval(timerInterval);
    clearInterval(learnTickInterval);
    drillKeyboard.onkeydown = null;
    const spaceHint = document.getElementById('space-hint');
    if (spaceHint) spaceHint.style.visibility = 'hidden';
    const anchorHint = document.getElementById('anchor-hint');
    if (anchorHint) anchorHint.style.display = 'none';
    saveStats(); // write time to Firestore

    const wpm = netWPM();
    const acc = accuracyPct();

    const isLastRun = currentStepIdx >= currentRuns.length - 1;

    if (isLastRun) {
        showLessonResultModal(wpm, acc);
    } else {
        showStepModal(wpm, acc, currentStepIdx + 1, currentRuns.length);
    }
}

function showStepModal(wpm, acc, nextIdx, totalSteps) {
    drillModal.classList.remove('hidden');
    document.getElementById('drill-keyboard-wrap').style.display = 'none';

    const gates    = gatesForRun(currentStep);
    const minWPM   = gates.minWPM;
    const minAcc   = gates.minAccuracy;
    const grade    = calculateGrade(wpm, acc, minWPM, minAcc, mistakes === 0);
    const canAdvance = gradeAdvances(grade, gates);

    // On a successful run the position checkpoint is stale — drop it so a resume
    // never lands back inside a run the student already cleared.
    if (canAdvance) clearRunPosition();

    recordRunOutcome(currentStepIdx, grade, canAdvance);

    document.getElementById('dm-title').textContent = 'Step ' + nextIdx + ' of ' + totalSteps + ' done';
    document.getElementById('dm-stars').innerHTML = gradeHTML(grade);

    const dailyBadge = (goals.dailySeconds > 0 && statsData.secondsToday >= goals.dailySeconds)
        ? '<span class="goal-badge goal-blue">\u2713</span>' : '';
    const weeklyBadge = (goals.weeklySeconds > 0 && statsData.secondsWeek >= goals.weeklySeconds)
        ? '<span class="goal-badge goal-blue">\u2713</span>' : '';

    // The target shown is the one actually being enforced. On a key drill that is
    // accuracy, and no WPM target is shown at all — displaying a number the run is
    // not graded on is what taught students to chase the wrong thing.
    document.getElementById('dm-stats').innerHTML =
        '<div class="dm-stat"><div class="dm-val">' + wpm + '</div><div class="dm-label">WPM</div></div>' +
        '<div class="dm-stat"><div class="dm-val">' + acc + '%</div><div class="dm-label">Accuracy</div></div>' +
        '<div class="dm-stat"><div class="dm-val" style="font-size:1.4rem;">' + minAcc + '%+</div>' +
        '<div class="dm-label">Target</div></div>' +
        (minWPM != null
            ? '<div class="dm-stat"><div class="dm-val" style="font-size:1.4rem;">' + minWPM + '+</div>' +
              '<div class="dm-label">Target WPM</div></div>'
            : '');

    const stepMsg = getGradeMessage(wpm, acc, minWPM, minAcc, grade);
    const hint = canAdvance
        ? '<span style="color:#888;font-size:0.8rem;font-family:monospace;">press Enter to continue</span>'
        : '<span style="color:#e65100;font-size:0.85rem;">' + escHtml(stepMsg) + ' (Enter to try again)</span>';
    document.getElementById('dm-msg').innerHTML =
        '<div class="cumulative-row" style="font-size:0.78rem;margin-bottom:4px;">' +
        dailyBadge + '<span>Today: ' + formatTime(statsData.secondsToday) + '</span>' +
        '<span class="cumulative-sep">|</span>' +
        '<span>This week: ' + formatTime(statsData.secondsWeek) + '</span>' +
        weeklyBadge + '</div>' + hint;
    document.getElementById('dm-remediation').innerHTML = '';

    const btns = document.getElementById('dm-btns');
    btns.innerHTML = '';

    // Define handler ONCE (not inside if/else) to avoid hoisting issues
    // that cause stale listeners to accumulate across steps
    var stepAction = null;
    function stepKeyHandler(e) {
        if (e.key === 'Enter') { e.preventDefault(); if (stepAction) stepAction(); }
    }
    document.addEventListener('keydown', stepKeyHandler);

    function cleanup() {
        document.removeEventListener('keydown', stepKeyHandler);
        drillModal.classList.add('hidden');
        document.getElementById('drill-keyboard-wrap').style.display = '';
    }

    const mapBtn = document.createElement('button');
    mapBtn.className = 'dm-btn-secondary'; mapBtn.textContent = '\u2190 Map';
    mapBtn.onclick = function() { cleanup(); stopLesson(); };
    btns.appendChild(mapBtn);

    if (canAdvance) {
        const next = document.createElement('button');
        next.className = 'dm-btn-primary'; next.textContent = 'Next Step \u2192 (Enter)';
        stepAction = function() { cleanup(); beginStep(nextIdx); };
        next.onclick = stepAction;
        btns.appendChild(next);
    } else {
        const retry = document.createElement('button');
        retry.className = 'dm-btn-primary'; retry.textContent = 'Try Again (Enter)';
        stepAction = function() { cleanup(); beginStep(nextIdx - 1); };
        retry.onclick = stepAction;
        btns.appendChild(retry);
    }
}

function showLessonResultModal(wpm, acc) {
    const gates  = gatesForRun(currentStep);
    const minWPM = gates.minWPM;
    const minAcc = gates.minAccuracy;

    const grade  = calculateGrade(wpm, acc, minWPM, minAcc, mistakes === 0);
    const passed = gradeAdvances(grade, gates);
    if (passed) clearRunPosition();

    // Record the run BEFORE saveProgress, so the cumulative time and run maps it
    // spreads forward already include this run.
    recordRunOutcome(currentStepIdx, grade, passed);

    // v2.0.0: an F now writes a record too. It previously wrote nothing, so the
    // students in the most trouble were the ones who left no trace at all.
    const countsAsTime = true;

    // Hint toward next grade
    const gradeHint = getGradeMessage(wpm, acc, minWPM, minAcc, grade);
    if (currentUser && countsAsTime) {
        saveProgress(passed, wpm, acc, grade);
    } else if (!currentUser && countsAsTime) {
        // Accumulate anon lesson progress for retroactive save on sign-in
        anonLessonsCompleted++;
        const GRADE_ORDER = ['F','D','C','B','A', FIRE_GRADE];
        const prev = anonLessonProgress[currentLesson.id];
        const prevGrade = prev ? (prev.grade || 'F') : 'F';
        const bestGrade = GRADE_ORDER.indexOf(grade) > GRADE_ORDER.indexOf(prevGrade) ? grade : prevGrade;
        anonLessonProgress[currentLesson.id] = {
            lessonId: currentLesson.id,
            completedAt: new Date().toISOString(),
            attempts: (prev ? prev.attempts || 0 : 0) + 1,
            finalWPM: wpm, finalAccuracy: acc,
            timeSpentSeconds: (prev ? prev.timeSpentSeconds || 0 : 0) + stepSeconds,
            passed: passed || (prev ? prev.passed || false : false),
            grade: bestGrade,
            stars: bestGrade === FIRE_GRADE || bestGrade === 'A' ? 3 : bestGrade === 'B' ? 2 : bestGrade === 'C' ? 1 : 0,
        };
        checkAnonLoginPrompt();
    }

    drillModal.classList.remove('hidden');
    document.getElementById('drill-keyboard-wrap').style.display = 'none';

    var titleMap = {};
    titleMap[FIRE_GRADE] = String.fromCodePoint(0x1F525) + ' On Fire!';
    titleMap['A']     = '\uD83C\uDF89 Excellent!';
    titleMap['B']     = '\u2713 Lesson Complete!';
    titleMap['C']     = '\u2713 Lesson Complete!';
    titleMap['D']     = 'Almost \u2014 Try Once More';
    titleMap['F']     = 'Not Yet';
    document.getElementById('dm-title').textContent = titleMap[grade] || 'Done';
    document.getElementById('dm-stars').innerHTML = gradeHTML(grade);
    const rdBadge = (goals.dailySeconds > 0 && statsData.secondsToday >= goals.dailySeconds)
        ? '<span class="goal-badge goal-blue" title="Daily goal!">✓</span>' : '';
    const rwBadge = (goals.weeklySeconds > 0 && statsData.secondsWeek >= goals.weeklySeconds)
        ? '<span class="goal-badge goal-blue" title="Weekly goal!">✓</span>' : '';
    document.getElementById('dm-stats').innerHTML =
        rdBadge +
        '<div class="dm-stat"><div class="dm-val">' + wpm + '</div><div class="dm-label">WPM</div></div>' +
        '<div class="dm-stat"><div class="dm-val">' + acc + '%</div><div class="dm-label">Accuracy</div></div>' +
        '<div class="dm-stat"><div class="dm-val" style="font-size:1.4rem;">' + minAcc + '%+</div><div class="dm-label">Target</div></div>' +
        (minWPM != null
            ? '<div class="dm-stat"><div class="dm-val" style="font-size:1.4rem;">' + minWPM + '+</div><div class="dm-label">Target WPM</div></div>'
            : '') +
        rwBadge;

    const msg = 'You got ' + wpm + ' WPM at ' + acc + '% accuracy.' + (gradeHint ? ' ' + gradeHint : '');
    document.getElementById('dm-msg').innerHTML =
        escHtml(msg) +
        '<div class="cumulative-row" style="font-size:0.78rem;margin-top:4px;">' +
        '<span>Today: ' + formatTime(statsData.secondsToday) + '</span>' +
        '<span class="cumulative-sep">|</span>' +
        '<span>This week: ' + formatTime(statsData.secondsWeek) + '</span>' +
        '</div>';

    // Remediation links for missed chars
    const remMissedKeys = Object.entries(missedChars)
        .filter(([ch, n]) => n >= 3).sort((a,b) => b[1]-a[1]).slice(0,3).map(([ch]) => ch);
    const remText = buildRemediationLinks();
    document.getElementById('dm-remediation').innerHTML = remText;
    // Wire all interactive elements after HTML is inserted
    const pracBtn = document.getElementById('practice-missed-btn');
    if (pracBtn) pracBtn.onclick = () => window._practiceMissedKeys(remMissedKeys);
    document.querySelectorAll('#dm-remediation a[data-lesson-id]').forEach(a => {
        a.href = '#';
        a.onclick = e => { e.preventDefault(); window._gotoLesson(a.dataset.lessonId); };
    });

    const btns = document.getElementById('dm-btns');
    btns.innerHTML = '';

    // Enter key shortcut for primary action
    const enterResultHandler = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            document.removeEventListener('keydown', enterResultHandler);
            primaryAction();
        }
    };
    document.addEventListener('keydown', enterResultHandler);

    let primaryAction;
    if (passed) {
        const nextLesson = getNextLesson();
        primaryAction = () => {
            document.removeEventListener('keydown', enterResultHandler);
            if (nextLesson) { startLesson(nextLesson); }
            else { window.location.href = 'index.html'; }
        };
        const nextBtn = document.createElement('button');
        nextBtn.className = 'dm-btn-primary';
        nextBtn.textContent = nextLesson ? 'Next Lesson → (Enter)' : '📚 Go to Library';
        nextBtn.onclick = primaryAction;
        const mapBtnP = document.createElement('button');
        mapBtnP.className = 'dm-btn-secondary'; mapBtnP.textContent = '← Map';
        mapBtnP.onclick = () => {
            document.removeEventListener('keydown', enterResultHandler);
            stopLesson();
        };
        btns.appendChild(mapBtnP); // left
        btns.appendChild(nextBtn); // right
    } else {
        // v2.0.0: retry THIS run. The old code called startLesson(), which reset
        // currentStepIdx to 0 and replayed the intro \u2014 so missing the gate on the
        // last step of a five-step lesson meant redoing all five. At a 50% per-run
        // pass rate that turned a 5-run lesson into ~18 runs of work.
        const retryIdx = currentStepIdx;
        primaryAction = () => {
            document.removeEventListener('keydown', enterResultHandler);
            drillModal.classList.add('hidden');
            document.getElementById('drill-keyboard-wrap').style.display = '';
            beginStep(retryIdx);
        };
        const retryBtn = document.createElement('button');
        retryBtn.className = 'dm-btn-primary'; retryBtn.textContent = 'Try Again (Enter)';
        retryBtn.onclick = primaryAction;
        const mapBtnF = document.createElement('button');
        mapBtnF.className = 'dm-btn-secondary'; mapBtnF.textContent = '← Map';
        mapBtnF.onclick = () => {
            document.removeEventListener('keydown', enterResultHandler);
            stopLesson();
        };
        btns.appendChild(mapBtnF); // left
        btns.appendChild(retryBtn); // right
    }
}

function buildRemediationLinks() {
    const top = Object.entries(missedChars)
        .filter(([ch, n]) => n >= 3)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3);
    if (!top.length) return '';

    const missedKeys = top.map(([ch]) => ch);

    const links = top.map(([ch]) => {
        const introLesson = allLessons.find(l => (l.newKeys || []).includes(ch));
        if (!introLesson) return null;
        return '<a href="#" data-lesson-id="' + introLesson.id + '">' + ch.toUpperCase() + ' (' + escHtml(introLesson.title) + ')</a>';
    }).filter(Boolean);

    const linkText = links.length
        ? 'You often missed: ' + links.join(', ') + ' — revisit these?'
        : '';

    // Practice button — store keys in data attribute to avoid quoting nightmares
    const practiceBtn = '<button class="dm-btn-secondary" style="margin-top:6px;width:100%;font-size:0.8rem;padding:7px;" '
        + 'id="practice-missed-btn">🎲 Practice missed keys</button>';

    return linkText + practiceBtn;
}

window._practiceMissedKeys = function(missedKeys) {
    if (!missedKeys || !missedKeys.length) return;
    // Build a synthetic key_random step from the missed keys
    const syntheticStep = {
        id: 'remediation',
        label: 'Practice: ' + missedKeys.map(k => k.toUpperCase()).join(' '),
        type: 'key_random',
        keySet: missedKeys,
        groupSize: 5,
        groupCount: 14,
        anchorEnforced: false,
    };
    drillModal.classList.add('hidden');
    document.getElementById('drill-keyboard-wrap').style.display = '';
    // v2.0.0: replace the run list rather than mutating currentLesson.steps. The old
    // swap-and-restore worked only because beginStep read steps synchronously; runs
    // make the intent explicit and leave the lesson object alone. Chunked in case
    // the missed-key set produces a long drill.
    currentRuns = chunkSequence(buildSequence(syntheticStep)).map((seq, i, all) => ({
        stepId: 'remediation', stepIdx: 0, chunkIdx: i, chunkCount: all.length,
        type: syntheticStep.type, anchorEnforced: false, gates: null, sequence: seq,
        label: syntheticStep.label + (all.length > 1 ? ` (${i + 1}/${all.length})` : ''),
    }));
    clearRunPosition();   // a remediation detour must not resurrect a lesson position
    beginStep(0);
};

window._gotoLesson = function(id) {
    const lesson = allLessons.find(l => l.id === id);
    if (lesson) startLesson(lesson);
};

// ─── Progress Persistence ────────────────────────────────────────────────────
// ─── Run-level instrumentation (v2.1.0, Batch B) ─────────────────────────────
// Before this, lessonProgress was written from exactly one place: the final run's
// result modal, and only when the grade wasn't F. A student stuck on run 2 of 12
// therefore wrote NOTHING — and rendered in the admin per-student grid as
// "not started", indistinguishable from a student who never opened the lesson. The
// failure mode the whole audit was about was the one the data couldn't show.
//
// Writes are queued, not immediate. learn.js v1.7.0 was explicitly a write-reduction
// release, and firing a document write on all 176 runs would undo it. These ride the
// existing coalesced flush (5-min timer, visibilitychange, beforeunload), so the
// added Firestore cost is zero writes per run and one merge per lesson per flush.
//
// Counters are computed from userProgress, which loadProgress() already populated at
// page load, so no extra reads either. Two devices at once would clobber rather than
// sum — same as the pre-existing attempts counter, and not worth a transaction.
const pendingProgress = new Set();   // lessonIds with unflushed run data

function recordRunOutcome(runIdx, grade, advanced) {
    if (!currentLesson) return;
    const id   = currentLesson.id;
    const prev = userProgress[id] || {};
    const key  = String(runIdx);

    const runAttempts = Object.assign({}, prev.runAttempts);
    const runFailures = Object.assign({}, prev.runFailures);
    runAttempts[key] = (runAttempts[key] || 0) + 1;
    if (!advanced) runFailures[key] = (runFailures[key] || 0) + 1;

    userProgress[id] = Object.assign({}, prev, {
        lessonId: id,
        started: true,
        runCount: currentRuns.length,
        // runCount is stored so a stale map is detectable: editing a lesson changes
        // how it chunks, which shifts every index in runAttempts/runFailures.
        furthestRunIdx: Math.max(prev.furthestRunIdx || 0, runIdx),
        lastRunIdx: runIdx,
        lastGrade: grade,
        lastSeenAt: new Date().toISOString(),
        runAttempts,
        runFailures,
        // The real cumulative figure. timeSpentSeconds previously added only the
        // final run's stepSeconds, so it undercounted by the whole rest of the lesson.
        timeSpentSeconds: (prev.timeSpentSeconds || 0) + stepSeconds,
    });

    pendingProgress.add(id);
    learnDirty = true;
    learnWalSave();
}

async function flushLessonProgress() {
    if (!currentUser || pendingProgress.size === 0) return true;
    let ok = true;
    for (const id of Array.from(pendingProgress)) {
        const rec = userProgress[id];
        if (!rec) { pendingProgress.delete(id); continue; }
        try {
            await setDoc(doc(db, 'users', currentUser.uid, 'lessonProgress', id),
                         rec, { merge: true });
            pendingProgress.delete(id);
        } catch (e) { ok = false; console.warn('Lesson progress flush failed:', e); }
    }
    return ok;
}

async function saveProgress(passed, wpm, acc, grade) {
    if (!currentUser || !currentLesson) return;
    const prev = userProgress[currentLesson.id] || {};
    const attempts  = (prev.attempts || 0) + 1;
    // NOT prev + stepSeconds: recordRunOutcome already added this run's seconds to
    // prev.timeSpentSeconds a moment ago. Adding again would double-count the final run.
    const timeSpent = prev.timeSpentSeconds || 0;

    // Keep best grade seen — order: F D C B A A🔥
    const GRADE_ORDER = ['F','D','C','B','A','A🔥'];
    const prevGrade   = prev.grade || 'F';
    const bestGrade   = GRADE_ORDER.indexOf(grade) > GRADE_ORDER.indexOf(prevGrade) ? grade : prevGrade;

    const record = {
        // Spread prev first so the run-level fields written by recordRunOutcome
        // survive. saveProgress used setDoc WITHOUT merge, so completing a lesson
        // would otherwise wipe runAttempts/runFailures/furthestRunIdx on the way past.
        ...prev,
        lessonId: currentLesson.id,
        completedAt: new Date().toISOString(),
        attempts,
        finalWPM: wpm,
        finalAccuracy: acc,
        timeSpentSeconds: timeSpent,
        passed: passed || prev.passed || false,
        grade: bestGrade,
        // Keep stars field for backward compat with old progress records
        stars: bestGrade === 'A🔥' ? 3 : bestGrade === 'A' ? 3 : bestGrade === 'B' ? 2 : bestGrade === 'C' ? 1 : 0,
    };

    // Leap detection flag
    const prevWPM = prev.finalWPM || 0;
    if (prevWPM > 0 && wpm > prevWPM * 1.5) record.leapFlagged = true;

    try {
        await setDoc(
            doc(db, 'users', currentUser.uid, 'lessonProgress', currentLesson.id),
            record, { merge: true }
        );
        userProgress[currentLesson.id] = record;
        pendingProgress.delete(currentLesson.id);   // this write covered it
    } catch(e) { console.warn('Could not save lesson progress:', e); }
}

// ─── Navigation ──────────────────────────────────────────────────────────────
function showView(which) {
    mapView.classList.toggle('hidden', which !== 'map');
    drillView.classList.toggle('hidden', which !== 'drill');
}

function stopLesson() {
    clearInterval(timerInterval);
    clearInterval(learnTickInterval);
    stopIntroAnim();
    drillKeyboard.onkeydown = null;
    currentLesson = null;
    backBtn.href = 'index.html'; backBtn.onclick = null;
    hudLessonLabel.textContent = '';
    document.getElementById('drill-keyboard-wrap').style.display = '';
    drillModal.classList.add('hidden');
    wpmDisplay.textContent = '—';
    accDisplay.textContent = '—';
    loadUserProgress().then(() => {
        renderMap();
        showView('map');
    });
}

function getNextLesson() {
    if (!currentLesson) return null;
    const idx = allLessons.findIndex(l => l.id === currentLesson.id);
    return allLessons[idx + 1] || null;
}

// ─── Save stats on page unload ───────────────────────────────────────────────
// Ensures time typed in School is persisted even if student navigates away
// mid-lesson without completing a step (which is when saveStats() normally fires).

// ─── LEARN GAME GENIE (admin only) ───────────────────────────────────────────
function openLearnGenie() {
    if (!currentUser || !ADMIN_EMAILS.includes(currentUser.email)) return;

    // Pause the drill timer while panel is open
    clearInterval(timerInterval);
    clearInterval(learnTickInterval);
    if (drillKeyboard) drillKeyboard.onkeydown = null;

    const lesson    = currentLesson;
    const stepIdx   = currentStepIdx;
    // Runs, not authored steps — beginStep() indexes currentRuns, so the jump list
    // has to match or the genie sends you to the wrong place in a chunked lesson.
    const steps     = (lesson && currentRuns.length) ? currentRuns
                    : (lesson ? buildRunList(lesson) : []);
    const onDrill   = !drillView.classList.contains('hidden');

    const ggS = 'background:#1a1a1a;color:#ff6600;border:1px solid #ff6600;' +
                'padding:4px 10px;cursor:pointer;border-radius:3px;font-family:monospace;' +
                'font-size:0.8em;font-weight:bold;margin:2px;';
    const ggT = 'color:#888;font-size:0.7em;margin-bottom:3px;font-family:monospace;';

    // Lesson dropdown
    const lessonOpts = allLessons.map(l => {
        const prog    = userProgress[l.id] || {};
        const grade   = prog.grade || (prog.passed ? 'B' : '');
        const sel     = lesson && l.id === lesson.id ? ' selected' : '';
        return '<option value="' + l.id + '"' + sel + '>' +
               'U' + l.unit + 'L' + l.lesson + ' ' + escHtml(l.title || l.id) +
               (grade ? ' [' + grade + ']' : '') + '</option>';
    }).join('');

    // Step dropdown
    const stepOpts = steps.map((s, i) =>
        '<option value="' + i + '"' + (i === stepIdx ? ' selected' : '') + '>' +
        'Run ' + (i+1) + ': ' + escHtml(s.label || s.stepId || '') + '</option>'
    ).join('');

    drillModal.classList.remove('hidden');
    document.getElementById('drill-keyboard-wrap').style.display = 'none';
    document.getElementById('dm-title').textContent = '\uD83D\uDD25 GAME GENIE \uD83D\uDD25';
    document.getElementById('dm-stars').innerHTML = '';
    document.getElementById('dm-remediation').innerHTML = '';

    document.getElementById('dm-stats').innerHTML =
        '<div style="font-size:0.75rem;color:#888;font-family:monospace;">' +
        (lesson ? escHtml(lesson.title || lesson.id) : 'No lesson active') +
        (onDrill ? ' — Step ' + (stepIdx+1) + '/' + steps.length : '') +
        '</div>';

    document.getElementById('dm-msg').innerHTML =
        '<div style="font-family:monospace;font-size:0.82em;text-align:left;max-width:420px;margin:0 auto;">' +

        // Lesson jump
        '<div style="margin-bottom:10px;">' +
        '<div style="' + ggT + '">WARP TO LESSON</div>' +
        '<div style="display:flex;gap:4px;align-items:center;">' +
        '<select id="gg-lesson-select" style="flex:1;background:#222;color:#eee;border:1px solid #555;padding:3px 4px;font-family:monospace;font-size:0.82em;border-radius:3px;">' + lessonOpts + '</select>' +
        '<button id="gg-lesson-go" style="' + ggS + '">WARP</button>' +
        '</div>' +
        '</div>' +

        // Step jump (only when on a drill)
        (onDrill && steps.length > 1 ?
        '<div style="margin-bottom:10px;">' +
        '<div style="' + ggT + '">JUMP TO STEP</div>' +
        '<div style="display:flex;gap:4px;align-items:center;">' +
        '<select id="gg-step-select" style="flex:1;background:#222;color:#eee;border:1px solid #555;padding:3px 4px;font-family:monospace;font-size:0.82em;border-radius:3px;">' + stepOpts + '</select>' +
        '<button id="gg-step-go" style="' + ggS + '">GO</button>' +
        '</div>' +
        '</div>' : '') +

        // Lock / unlock current lesson
        (lesson ?
        '<div style="margin-bottom:10px;">' +
        '<div style="' + ggT + '">CURRENT LESSON PROGRESS</div>' +
        '<div style="display:flex;gap:4px;flex-wrap:wrap;">' +
        '<button id="gg-unlock" style="' + ggS + '" title="Mark as passed (grade B)">\u2713 UNLOCK (mark passed)</button>' +
        '<button id="gg-lock" style="' + ggS + 'color:#ff4444;border-color:#ff4444;" title="Delete progress record">\u2717 LOCK (remove progress)</button>' +
        '</div>' +
        '</div>' : '') +

        // Toggles
        '<div style="margin-bottom:10px;">' +
        '<div style="' + ggT + '">TOGGLES</div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
        '<label style="display:flex;align-items:center;gap:3px;font-size:0.78em;color:' + (ggAllowMistakes ? '#ff6600' : '#888') + ';cursor:pointer;">' +
        '<input type="checkbox" id="gg-allow-mistakes"' + (ggAllowMistakes ? ' checked' : '') + '> Mistakes OK</label>' +
        '<label style="display:flex;align-items:center;gap:3px;font-size:0.78em;color:' + (ggBypassIdle ? '#ff6600' : '#888') + ';cursor:pointer;">' +
        '<input type="checkbox" id="gg-bypass-idle"' + (ggBypassIdle ? ' checked' : '') + '> No Idle</label>' +
        '</div>' +
        '</div>' +

        '</div>';

    const btns = document.getElementById('dm-btns');
    btns.innerHTML = '';

    function closeGenie() {
        drillModal.classList.add('hidden');
        document.getElementById('drill-keyboard-wrap').style.display = '';
        // Resume if on a drill
        if (onDrill && !drillView.classList.contains('hidden')) {
            startGradedTimer();
            learnTickInterval = setInterval(() => {
                if (!learnLastInputTime) return;
                if (!ggBypassIdle && Date.now() - learnLastInputTime >= LEARN_IDLE_THRESHOLD) return;
                learnActiveSeconds++;
                statsData.secondsToday++; statsData.secondsWeek++;
                if (hudTimer) {
                    const m = Math.floor(statsData.secondsToday/60), s = statsData.secondsToday%60;
                    hudTimer.textContent = m + ':' + String(s).padStart(2,'0');
                }
            }, 1000);
            drillKeyboard.onkeydown = handleDrillKey;
            drillKeyboard.focus();
        }
    }

    const closeBtn = document.createElement('button');
    closeBtn.className = 'dm-btn-secondary'; closeBtn.textContent = 'Close (Esc)';
    closeBtn.onclick = closeGenie;
    btns.appendChild(closeBtn);

    function genieEscHandler(e) {
        if (e.key === 'Escape') { document.removeEventListener('keydown', genieEscHandler); closeGenie(); }
    }
    document.addEventListener('keydown', genieEscHandler);

    // Wire lesson warp
    const lessonGoBtn = document.getElementById('gg-lesson-go');
    if (lessonGoBtn) lessonGoBtn.onclick = () => {
        const id = document.getElementById('gg-lesson-select').value;
        const target = allLessons.find(l => l.id === id);
        if (target) { document.removeEventListener('keydown', genieEscHandler); closeGenie(); startLesson(target); }
    };

    // Wire step jump
    const stepGoBtn = document.getElementById('gg-step-go');
    if (stepGoBtn) stepGoBtn.onclick = () => {
        const idx = parseInt(document.getElementById('gg-step-select').value);
        document.removeEventListener('keydown', genieEscHandler);
        drillModal.classList.add('hidden');
        document.getElementById('drill-keyboard-wrap').style.display = '';
        beginStep(idx);
    };

    // Unlock
    const unlockBtn = document.getElementById('gg-unlock');
    if (unlockBtn) unlockBtn.onclick = async () => {
        if (!currentUser || !lesson) return;
        const record = { lessonId: lesson.id, completedAt: new Date().toISOString(),
            passed: true, grade: 'B', adminOverride: true,
            attempts: 1, finalWPM: 0, finalAccuracy: 0, timeSpentSeconds: 0 };
        await setDoc(doc(db, 'users', currentUser.uid, 'lessonProgress', lesson.id), record, { merge: true });
        userProgress[lesson.id] = record;
        unlockBtn.textContent = '\u2713 UNLOCKED';
        unlockBtn.style.color = '#22c55e'; unlockBtn.style.borderColor = '#22c55e';
    };

    // Lock
    const lockBtn = document.getElementById('gg-lock');
    if (lockBtn) lockBtn.onclick = async () => {
        if (!currentUser || !lesson) return;
        if (!confirm('Remove progress for "' + (lesson.title || lesson.id) + '"?')) return;
        await deleteDoc(doc(db, 'users', currentUser.uid, 'lessonProgress', lesson.id));
        delete userProgress[lesson.id];
        lockBtn.textContent = '\u2717 LOCKED'; lockBtn.style.color = '#888'; lockBtn.style.borderColor = '#888';
    };

    // Toggles
    const mistakesBox = document.getElementById('gg-allow-mistakes');
    if (mistakesBox) mistakesBox.onchange = () => { ggAllowMistakes = mistakesBox.checked; };
    const idleBox = document.getElementById('gg-bypass-idle');
    if (idleBox) idleBox.onchange = () => { ggBypassIdle = idleBox.checked; };
}

// visibilitychange:hidden is the reliable one — it fires on tab switch, lid
// close, and app backgrounding, where beforeunload often doesn't.
//
// ⚠️ BUT IT FIRES ON EVERY TAB SWITCH, not just at session end. A student
// bouncing to Google Classroom and back eight times used to trigger eight full
// final flushes. The localStorage position write is free and must still happen
// every time — that's the part protecting their work. The Firestore flush is
// rate-limited to once a minute, because nothing in it is time-critical: the WAL
// already holds the durable copy, and a teacher reading a report mid-period is
// looking at typing_logs, which is a merge and therefore idempotent.
const HIDDEN_FLUSH_MIN_GAP_MS = 60000;
let lastHiddenFlush = 0;

document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
        // Position first: it's a synchronous localStorage write and it's the thing
        // whose loss actually costs the student their work. Never rate-limited.
        if (currentStep && drillPos > 0) saveRunPosition();
        learnWalSave();
        if (Date.now() - lastHiddenFlush >= HIDDEN_FLUSH_MIN_GAP_MS) {
            lastHiddenFlush = Date.now();
            flushStats('hidden', true);
        }
    }
});

window.addEventListener('beforeunload', () => {
    if (currentStep && drillPos > 0) saveRunPosition();
    if (currentUser && statsData.secondsToday > 0) flushStats('beforeunload', true);
});

// ─── Caps Lock Warning ────────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
    const capsEl = document.getElementById('caps-warning');
    if (capsEl) capsEl.classList.toggle('hidden', !e.getModifierState('CapsLock'));
});

// Escape: show quick stats overlay during a drill (mirrors game.js pause)
document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (drillView.classList.contains('hidden')) return;
    if (!drillModal.classList.contains('hidden')) return; // modal already showing
    e.preventDefault();
    showEscapeStats();
});

function showEscapeStats() {
    const wpm = stepSeconds > 0 ? Math.round((chars / 5) / (stepSeconds / 60)) : 0;
    const acc = chars > 0 ? Math.round(((chars - mistakes) / chars) * 100) : 100;
    const todayWPM  = statsData.secondsToday > 0 ? Math.round((statsData.charsToday / 5) / (statsData.secondsToday / 60)) : 0;
    const weekWPM   = statsData.secondsWeek  > 0 ? Math.round((statsData.charsWeek  / 5) / (statsData.secondsWeek  / 60)) : 0;
    const dGoal = goals.dailySeconds  > 0;
    const wGoal = goals.weeklySeconds > 0;
    const dDone = dGoal && statsData.secondsToday >= goals.dailySeconds;
    const wDone = wGoal && statsData.secondsWeek  >= goals.weeklySeconds;

    drillModal.classList.remove('hidden');
    document.getElementById('drill-keyboard-wrap').style.display = 'none';

    document.getElementById('dm-title').textContent = 'Paused';
    document.getElementById('dm-stars').innerHTML = '';
    document.getElementById('dm-stats').innerHTML =
        '<div class="dm-stat"><div class="dm-val">' + wpm + '</div><div class="dm-label">WPM</div></div>' +
        '<div class="dm-stat"><div class="dm-val">' + acc + '%</div><div class="dm-label">Accuracy</div></div>';

    document.getElementById('dm-msg').innerHTML =
        '<div class="cumulative-row" style="font-size:0.85rem;gap:16px;margin-bottom:6px;">' +
        '<span>' + (dDone ? '✓ ' : '') + 'Today: <strong>' + formatTime(statsData.secondsToday) + '</strong>' +
        (dGoal ? ' / ' + formatTime(goals.dailySeconds) : '') + '</span>' +
        '<span>' + (wDone ? '✓ ' : '') + 'Week: <strong>' + formatTime(statsData.secondsWeek) + '</strong>' +
        (wGoal ? ' / ' + formatTime(goals.weeklySeconds) : '') + '</span>' +
        '</div>' +
        '<span style="color:#aaa;font-size:0.78rem;">Press Escape or Enter to resume</span>';
    document.getElementById('dm-remediation').innerHTML = '';

    const btns = document.getElementById('dm-btns');
    btns.innerHTML = '';
    const resumeBtn = document.createElement('button');
    resumeBtn.className = 'dm-btn-primary'; resumeBtn.textContent = 'Resume';

    function resumeHandler() {
        document.removeEventListener('keydown', escKeyHandler);
        drillModal.classList.add('hidden');
        document.getElementById('drill-keyboard-wrap').style.display = '';
        drillKeyboard.focus();
    }
    function escKeyHandler(e) {
        if (e.key === 'Escape' || e.key === 'Enter') { e.preventDefault(); resumeHandler(); }
    }
    resumeBtn.onclick = resumeHandler;
    btns.appendChild(resumeBtn);
    document.addEventListener('keydown', escKeyHandler);
}

// ─── Auto-refocus keyboard on click-back ─────────────────────────────────────
function ensureKeyboardFocus() {
    if (!activeDrill.classList.contains('hidden') &&
        drillModal.classList.contains('hidden') &&
        drillKeyboard.onkeydown) {
        drillKeyboard.focus();
    }
}

document.getElementById('active-drill').addEventListener('click', ensureKeyboardFocus);

document.addEventListener('keydown', e => {
    if (e.target !== drillKeyboard) ensureKeyboardFocus();
});

// ─── Keyboard health-check ────────────────────────────────────────────────────
// Re-initialize keyboard if it somehow ends up empty (Safari paint timing edge case).
// Runs whenever the tab becomes visible again and on a periodic interval during drills.
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
        ensureKeyboardFocus();
        rebuildKeyboardIfNeeded();
    }
});

function _showHardStopOverlay(targetChar) {
    // Remove any existing overlay first
    const existing = document.getElementById('drill-hardstop');
    if (existing) existing.remove();

    let friendly = targetChar;
    if (targetChar === ' ')  friendly = 'Space';
    if (targetChar === '\n') friendly = 'Enter';
    if (targetChar === '\t') friendly = 'Tab';

    const el = document.createElement('div');
    el.id = 'drill-hardstop';
    el.style.cssText = [
        'position:absolute','inset:0','z-index:30',
        'display:flex','flex-direction:column','align-items:center','justify-content:center',
        'background:rgba(255,255,255,0.92)','gap:12px'
    ].join(';');
    el.innerHTML =
        '<div style="font-size:0.9rem;color:#555;font-family:monospace;">Too many errors — type the correct key to continue</div>' +
        '<div style="font-size:2rem;font-weight:bold;color:#D32F2F;border:2px solid #D32F2F;border-radius:6px;padding:6px 20px;font-family:monospace;">' +
        escHtml(friendly) + '</div>';

    // Attach to drill-keyboard-wrap so it overlays the keyboard area
    const wrap = document.getElementById('drill-keyboard-wrap');
    if (wrap) { wrap.style.position = 'relative'; wrap.appendChild(el); }
}

function _rebuildKeyboard() {
    console.warn('[TTB] Rebuilding keyboard — layout:', LAYOUT, 'step:', currentStepIdx);
    createKeyboard(drillKeyboard, LAYOUT);
    createHandGuide(drillKeyboard, fingerMap, LAYOUT, true);
    colorKeyboardKeys(drillKeyboard, fingerMap, true);
    requestAnimationFrame(() => requestAnimationFrame(() => {
        if (currentStep) advanceHandGuide();
        drillKeyboard.focus();
        _hideKeyboardRecovery();
        console.log('[TTB] Keyboard rebuilt OK — keys:', drillKeyboard.querySelectorAll('.key').length);
    }));
}

function _showKeyboardRecovery() {
    let el = document.getElementById('keyboard-recovery');
    if (!el) {
        el = document.createElement('div');
        el.id = 'keyboard-recovery';
        el.style.cssText = [
            'position:absolute', 'inset:0', 'display:flex',
            'align-items:center', 'justify-content:center',
            'background:rgba(0,0,0,0.55)', 'z-index:20',
            'cursor:pointer', 'border-radius:4px'
        ].join(';');
        el.innerHTML = '<div style="background:#fff;padding:16px 24px;border-radius:6px;text-align:center;font-family:monospace;">'
            + '<div style="font-size:1rem;font-weight:bold;margin-bottom:8px;">&#x2328; Keyboard did not load</div>'
            + '<div style="font-size:0.85rem;color:#555;margin-bottom:12px;">Tap to reload it</div>'
            + '<button style="background:var(--carolina-blue);color:white;border:none;padding:8px 20px;border-radius:4px;font-family:inherit;cursor:pointer;font-size:0.9rem;">Reload Keyboard</button>'
            + '</div>';
        el.addEventListener('click', () => { _rebuildKeyboard(); });
        // Wrap in position:relative container
        const wrap = document.getElementById('drill-keyboard-wrap');
        if (wrap) { wrap.style.position = 'relative'; wrap.appendChild(el); }
    }
    el.style.display = 'flex';
}

function _hideKeyboardRecovery() {
    const el = document.getElementById('keyboard-recovery');
    if (el) el.style.display = 'none';
}

function rebuildKeyboardIfNeeded() {
    if (activeDrill.classList.contains('hidden')) return;
    if (drillModal && !drillModal.classList.contains('hidden')) return;
    if (drillKeyboard.querySelectorAll('.key').length === 0) {
        console.warn('[TTB] Periodic check: keyboard empty — showing recovery UI');
        _showKeyboardRecovery();
        _rebuildKeyboard();
    }
}

// Periodic backstop — 1s interval (was 2s) for faster recovery
setInterval(() => {
    if (!activeDrill.classList.contains('hidden') &&
        drillModal.classList.contains('hidden')) {
        rebuildKeyboardIfNeeded();
    }
}, 1000);

// ─── Utils ────────────────────────────────────────────────────────────────────
function escHtml(s) {
    return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function formatTime(seconds) {
    const m = Math.floor(seconds / 60), s = seconds % 60;
    return m + ':' + String(s).padStart(2,'0');
}

function getLocalDateStr(date) {
    const d = date || new Date();
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}

function getWeekStart(date) {
    // Returns "YYYY-MM-DD" for the Saturday starting this school week (Sat-Fri).
    const d = new Date(date);
    const diff = (d.getDay() + 1) % 7;
    d.setDate(d.getDate() - diff);
    return d.getFullYear() + '-' +
        String(d.getMonth() + 1).padStart(2, '0') + '-' +
        String(d.getDate()).padStart(2, '0');
}



// ─── Stats loading (mirrors game.js) ─────────────────────────────────────────
async function loadUserStats() {
    if (!currentUser) return;
    try {
        const today = new Date();
        const dateStr = getLocalDateStr(today);
        const weekStart = getWeekStart(today);
        const snap = await getDoc(doc(db, 'users', currentUser.uid, 'stats', 'time_tracking'));
        if (snap.exists()) {
            const data = snap.data();
            if (data.lastDate === dateStr) {
                statsData.secondsToday  = data.secondsToday  || 0;
                statsData.charsToday    = data.charsToday    || 0;
                statsData.mistakesToday = data.mistakesToday || 0;
            } else {
                statsData.secondsToday = statsData.charsToday = statsData.mistakesToday = 0;
            }
            if ((data.weekStart || '') === weekStart) {
                statsData.secondsWeek  = data.secondsWeek  || 0;
                statsData.charsWeek    = data.charsWeek    || 0;
                statsData.mistakesWeek = data.mistakesWeek || 0;
            } else {
                statsData.secondsWeek = statsData.charsWeek = statsData.mistakesWeek = 0;
            }
        }
        statsData.lastDate  = dateStr;
        statsData.weekStart = weekStart;
    } catch(e) { console.warn('loadUserStats failed:', e); }
}


// ─── Apply pending class assignment set by admin before student first typed ──
async function applyPendingClassAssignment(user) {
    if (!user || user.isAnonymous || !user.email) return;
    try {
        const email   = user.email.toLowerCase();
        const pendRef = doc(db, 'pendingClassAssignments', email);
        const pendSnap = await getDoc(pendRef);
        if (!pendSnap.exists()) return;

        const { classId, schoolId } = pendSnap.data();
        if (!classId) return;

        // Check they don't already have a class assigned
        const userSnap = await getDoc(doc(db, 'users', user.uid));
        if (userSnap.exists() && userSnap.data().classId) return; // already assigned

        // Apply the pre-assignment
        // Stamp schoolId at the same time. Everything downstream — report scoping,
        // security rules, the roster — keys off the building, and a student with a
        // class but no building is invisible to their own teacher.
        await setDoc(doc(db, 'users', user.uid),
                     { classId, schoolId: schoolId || '' }, { merge: true });

        // Delete the pending record so it doesn't re-apply
        await deleteDoc(pendRef);

        // Reload goals with the new class
        await loadGoals();
    } catch(e) { /* non-critical — don't block login */ }
}

async function loadGoals() {
    try {
        // Cache hit? game.js has had this for several versions; learn.js never
        // got it, so every load paid two reads for values that change about once
        // a year. Same key, same shape, same 24h window — a student who opens
        // both pages in a day pays for one read, not two.
        //
        // ⚠️ game.js writes this same key WITHOUT `className` — it has no class
        // banner to fill. If we accepted that entry we'd blank the class name in
        // the header for up to 24h. So an entry that names a class but carries no
        // className is treated as a miss: we pay two reads once, and the entry we
        // write back has everything both pages need.
        const c0 = cacheRead(LEARN_GOALS_KEY, LEARN_GOALS_MS,
                             currentUser ? currentUser.uid : '');
        const c = (c0 && c0.classId && !c0.className) ? null : c0;
        if (c) {
            goals.dailySeconds  = c.dailySeconds  || 0;
            goals.weeklySeconds = c.weeklySeconds || 0;
            classInfo = { id: c.classId || '', name: c.className || '',
                          schoolId: c.schoolId || '',
                          dailySeconds: goals.dailySeconds,
                          weeklySeconds: goals.weeklySeconds };
            updateClassDisplay();
            if (goals.dailySeconds  > 0 && statsData.secondsToday >= goals.dailySeconds)  dailyGoalCelebrated  = true;
            if (goals.weeklySeconds > 0 && statsData.secondsWeek  >= goals.weeklySeconds) weeklyGoalCelebrated = true;
            return;
        }

        // Step 1: check if user belongs to a class
        let resolved = false;
        if (currentUser) {
            const userSnap = await getDoc(doc(db, 'users', currentUser.uid));
            if (userSnap.exists()) {
                const ud = userSnap.data();
                if (ud.classId) {
                    const classSnap = await getDoc(doc(db, 'classes', ud.classId));
                    if (classSnap.exists()) {
                        const cd = classSnap.data();
                        goals.dailySeconds  = cd.dailySeconds  || 0;
                        goals.weeklySeconds = cd.weeklySeconds || 0;
                        classInfo = { id: ud.classId, name: cd.name || '',
                                      schoolId: ud.schoolId || cd.schoolId || '',
                                      dailySeconds: goals.dailySeconds,
                                      weeklySeconds: goals.weeklySeconds };
                        resolved = true;
                        updateClassDisplay();
                    }
                }
            }
        }
        // Step 2: fall back to settings/goals if no class
        if (!resolved) {
            const snap = await getDoc(doc(db, 'settings', 'goals'));
            if (snap.exists()) {
                const d = snap.data();
                goals.dailySeconds  = d.dailySeconds  || 0;
                goals.weeklySeconds = d.weeklySeconds || 0;
            }
            classInfo = { id: '', name: '', dailySeconds: goals.dailySeconds,
                          weeklySeconds: goals.weeklySeconds };
            updateClassDisplay();
        }

        // Persist for 24h. `className` is extra over game.js's payload and is
        // additive only — game.js reads the fields it knows and ignores this one.
        cacheWrite(LEARN_GOALS_KEY, {
            uid: currentUser ? currentUser.uid : '',
            dailySeconds: goals.dailySeconds, weeklySeconds: goals.weeklySeconds,
            classId: classInfo.id || '', className: classInfo.name || '',
            schoolId: classInfo.schoolId || ''
        });

        if (goals.dailySeconds  > 0 && statsData.secondsToday >= goals.dailySeconds)  dailyGoalCelebrated  = true;
        if (goals.weeklySeconds > 0 && statsData.secondsWeek  >= goals.weeklySeconds) weeklyGoalCelebrated = true;
    } catch(e) { console.warn('loadGoals failed:', e); }
}

function updateClassDisplay() {
    // Class name below username
    const classEl = document.getElementById('user-class-name');
    if (classEl) classEl.textContent = classInfo.name || '';

    // Daily goal denominator in HUD
    const dailyGoalEl = document.getElementById('hud-daily-goal');
    if (dailyGoalEl) {
        if (goals.dailySeconds > 0) {
            const gm = Math.floor(goals.dailySeconds / 60);
            const gs = goals.dailySeconds % 60;
            dailyGoalEl.textContent = ' / ' + gm + ':' + String(gs).padStart(2,'0');
        } else {
            dailyGoalEl.textContent = '';
        }
    }

    // Weekly goal denominator — update hud-week format
    updateWeeklyHUD();
}

function updateWeeklyHUD() {
    const weekEl = document.getElementById('hud-week');
    if (!weekEl) return;
    const wm = Math.floor(statsData.secondsWeek / 60);
    const ws = statsData.secondsWeek % 60;
    const wDone = goals.weeklySeconds > 0 && statsData.secondsWeek >= goals.weeklySeconds;
    let txt = 'Week ' + wm + ':' + String(ws).padStart(2,'0');
    if (goals.weeklySeconds > 0) {
        const gm = Math.floor(goals.weeklySeconds / 60);
        const gs = goals.weeklySeconds % 60;
        txt += ' / ' + gm + ':' + String(gs).padStart(2,'0');
    }
    if (wDone) txt += ' ✓';
    weekEl.textContent = txt;
}

// Coalesced stats persistence, mirroring the pattern in game.js v3.4.0.
//
// saveStats() fired on every completed lesson step and wrote TWO documents each
// time. Steps come every 30-60 seconds, so a ten-minute lesson block was ~20-40
// writes per student. Now every call records to a local write-ahead log (free,
// synchronous, instant) and Firestore gets a batched flush on a timer and at
// session end. Nothing is lost — see walRecoverLearn() below.
const LEARN_WAL_KEY = 'ttb_learnwal_v1';

// ─── Run position persistence (v2.0.0) ───────────────────────────────────────
// Separate key from the stats WAL on purpose: stats are a merge-by-max recovery,
// position is a single latest-wins snapshot with different lifetime rules, and
// mixing them would mean one corrupt field losing both.
//
// Before this existed the WAL persisted statsData only — not drillPos, not
// currentStepIdx — so the bell erased the whole run AND any earlier runs cleared in
// that sitting, because lessonProgress is only written at the end of a lesson. Any
// run longer than the time left in the period was therefore unfinishable, forever.
//
// The sequence is stored verbatim rather than regenerated: key_random and
// key_pattern_auto build a fresh random sequence on every call, so restoring a
// position into a regenerated sequence would put the student mid-word in text they
// never saw.
const LEARN_POS_KEY = 'ttb_learnpos_v1';

function saveRunPosition() {
    if (!currentLesson || !currentStep) return;
    try {
        localStorage.setItem(LEARN_POS_KEY, JSON.stringify({
            v: 1,
            uid: currentUser ? currentUser.uid : 'anon',
            lessonId: currentLesson.id,
            runIdx: currentStepIdx,
            drillPos, chars, mistakes, stepSeconds,
            seq: drillSequence.join(''),
            savedAt: Date.now()
        }));
    } catch (e) { console.warn('run position write failed:', e); }
}

function readRunPosition() {
    try {
        const raw = localStorage.getItem(LEARN_POS_KEY);
        if (!raw) return null;
        const p = JSON.parse(raw);
        if (p.v !== 1) return null;
        // Don't hand one student's position to another on a shared Chromebook.
        const who = currentUser ? currentUser.uid : 'anon';
        if (p.uid !== who) return null;
        // A run part-way through is worth restoring; a run barely started isn't
        // worth the confusion of resuming into.
        if (!p.seq || typeof p.drillPos !== 'number' || p.drillPos < 5) return null;
        return p;
    } catch (_) { return null; }
}

function clearRunPosition() {
    try { localStorage.removeItem(LEARN_POS_KEY); } catch (_) {}
}

// Non-destructive read, for renderMap and startLesson.
function peekPendingRun(lessonId) {
    const p = readRunPosition();
    return (p && p.lessonId === lessonId) ? p : null;
}

// Destructive read, for beginStep: a position is consumed the moment it's applied,
// so a later retry of the same run starts clean instead of resurrecting old counters.
function takePendingRun(runIdx) {
    if (!currentLesson) return null;
    const p = peekPendingRun(currentLesson.id);
    if (!p || p.runIdx !== runIdx) return null;
    clearRunPosition();
    return p;
}
const LEARN_FLUSH_MS = 300000;   // 5 minutes
let learnFlushTimer = null;
let learnDirty = false;
let learnStatsDocDirty = false;

function learnWalSave() {
    if (!currentUser) return;
    try {
        localStorage.setItem(LEARN_WAL_KEY, JSON.stringify({
            v: 1, uid: currentUser.uid, savedAt: Date.now(), stats: { ...statsData },
            // Queued run-level progress, so a crash between flushes doesn't lose the
            // record of a student grinding on a run they can't clear.
            progress: Array.from(pendingProgress).reduce((acc, id) => {
                if (userProgress[id]) acc[id] = userProgress[id];
                return acc;
            }, {})
        }));
    } catch (e) { console.warn('learn WAL write failed:', e); }
}

// Replay whatever the last session couldn't flush. Counters only rise within a
// day/week, so max() is the safe merge. Call after loadUserStats().
function walRecoverLearn() {
    try {
        const raw = localStorage.getItem(LEARN_WAL_KEY);
        if (!raw) return;
        const wal = JSON.parse(raw);
        if (wal.v !== 1 || !currentUser || wal.uid !== currentUser.uid || !wal.stats) return;
        let recovered = false;
        if (wal.stats.lastDate === statsData.lastDate) {
            for (const k of ['secondsToday', 'charsToday', 'mistakesToday']) {
                if ((wal.stats[k] || 0) > (statsData[k] || 0)) { statsData[k] = wal.stats[k]; recovered = true; }
            }
        }
        if (wal.stats.weekStart === statsData.weekStart) {
            for (const k of ['secondsWeek', 'charsWeek', 'mistakesWeek']) {
                if ((wal.stats[k] || 0) > (statsData[k] || 0)) { statsData[k] = wal.stats[k]; recovered = true; }
            }
        }
        // Replay queued run-level progress (v2.1.0). Merge rather than overwrite:
        // loadProgress() has already read Firestore, and the WAL copy is only newer
        // for the specific lessons that were mid-flight when the tab died.
        if (wal.progress && typeof wal.progress === 'object') {
            for (const [id, rec] of Object.entries(wal.progress)) {
                const live = userProgress[id];
                const walSeen  = Date.parse(rec.lastSeenAt || 0) || 0;
                const liveSeen = Date.parse(live && live.lastSeenAt) || 0;
                if (!live || walSeen > liveSeen) {
                    userProgress[id] = Object.assign({}, live, rec);
                    pendingProgress.add(id);
                    recovered = true;
                }
            }
            if (pendingProgress.size) {
                console.log('Recovered unflushed run progress for', pendingProgress.size, 'lesson(s).');
            }
        }

        if (recovered) {
            console.log('Recovered unflushed lesson data from local storage.');
            learnDirty = true; learnStatsDocDirty = true;
            flushStats('recovery', true);
        } else {
            localStorage.removeItem(LEARN_WAL_KEY);
        }
    } catch (_) { /* corrupt WAL — ignore it */ }
}

// Record locally and schedule a flush. Replaces the old saveStats().
function saveStats() {
    if (!currentUser) return;
    learnDirty = true;
    learnStatsDocDirty = true;
    learnWalSave();
    if (!learnFlushTimer) {
        learnFlushTimer = setTimeout(() => { learnFlushTimer = null; flushStats('interval'); }, LEARN_FLUSH_MS);
    }
}

// ⚠️ RE-ENTRANCY GUARD. flushStats() is reachable from the interval timer,
// visibilitychange, beforeunload, and walRecoverLearn(). It is async with
// several sequential awaits, so two runs could overlap and both iterate
// `pendingProgress` — writing the same lesson record twice and deleting entries
// out from under each other's loop. Same class of bug as game.js flushAll().
// A single in-flight promise serialises them: a caller that arrives mid-flush
// waits for the running flush and then re-runs, so nothing is dropped.
//
// ⚠️ THE LOOP IS `while`, NOT `if`. (v2.2.1)
//
// v2.2.0 wrote `if`, which holds for two callers and fails for three or more:
// once the running flush resolves and its finally nulls the slot, every caller
// parked on that promise is ALREADY past the `if`, so they all claim the slot
// and their inner runs overlap. `while` closes it, because re-checking after
// the await is synchronous with the assignment that follows. Four call sites
// means three-deep is reachable — a student alt-tabbing during an interval
// flush is enough. Identical fix to game.js 3.9.2; both files had it.
let _learnFlushInFlight = null;

async function flushStats(reason, final = false) {
    while (_learnFlushInFlight) {
        await _learnFlushInFlight.catch(() => {});
    }
    _learnFlushInFlight = _flushStatsInner(reason, final);
    try { await _learnFlushInFlight; }
    finally { _learnFlushInFlight = null; }
}

async function _flushStatsInner(reason, final = false) {
    if (!currentUser) return;
    if (!learnDirty && pendingProgress.size === 0) return;
    if (learnFlushTimer) { clearTimeout(learnFlushTimer); learnFlushTimer = null; }
    let ok = true;

    // Daily log — what reports.html reads. Written on every flush so a teacher
    // checking mid-period sees today's numbers.
    try {
        const today = getLocalDateStr();
        await setDoc(doc(db, 'typing_logs', currentUser.uid + '_' + today), {
            uid: currentUser.uid, email: currentUser.email || '',
            displayName: currentUser.displayName || 'Anonymous',
            classId: (classInfo && classInfo.id) || '',
            schoolId: (classInfo && classInfo.schoolId) || '',
            date: today, seconds: statsData.secondsToday || 0,
            chars: statsData.charsToday || 0, mistakes: statsData.mistakesToday || 0,
            lastUpdated: new Date(), source: 'school'
        }, { merge: true });
    } catch (e) { ok = false; console.warn(`Log flush failed (${reason}):`, e); }

    // Week/day rollup — only read at page load, so session-end is soon enough.
    if (final && learnStatsDocDirty) {
        try {
            await setDoc(doc(db, 'users', currentUser.uid, 'stats', 'time_tracking'),
                         statsData, { merge: true });
            learnStatsDocDirty = false;
        } catch (e) { ok = false; console.warn(`Stats flush failed (${reason}):`, e); }
    }

    if (!(await flushLessonProgress())) ok = false;

    // The local copy is now authoritative for this student — mirror it into the
    // cache so the next page load doesn't have to re-read the subcollection to
    // learn what this tab already did.
    refreshProgressCache();

    if (ok) {
        learnDirty = false;
        if (final) { try { localStorage.removeItem(LEARN_WAL_KEY); } catch (_) {} }
    } else {
        learnWalSave();   // keep the local copy; next flush retries
    }
}

// ─── Celebration (copied from game.js) ───────────────────────────────────────
function createCelebrationCanvas() {
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9999;';
    canvas.width = window.innerWidth; canvas.height = window.innerHeight;
    document.body.appendChild(canvas); return canvas;
}

function showGoalToast(message, color) {
    const toast = document.createElement('div');
    toast.textContent = message;
    toast.style.cssText = 'position:fixed;top:80px;left:50%;transform:translateX(-50%);background:' + color + ';color:#000;font-family:"Courier Prime",monospace;font-weight:700;font-size:1.2rem;padding:14px 28px;border-radius:8px;z-index:10000;box-shadow:0 4px 20px rgba(0,0,0,0.5);';
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.5s'; setTimeout(() => toast.remove(), 500); }, 3000);
}

function launchConfetti() {
    const canvas = createCelebrationCanvas();
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    const colors = ['#4B9CD3','#FFD700','#FF6B6B','#22c55e','#FF69B4','#FFA500','#9B59B6','#00CED1'];
    const pieces = [];
    for (let i = 0; i < 150; i++) {
        pieces.push({ x: W*0.5+(Math.random()-0.5)*W*0.6, y:-20-Math.random()*100,
            w:6+Math.random()*6, h:10+Math.random()*8, color:colors[Math.floor(Math.random()*colors.length)],
            rotation:Math.random()*Math.PI*2, rotSpeed:(Math.random()-0.5)*0.15,
            vx:(Math.random()-0.5)*4, vy:2+Math.random()*3,
            wobble:Math.random()*Math.PI*2, wobbleSpeed:0.03+Math.random()*0.05 });
    }
    showGoalToast('🎉 Daily Goal Reached!', '#22c55e');
    let frame = 0;
    (function animate() {
        ctx.clearRect(0,0,W,H); let alive=false;
        pieces.forEach(p => {
            p.x+=p.vx+Math.sin(p.wobble)*0.5; p.y+=p.vy; p.vy+=0.04;
            p.rotation+=p.rotSpeed; p.wobble+=p.wobbleSpeed; p.vx*=0.99;
            if(p.y<H+50){ alive=true; ctx.save(); ctx.translate(p.x,p.y); ctx.rotate(p.rotation);
                ctx.fillStyle=p.color; ctx.globalAlpha=Math.max(0,1-(frame/200));
                ctx.fillRect(-p.w/2,-p.h/2,p.w,p.h); ctx.restore(); }
        });
        frame++; if(alive&&frame<250) requestAnimationFrame(animate); else canvas.remove();
    })();
}

function launchFireworks() {
    const canvas = createCelebrationCanvas();
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    const colors = ['#4B9CD3','#FFD700','#FF6B6B','#22c55e','#FF69B4','#FFA500','#9B59B6','#00CED1','#fff'];
    const shells = [], particles = [];
    for(let i=0;i<5;i++) setTimeout(()=>{
        shells.push({x:W*(0.2+Math.random()*0.6),y:H,vy:-(8+Math.random()*4),
            targetY:H*(0.15+Math.random()*0.35),color:colors[Math.floor(Math.random()*colors.length)],exploded:false});
    },i*400);
    showGoalToast('🎆 Weekly Goal Reached!', '#FFD700');
    let frame=0;
    (function animate(){
        ctx.clearRect(0,0,W,H);
        shells.forEach(s=>{
            if(s.exploded)return; s.y+=s.vy; s.vy+=0.12;
            ctx.beginPath();ctx.arc(s.x,s.y,2,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();
            if(s.y<=s.targetY||s.vy>=0){
                s.exploded=true;
                for(let i=0;i<80;i++){
                    const angle=(Math.PI*2*i)/80+(Math.random()-0.5)*0.3, speed=2+Math.random()*4;
                    particles.push({x:s.x,y:s.y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed,
                        color:Math.random()>0.3?s.color:colors[Math.floor(Math.random()*colors.length)],
                        life:1.0,decay:0.008+Math.random()*0.012,size:1.5+Math.random()*2});
                }
            }
        });
        for(let i=particles.length-1;i>=0;i--){
            const p=particles[i]; p.x+=p.vx; p.y+=p.vy; p.vy+=0.04; p.vx*=0.98; p.life-=p.decay;
            if(p.life<=0){particles.splice(i,1);continue;}
            ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);
            ctx.fillStyle=p.color;ctx.globalAlpha=p.life;ctx.fill();
        }
        ctx.globalAlpha=1; frame++;
        if(frame<400&&(particles.length>0||shells.some(s=>!s.exploded))) requestAnimationFrame(animate);
        else canvas.remove();
    })();
}

// ─── Init ─────────────────────────────────────────────────────────────────────
// loadLessons fires immediately (lessons collection is public, no auth needed).
// onAuthStateChanged handles ALL rendering — it fires for both signed-in and
// signed-out states, and is the only reliable moment to know auth is settled.
// We must NOT call renderMap() here because auth.currentUser is null at module
// load time even for a returning signed-in user.
const footer = document.querySelector('footer');
if (footer) footer.textContent = 'School v' + LEARN_VERSION + ' / keyboard.js v' + KB_VERSION;
// Title was hardcoded in learn.html and drifted from the constant. Drive it from
// the constant so there is only one number to change.
document.title = 'TypeThatBook — School v' + LEARN_VERSION;

loadLessons(); // fire-and-forget; renderMap() in onAuthStateChanged will re-render when done
