#!/usr/bin/env python3
"""BATCH 16 FINDING: audit every pattern that ends in a hard \\b for hidden inflections.

The handoff's own customFlaggedWords list carries /\\bpecker\\b/, /\\bfanny\\b/,
/\\bmammy\\b/ etc. — the exact 'exact word with a trailing boundary' form that
THE REGEX RULE (batch 2) forbids. /\\bpecker\\b/ cannot see 'peckers'.

This re-runs every hard-bounded literal as a stem and reports anything the
standing scan could not see.
"""
import re, sys
from scan import BLOCKS, load_spine, dedupe

# pull literal words out of hard-bounded alternatives
HARD = re.compile(r'\\b([a-z]{3,})\\b')

def stems_from(pats):
    out = set()
    for p in pats:
        for w in HARD.findall(p):
            out.add(w)
    return out

def audit(dumpfile):
    spine = load_spine(dumpfile)
    stems = set()
    for pats in BLOCKS.values():
        stems |= stems_from(pats)
    findings = []
    for fname, body in spine:
        for w in sorted(stems):
            strict = re.compile(r'\b' + w + r'\b', re.I)
            loose = re.compile(r'\b' + w + r'\w+', re.I)   # strictly MORE than the word
            extra = [m for m in loose.finditer(body)]
            if extra:
                for m in extra:
                    findings.append((fname, w, m.group(0), m.start(),
                                     body[max(0, m.start()-90):m.start()+90].replace('\n', ' ')))
    return findings

if __name__ == '__main__':
    # words whose inflections are pure noise; suppress to keep the signal readable
    NOISE = {'ass', 'crack', 'lame', 'dumb', 'brave', 'den', 'dis', 'dem', 'dar',
             'dat', 'dey', 'den', 'obs', 'mah', 'nip', 'hun', 'huns', 'wif', 'fag',
             'fags', 'tits', 'balls', 'members', 'member', 'moor', 'chile', 'heah'}
    seen = set()
    for fname, w, form, pos, ctx in audit(sys.argv[1]):
        if w in NOISE:
            continue
        key = (w, form.lower())
        if key in seen:
            continue
        seen.add(key)
        print(f'[{w} -> {form}] {fname[:30]}')
        print(f'    {ctx}')
