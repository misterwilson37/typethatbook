#!/usr/bin/env python3
"""typefix.py 1.0.0 - BATCH 25. Turn untypable characters into typeable ones.

Jake's ruling, batch 25:
  "Normalize ellipses into three periods. Probably no need for spaces around them.
   All untypable characters should be changed into typeable ones."

⚠️ WHY THIS IS A SCRIPT AND NOT ROWS IN `edits.py`.
`edits.py` rows are hand-written, hand-counted assertions, and that is right for
JUDGMENT edits - a slur has a context, a replacement, and a reason a human must
be able to argue with. These 633 sites have no judgment in them at all: every
`U+FEFF` gets deleted for the same reason as every other `U+FEFF`. Writing 633
rows by hand would be 633 chances to typo and would bury the ~20 rows that
actually need review. **Mechanical passes go in a script with a census;
judgment passes go in the table.**

⚠️ WHAT THIS DELIBERATELY DOES NOT TOUCH: the five KEEP_GLYPHS from
`measure.py` - curly quotes and the em/en dashes. 13b/17g whitelisted those as
acceptable for TypeThatBook eight batches ago and `measure.py typable` still
does not report them. If Jake wants those flattened too it is a one-line change
here, but it is a NEW ruling and not this one.

USAGE
  python3 typefix.py <bookdir> --dry     # census only, writes nothing
  python3 typefix.py <bookdir>           # rewrite in place
  python3 typefix.py --selftest
"""
import os, re, sys, glob, collections

VERSION = '1.0.0'

# BATCH 25: SKIP was copied from measure.py, where excluding front/back matter
# is RIGHT - the question there is "what will a student type", and admin.js
# rebuilds those pages on import (19d). But verify.py's residual check reads the
# WHOLE BOOK, correctly, and caught 2 U+FEFF + 2 U+00A0 still live in
# colophon.xhtml and uncopyright.xhtml.
#
# A measurement tool and a cleaning tool want different scopes: measuring asks
# what the student sees, cleaning asks what is in the file. Normalising a page
# admin.js may overwrite costs nothing; leaving an unkeyable character in a
# shipped EPUB and calling the book clean costs the next re-scan's trust (17a).
# So this list is now empty by design, and kept as a named constant so the
# reason survives.
SKIP = ()

# ⚠️ ORDER MATTERS AND THE ELLIPSIS RULE MUST COME FIRST.
# Standard Ebooks writes an ellipsis as the three-character run
# `U+FEFF U+200A U+2026` (zero-width no-break space, hair space, ellipsis
# glyph). If the U+FEFF and U+200A rules ran first they would each turn into a
# space and leave `  ...` with the very spaces Jake said to drop. Collapse the
# whole cluster in one step, including any space that already precedes it, so
# `barrels!﻿ ﻿… Barrels!` becomes `barrels!... Barrels!`.
RULES = [
    # -- ellipses, cluster first --------------------------------------------
    ('SE ellipsis cluster -> ...',
     re.compile('[ \u00a0\u200a\ufeff]*\u2026'), '...'),

    # ⚠️ BATCH 25b: the PROJECT GUTENBERG spaced form, added while confirming
    # The Prince and the Pauper (27 instances, six chapters). PG plain text
    # renders an ellipsis as `. . .` with real spaces between the periods, so
    # `quality.py` files it under "expected, not defects" and no other check
    # looks at it. It is fully typeable - and it is not what Jake ruled:
    # "normalize ellipses into three periods, probably no need for spaces".
    #
    # ⚠️ THIS RULE LIVES HERE AND NOWHERE ELSE. `notefix.py` grew a
    # double-space collapse that rewrote these same 27 ellipses as a side
    # effect of stripping footnote anchors - the right change from the wrong
    # tool, which is a change no reviewer can find. One owner per concern.
    #
    # Ordered AFTER the U+2026 rule so a converted cluster is not re-processed,
    # and written to eat a leading space so `gallows! . . .` -> `gallows!...`
    # rather than `gallows! ...`.
    ('PG spaced ellipsis -> ...',
     re.compile(r' ?\.(?: +\.){2,}'), '...'),

    # -- invisibles: delete, never space ------------------------------------
    # U+FEFF here is a line-break hint SE puts beside em-dashes. It is not a
    # word separator, so replacing it with a space would insert a space that
    # was never in the text: `dreeft﻿—dreeft` must not become `dreeft —dreeft`.
    ('U+FEFF zero-width no-break space -> deleted',
     re.compile('\ufeff'), ''),
    ('U+FE0E variation selector -> deleted',
     re.compile('\ufe0e'), ''),

    # -- space lookalikes: these ARE word separators, so they become a space --
    ('U+00A0 non-breaking space -> space',
     re.compile('\u00a0'), ' '),
    ('U+200A hair space -> space',
     re.compile('\u200a'), ' '),
    ('U+2009 thin space -> space',
     re.compile('\u2009'), ' '),

    # -- punctuation that has a keyable twin --------------------------------
    ('U+2011 non-breaking hyphen -> hyphen',
     re.compile('\u2011'), '-'),
    ('U+2012/2015 dashes -> hyphen',
     re.compile('[\u2012\u2015]'), '-'),
    ('U+00AD soft hyphen -> deleted',
     re.compile('\u00ad'), ''),
    ('U+2032/2033 primes -> apostrophe/quote',
     re.compile('\u2032'), '\u2019'),
    ('U+00B4/02BC/0060 stray accents-as-apostrophe -> apostrophe',
     re.compile('[\u00b4\u02bc\u0060]'), '\u2019'),
    ('U+21A9 endnote arrow -> deleted',
     re.compile('\u21a9'), ''),

    # -- accented Latin letters --------------------------------------------
    # ⚠️ THIS IS THE ONE RULE WITH A COST. In Captains Courageous the accents
    # are French song lyrics and one exclamation - `Par derriere chez ma
    # tante`, `Quebec`, `Arretez vous!` - so flattening them makes the French
    # slightly wrong. Kept anyway, because the alternative is a 13-year-old
    # hunting for a key that is not on the keyboard mid-sentence, and `Quebec`
    # unaccented is standard English usage regardless. Flagged to Jake.
    ('accented Latin -> unaccented',
     re.compile('[\u00c0-\u00ff\u0100-\u017f]'), None),
]

FOLD = {
    'à': 'a', 'á': 'a', 'â': 'a', 'ã': 'a', 'ä': 'a', 'å': 'a', 'ā': 'a',
    'è': 'e', 'é': 'e', 'ê': 'e', 'ë': 'e', 'ē': 'e',
    'ì': 'i', 'í': 'i', 'î': 'i', 'ï': 'i', 'ī': 'i',
    'ò': 'o', 'ó': 'o', 'ô': 'o', 'õ': 'o', 'ö': 'o', 'ō': 'o',
    'ù': 'u', 'ú': 'u', 'û': 'u', 'ü': 'u', 'ū': 'u',
    'ç': 'c', 'ñ': 'n', 'ý': 'y', 'ÿ': 'y', 'š': 's', 'ž': 'z',
    'æ': 'ae', 'œ': 'oe', 'ø': 'o', 'ß': 'ss', 'ð': 'th', 'þ': 'th',
    'À': 'A', 'Á': 'A', 'Â': 'A', 'Ã': 'A', 'Ä': 'A', 'Å': 'A',
    'È': 'E', 'É': 'E', 'Ê': 'E', 'Ë': 'E',
    'Ì': 'I', 'Í': 'I', 'Î': 'I', 'Ï': 'I',
    'Ò': 'O', 'Ó': 'O', 'Ô': 'O', 'Õ': 'O', 'Ö': 'O',
    'Ù': 'U', 'Ú': 'U', 'Û': 'U', 'Ü': 'U',
    'Ç': 'C', 'Ñ': 'N', 'Æ': 'AE', 'Œ': 'OE', 'Ø': 'O',
}


def fold(m):
    return FOLD.get(m.group(0), m.group(0))


def files(root):
    """⚠️ BATCH 25b: THIS FUNCTION RETURNED AN EMPTY LIST AND run() REPORTED
    SUCCESS.

    The old body probed `root/epub/text`, then `root/OEBPS/text`, then fell
    back to `root` itself. The Prince and the Pauper is a FLAT layout - the
    XHTML sits directly in `OEBPS/`, with no `text/` subdirectory - so all
    three probes missed, the glob ran against `root`, and the tool printed
    `0 files changed, 0 substitutions` and exited 0 on a book with 27 spaced
    ellipses in it.

    ⚠️ THAT IS THE `measure.py spine()` FAILURE REPRODUCED IN A TOOL I WROTE
    IN THIS SAME BATCH, one session after documenting it. A layout assumption
    plus a silent empty result equals a clean bill of health for an untouched
    book. An empty file list is now a hard error, because there is no
    legitimate reason to run a cleaning pass over zero files.
    """
    for base in ('epub/text', 'OEBPS/text', 'OEBPS', 'epub', ''):
        d = os.path.join(root, base) if base else root
        found = sorted(glob.glob(os.path.join(d, '*.xhtml')))
        if found:
            return [f for f in found if os.path.basename(f) not in SKIP]
    raise SystemExit(
        f'\n  *** no .xhtml found under {root!r}. Probed: epub/text, '
        f'OEBPS/text, OEBPS, epub, and the root itself. Refusing to report '
        f'"0 substitutions" on a book that was never opened. ***')


def run(root, dry=True):
    census = collections.Counter()
    per_file = collections.Counter()
    unfolded = collections.Counter()
    touched = 0
    for f in files(root):
        raw = open(f, encoding='utf-8').read()
        s = raw
        for label, pat, repl in RULES:
            if repl is None:
                s, n = pat.subn(fold, s)
                # anything the FOLD table has no entry for survives; report it
                for m in pat.finditer(s):
                    unfolded[m.group(0)] += 1
            else:
                s, n = pat.subn(repl, s)
            if n:
                census[label] += n
        if s != raw:
            touched += 1
            per_file[os.path.basename(f)] = sum(
                1 for a, b in zip(raw, s) if a != b) or len(raw) - len(s)
            if not dry:
                open(f, 'w', encoding='utf-8').write(s)
    print(f'  {"DRY RUN - nothing written" if dry else "REWRITTEN IN PLACE"}')
    print(f'  {touched} files changed, {sum(census.values())} substitutions')
    for label, n in census.most_common():
        print(f'    {n:6d}  {label}')
    if unfolded:
        print('  ⚠️ NO FOLD ENTRY - these survived and are still untypable:')
        for ch, n in unfolded.most_common():
            print(f'    U+{ord(ch):04X} {ch!r} x{n}')
    return census


def selftest():
    """⚠️ Rule 10. The ellipsis case is the whole reason for the rule ORDER, so
    it is asserted character-for-character, not by count."""
    cases = [
        # (input, expected, why)
        ('barrels!\ufeff \ufeff\u2026 Barrels!', 'barrels!... Barrels!',
         'SE ellipsis cluster + the space before it, Jake: no spaces around'),
        ('thinks\ufeff \ufeff\u2026 Say', 'thinks... Say',
         'the Captains Courageous form'),
        ('dreeft\ufeff\u2014dreeft', 'dreeft\u2014dreeft',
         '⚠️ U+FEFF beside an em-dash DELETES - a space here would be invented'),
        ('wha\u2011at', 'wha-at', 'non-breaking hyphen in Manuel speech'),
        ('Mr.\u00a0Mactonal', 'Mr. Mactonal', 'nbsp is a real separator'),
        ('Qu\u00e9bec', 'Quebec', 'accent fold'),
        ('Arr\u00eatez vous!', 'Arretez vous!', 'accent fold'),
        ('derri\u00e8re', 'derriere', 'accent fold'),
        ('\u201cWhat\u2019s a Jonah?\u201d', '\u201cWhat\u2019s a Jonah?\u201d',
         '⚠️ KEEP_GLYPHS untouched - curly quotes are whitelisted (13b/17g)'),
        ('a long\u2014dash', 'a long\u2014dash', 'em-dash is whitelisted'),
        ('plain ascii ... unchanged', 'plain ascii ... unchanged',
         'an already-typeable ellipsis is not re-processed'),
        # BATCH 25b - the Project Gutenberg spaced form.
        ('the gallows! . . . and then', 'the gallows!... and then',
         'PG spaced ellipsis, leading space eaten (Jake: no spaces around)'),
        # ⚠️ THE FOUR-DOT FORM. `strength. . . .` is the printer's convention
        # for a sentence-ending period PLUS an ellipsis, so the typographically
        # faithful output is `strength....` - and I first wrote this case
        # expecting exactly that. Jake's ruling is narrower and wins: "normalize
        # ellipses into three periods." Every run of spaced dots collapses to
        # exactly three, so a student never has to count them.
        ('bring me strength. . . .', 'bring me strength...',
         'four-dot PG form collapses to THREE - Jake\'s ruling over typography'),
        ('a decimal 3.14 and Mr. Smith', 'a decimal 3.14 and Mr. Smith',
         'periods that are NOT an ellipsis are untouched'),
    ]
    ok = True
    for src, want, why in cases:
        got = src
        for label, pat, repl in RULES:
            got = pat.sub(fold, got) if repl is None else pat.sub(repl, got)
        good = got == want
        ok = ok and good
        print(f'  {"OK  " if good else "FAIL"} {why}')
        if not good:
            print(f'         in   {src!r}')
            print(f'         want {want!r}')
            print(f'         got  {got!r}')
    print(f'\n{len(cases)} cases ran')
    print('SELFTEST PASS' if ok else '*** SELFTEST FAILED ***')
    return ok


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        sys.exit(0 if selftest() else 1)
    run(sys.argv[1], dry='--dry' in sys.argv)
