// checkmatter.js 1.0.0 - BATCH 25b. Answers "will admin.js let a student type
// this file?" by RUNNING JAKE'S OWN CODE against a built EPUB, instead of
// reasoning about it from the source.
//
// Jake, batch 25b, on The Prince and the Pauper's endnotes:
//   "What will it do with those endnotes? If they get typed, then cut them."
//
// ⚠️ THE POINT OF THIS TOOL IS THAT IT DOES NOT PARAPHRASE admin.js.
// `extract.py` lifts classifyDocument(), detectAbout(), matterTitleFrom(),
// assignChapterIds(), detectPart() and their constants VERBATIM out of
// admin.js into extracted.js, and this harness calls them. A hand-written
// reimplementation of the classifier would answer a question about MY code, not
// about the app - and the whole reason the question was worth asking is that
// admin.js is the file that decides.
//
// ⚠️ RE-EXTRACT AFTER EVERY admin.js CHANGE. `extracted.js` is a snapshot and
// will silently go stale, which is the exact failure mode admin.js's own v3.x
// header warns about ("a stale admin.js was previously invisible").
//
// VERDICT FOR THE PRINCE AND THE PAUPER, run 2026-08-28:
//   34 body chapters (Twain's 33 + Conclusion), front 0.1-0.2, back 900.1-900.3
//   endnotes.xhtml -> matter=back, id=900.1, typed=NO, about=NO
//     via epub:type="backmatter endnotes" - STRATEGY 1, the authoritative
//     route, not the filename fallback. So the answer to Jake was DO NOT CUT.
//
// ⚠️ AND NOTE WHAT admin.js GETS RIGHT THAT MY PYTHON TOOLS GOT WRONG: it reads
// the OPF with a real DOM and getAttribute(), so the attribute-order bug that
// silently zeroed `measure.py spine()` on every Standard Ebook (25b) cannot
// happen here. When checking someone else's parser, check for the bug you just
// found in your own.
//
// USAGE
//   python3 extract.py            # refresh extracted.js from admin.js
//   node checkmatter.js <dir-containing-content.opf>
//
// Runs Jake's REAL admin.js functions (extracted verbatim) against every spine
// file of The Prince and the Pauper, to answer one question with evidence
// rather than reasoning: does endnotes.xhtml get typed?
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');
const A = require('./extracted.js');

const dir = process.argv[2] || 'PPW/OEBPS';
const opf = fs.readFileSync(path.join(dir, 'content.opf'), 'utf8');

// Spine order, parsed the way admin.js does it - a real DOM, getAttribute, so
// attribute order cannot matter.
const opfDom = new JSDOM(opf, { contentType: 'text/xml' });
const d = opfDom.window.document;
const idToHref = {};
for (const it of d.getElementsByTagName('item')) {
  idToHref[it.getAttribute('id')] = it.getAttribute('href');
}
const spine = [];
for (const r of d.getElementsByTagName('itemref')) {
  const h = idToHref[r.getAttribute('idref')];
  if (h) spine.push(h);
}

const chapters = [];
for (const href of spine) {
  const p = path.join(dir, href);
  if (!fs.existsSync(p)) { console.log('MISSING', href); continue; }
  const doc = new JSDOM(fs.readFileSync(p, 'utf8'), { contentType: 'application/xhtml+xml' }).window.document;
  const fileKey = path.basename(href);
  const { cls, why } = A.classifyDocument(doc, fileKey);
  const about = A.detectAbout(doc, fileKey, cls);
  chapters.push({ file: fileKey, matter: cls, why, about,
                  title: A.matterTitleFrom(fileKey, cls, 0) });
}
A.assignChapterIds(chapters);

const bodyCount = chapters.filter(c => c.matter === 'body').length;
console.log('file                    matter  id      typed?  about?  why');
console.log('-'.repeat(88));
for (const c of chapters) {
  const typed = c.matter === 'body' ? 'TYPED ' : '  -   ';
  const ab = c.about ? 'About ' : '  -   ';
  console.log(
    `${c.file.padEnd(23)} ${String(c.matter).padEnd(6)} ${String(c.id).padEnd(7)} ${typed}  ${ab}  ${c.why}`);
}
console.log('-'.repeat(88));
console.log('stagedBodyChapters (what "finished the book" is judged on):', bodyCount);
const e = chapters.find(c => /endnotes/.test(c.file));
if (!e) { console.log('=== no endnotes.xhtml in this book ==='); process.exit(0); }
console.log('');
console.log('=== VERDICT FOR endnotes.xhtml ===');
console.log('  matter :', e.matter, '   (' + e.why + ')');
console.log('  id     :', e.id);
console.log('  typed  :', e.matter === 'body' ? 'YES' : 'NO');
console.log('  about  :', e.about ? 'YES' : 'NO');
