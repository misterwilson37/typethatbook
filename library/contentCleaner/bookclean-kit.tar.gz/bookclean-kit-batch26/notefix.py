#!/usr/bin/env python3
"""notefix.py 1.0.0 - BATCH 25. Strip Project Gutenberg `{n}` footnote anchors
from body text, leaving the notes themselves in back matter.

Jake, batch 25: "My concern with the footnotes is less that they're not linked
and more that they're untypable as footnotes. Could they become parentheticals?"

⚠️ THE ANSWER TURNED OUT TO BE NO, AND FOR A BETTER REASON THAN EXPECTED.
All 18 anchors in The Prince and the Pauper fall into three groups, and not one
of them is content a reader needs inline:

  GROUP A - BARE ACADEMIC CITATIONS (5 sites: {4} {5} {6} {8} {9})
      The notes read `Hume.`, `Ib.`, `Hume's England.`, `From 'The English
      Rogue.' London, 1665.` A parenthetical `(Hume)` mid-sentence is WORSE
      than nothing for a 12-year-old - it is a scholar's apparatus, and it
      belongs in back matter where it already is.

  GROUP B - POINTERS TO TWAIN'S OWN NOTES (9 sites, all `{1}`)
      The note reads `For Mark Twain's note see below under the relevant
      chapter heading.` ⚠️ IT IS A POINTER TO A MULTI-PARAGRAPH HISTORICAL
      ESSAY. There is no parenthetical form of a three-paragraph appendix.

  GROUP C - REAL GLOSSES, AND ⚠️ ALL THREE ARE INSIDE DIALOGUE ({2} {3} {7})
      This is what kills the parenthetical idea outright. Each sits mid-speech:
        {2} inside Hendon's `My father is a baronet - one of the smaller lords
            by knight service {2} - Sir Richard Hendon of Hendon Hall`
        {3} inside Hendon's petition to the King
        {7} inside the Ruffler's `counting the dells and doxies and other
            morts. {7}`
      A narrator's antiquarian aside dropped inside a character's line breaks
      the voice on the page and reads as the character explaining himself.
      ⚠️ AND {2} IS ALREADY GLOSSED BY TWAIN IN THE SENTENCE ITSELF - `one of
      the smaller lords by knight service` IS the explanation; the note only
      adds which century's baronets he does not mean.
      ⚠️ AND {7} SHOULD PROBABLY STAY OPAQUE. `Canting terms for various kinds
      of thieves, beggars and vagabonds, AND THEIR FEMALE COMPANIONS` makes a
      prostitution reference legible that is currently invisible to a sixth
      grader. Explaining it is a content decision, not a formatting one.

  GROUP D - DANGLING ({13}, chapter 15)
      ⚠️ NO NOTE {13} EXISTS - the notes stop at {10}. This is present in the
      RAW Gutenberg file too, so it is a SOURCE defect, not a prior-pass
      error. Do not go looking for the note; there isn't one.

So: strip all of them. The notes stay in back matter untouched.

⚠️ WHAT THIS TOOL DOES NOT TOUCH: `endnotes.xhtml`. The `{n}` labels there are
the notes' own headings and one internal anchor, and they are the only thing
making the back matter navigable by eye. Stripping them would leave ten
unlabelled paragraphs.

USAGE
  python3 notefix.py <bookdir> --dry
  python3 notefix.py <bookdir>
  python3 notefix.py --selftest
"""
import os, re, sys, glob, collections

VERSION = '1.0.0'

# Body files only. The notes file keeps its labels - see header.
NOTES_FILES = ('endnotes.xhtml', 'notes.xhtml', 'footnotes.xhtml')

# ⚠️ ORDER MATTERS. The anchors appear in three spacings and a naive
# `{n}` -> '' leaves a double space or a stranded space before punctuation:
#     `knight service {2}-Sir Richard`  -> `knight service -Sir Richard`  WRONG
#     `charity." {1}</p>`               -> `charity." </p>`               WRONG
#     `'prentices{1}-that`              -> `'prentices-that`              right
# Eat the space BEFORE the marker, and any space left dangling after it.
RULES = [
    # ⚠️ FOUR CONTEXT-PRECISE PATTERNS AND NO GENERIC TIDY-UP. READ WHY.
    #
    # Version 1 of this tool ended with two "tidy" rules - a global
    # `('  +' -> ' ')` collapse and a `(' +([,.;:!?])' -> r'\1')`. Between them
    # they silently rewrote TWELVE of Twain's spaced ellipses: `gallows! . . .`
    # became `gallows!...` across six chapters I never meant to open. The
    # reverse-diff caught it.
    #
    # ⚠️ AND THOSE CHANGES WERE ARGUABLY CORRECT - Jake's batch-25 ruling is
    # "normalize ellipses into three periods, no spaces around them". THAT IS
    # PRECISELY WHY IT WAS DANGEROUS: a rule doing the right thing for the
    # wrong reason, inside a tool called `notefix`, is a change no reviewer
    # would think to look for here. Ellipsis normalisation belongs to
    # `typefix.py`, where the ruling is recorded and harnessed.
    #
    # A generic clean-up rule cannot tell the whitespace IT created from the
    # whitespace the author wrote. So every pattern below is anchored to the
    # marker itself and consumes at most the one space beside it.
    ('anchor before a dash',      re.compile(r' ?\{\d+\}(?=[\u2014\u2013-])'), ''),
    ('anchor before a close tag', re.compile(r' ?\{\d+\}(?=\s*</)'), ''),
    ('anchor at end of line',     re.compile(r' ?\{\d+\}(?=[ \t]*(?:\n|$))'), ''),
    ('anchor between two spaces', re.compile(r' \{\d+\}(?= )'), ''),
]


def files(root):
    for base in ('epub/text', 'OEBPS/text', 'OEBPS', 'epub', ''):
        d = os.path.join(root, base) if base else root
        found = sorted(glob.glob(os.path.join(d, '*.xhtml')))
        if found:
            return [f for f in found
                    if os.path.basename(f) not in NOTES_FILES]
    # ⚠️ BATCH 25b: was `return []`, which let run() print a clean report on a
    # book it never opened. Same fix as typefix.py; same reason.
    raise SystemExit(
        f'\n  *** no .xhtml found under {root!r}. Refusing to report '
        f'"0 anchors" on a book that was never opened. ***')


def run(root, dry=True):
    census = collections.Counter()
    per_file = collections.Counter()
    samples = []
    for f in files(root):
        raw = open(f, encoding='utf-8').read()
        n_before = len(re.findall(r'\{\d+\}', raw))
        if not n_before:
            continue
        for m in re.finditer(r'\{(\d+)\}', raw):
            census[int(m.group(1))] += 1
            if len(samples) < 6:
                txt = re.sub(r'<[^>]+>', '', raw)
                mm = re.search(re.escape(m.group(0)), txt)
                if mm:
                    samples.append(' '.join(
                        txt[max(0, mm.start() - 60):mm.end() + 30].split()))
        s = raw
        for _label, pat, repl in RULES:
            s = pat.sub(repl, s)
        left = len(re.findall(r'\{\d+\}', s))
        assert left == 0, f'{f}: {left} anchors survived'
        per_file[os.path.basename(f)] = n_before
        if not dry:
            open(f, 'w', encoding='utf-8').write(s)
    print(f'  {"DRY RUN - nothing written" if dry else "REWRITTEN IN PLACE"}')
    print(f'  {sum(census.values())} anchors in {len(per_file)} body files')
    print('  -- by note number --')
    for n, c in sorted(census.items()):
        print(f'    {{{n}}}  x{c}')
    print('  -- by file --')
    for fn, c in per_file.most_common():
        print(f'    {fn:22s} {c}')
    print('  -- samples (before) --')
    for s in samples:
        print(f'    ...{s}')
    print(f'  (notes file untouched: {", ".join(NOTES_FILES)})')
    return census


def selftest():
    """⚠️ Rule 10. Every spacing form that actually occurs in the book, plus
    the two that a naive strip would corrupt."""
    cases = [
        ("<p>among serving-men and \u2019prentices{1}\u2014that is to say</p>",
         "<p>among serving-men and \u2019prentices\u2014that is to say</p>",
         'anchor welded to the word, em-dash after'),
        ("lords by knight service {2}\u2014Sir Richard",
         "lords by knight service\u2014Sir Richard",
         'spaced anchor before em-dash - a naive strip leaves \u201cservice \u2014Sir\u201d'),
        ("<p>gentleness and charity.\u201d {1}</p>",
         "<p>gentleness and charity.\u201d</p>",
         'anchor at paragraph end - a naive strip leaves a stranded space'),
        ("other morts. {7} Most are here",
         "other morts. Most are here",
         'mid-paragraph anchor between sentences'),
        ("fetch me a storm.\u201d {13}",
         "fetch me a storm.\u201d",
         '\u26a0 the DANGLING anchor - no note 13 exists, present in the raw too'),
        ("to death by the executioner, {9} the boy was filled",
         "to death by the executioner, the boy was filled",
         'anchor after a comma mid-sentence'),
        ("<p>plain text, no anchors at all.</p>",
         "<p>plain text, no anchors at all.</p>",
         'a file with nothing to do is left byte-identical'),
        # ⚠️ REGRESSION GUARD. The first version of this tool rewrote Twain's
        # spaced ellipses via a global double-space collapse - 12 silent
        # changes in six chapters. Ellipses belong to typefix.py. If this case
        # ever fails, notefix has grown a second job.
        ("the gallows! . . . and then . . . nothing",
         "the gallows! . . . and then . . . nothing",
         '\u26a0 spaced ellipses are NOT this tool\u2019s business - scope guard'),
        ("service {2}\u2014Sir Richard and . . . more",
         "service\u2014Sir Richard and . . . more",
         'an anchor is stripped WITHOUT disturbing an ellipsis in the same line'),
    ]
    ok = True
    for src, want, why in cases:
        got = src
        for _l, pat, repl in RULES:
            got = pat.sub(repl, got)
        good = got == want
        ok = ok and good
        print(f'  {"OK  " if good else "FAIL"} {why}')
        if not good:
            print(f'         want {want!r}')
            print(f'         got  {got!r}')
    print(f'\n{len(cases)} cases ran')
    print('SELFTEST PASS' if ok else '*** SELFTEST FAILED ***')
    return ok


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        sys.exit(0 if selftest() else 1)
    run(sys.argv[1], dry='--dry' in sys.argv)
