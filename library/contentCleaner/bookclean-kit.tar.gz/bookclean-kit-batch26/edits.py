#!/usr/bin/env python3
"""edits.py - BATCH 26 edit table as DATA. Dry-run entry point.

Books (all three Gutenberg conversions via ttb-fix-epubs.py, flat OEBPS/ layout):
  TS = appleton-tom-swift-and-his-motor-cycle      (PG #4230)
  RF = emerson-ruth-fielding-of-the-red-mill       (PG #4985)
  BC = warner-the-box-car-children                 (PG #42796)

Jake's rulings, batch 26:
  BC5 (`chinks` next to `Japanese print`): "fine either way, as I don't think
      anyone would associate a Japanese print with a Chinese slur."
      -> LEFT. See BC-X1. The proximity rule stays narrow: PERSON, not object.
  Mercy Curtis: "all of your fixes are fine. If Mercy ever refers to herself as
      lame or crippled, I would keep it there for the same reason you kept her
      bitterness."
      -> ZERO SITES. Verified: Mercy never uses either word about herself.
         See RF-X2 - the ruling is recorded for the rest of the series.
  Mammy 'Liza: approved as tabled.
  Tom Swift: "Let's go with option 2."
      -> FULL DE-DIALECT of Eradicate Sampson. See TS-POLICY.

Row shape: (id, file, old, new, count). new == DELETE -> span removed.

⚠️ ENTITY DISCIPLINE. These files are ONE PARAGRAPH PER LINE (no hard wrapping),
and they use `&quot;` for every double quote and `&#x27;` for every apostrophe -
1,444 + 2,578 of them in TS alone, and ZERO literal `'` or `"` in prose. Rows
below are therefore written in READABLE form and passed through `raw()`, which
is the only place the entity mapping lives (Rule 9).
⚠️ `raw()` deliberately does NOT touch `&`. TS carries six literal `&amp;`
(`Smeak &amp; Katch`, `Swift &amp; Son`, `Reid &amp; Crawford`) and 13c cost a
batch to a bare `&` in a replacement breaking the XML. `check_amp()` refuses to
proceed if any row contains a bare ampersand.
"""
import sys, os

DELETE = '\x00DELETE\x00'

BOOKS = {'TS': 'appleton-tom-swift-and-his-motor-cycle',
         'RF': 'emerson-ruth-fielding-of-the-red-mill',
         'BC': 'warner-the-box-car-children'}
AUTHORS = {'TS': 'Victor Appleton',
           'RF': 'Alice B. Emerson',
           'BC': 'Gertrude Chandler Warner'}
TITLES = {'TS': 'Tom Swift and His Motor-Cycle',
          'RF': 'Ruth Fielding of the Red Mill',
          'BC': 'The Box-Car Children'}
TEXTDIR = 'OEBPS'


def raw(s):
    """Readable string -> the bytes actually in the file. Single owner."""
    if s == DELETE:
        return s
    return s.replace('"', '&quot;').replace("'", '&#x27;')


# ═══════════════════════════════════════════════════════════════════════════
# THE BOX-CAR CHILDREN - 4 rows
#
# 24 scan hits, 20 of them false positives. Second-cleanest book in the corpus
# after Alice. `roosters` x2 fired rawcheck's previous-pass fingerprint and are
# GENUINE BARNYARD - the batch-24 Ozma/Billina case exactly.
#
# BC-X1. ⚠️ `filling in the chinks` (ch. 13) - LEFT BY JAKE'S RULING.
#   It sits ~15 words after `like a Japanese print`, which is the tightest
#   proximity the batch-23 rule could ever see. Jake: "fine either way, as I
#   don't think anyone would associate a Japanese print with a Chinese slur."
#   ⚠️ THE PORTABLE PART: the proximity rule is about an Asian PERSON, not an
#   Asian OBJECT. A woodblock print, a china teapot, a Japanese maple do not
#   arm the word. Do not re-spend this decision, and do not widen the rule.
# BC-X2. `cocked an ear` (ch. 16) - batch-11 narrowing; `cocked` is fine.
# BC-X3. The father's drunkenness (ch. 1) - alcohol calibration, and it is the
#   book's premise. The baker's `beggars` - a character sneering, 14g, and the
#   book answers him inside two pages.
# BC-X4. False positives, do not re-read: `crack` x3, `mistress` x2 (the dog's
#   owner), `lame` (the dog's paw), `queer` x2, `balls` (charred potatoes),
#   `tramps` x2 (the children's own joke name for their home, "Home for
#   Tramps", which is also the last chapter's punchline), `colored rose` (on a
#   handkerchief), `panting` (a locomotive).
# ═══════════════════════════════════════════════════════════════════════════

BC = [

# BC1. `gay` always-fix. The party is a berry-picking expedition coming home.
('BC1', 'chapter-05.xhtml',
 'when the gay party returned to the freight car',
 'when the merry party returned to the freight car', 1),

# BC2. `gay` always-fix. Benny's stuffed bear. `bright` matches the red string.
('BC2', 'chapter-12.xhtml',
 'and a gay collar of braided red string',
 'and a bright collar of braided red string', 1),

# BC3. The bare word `cock`, which fires even though `cocked` would not (11b).
#      The dog is putting his paw on a flash card; `tip` is the ordinary verb.
('BC3', 'chapter-11.xhtml',
 'to see Watch cock his head on one side',
 'to see Watch tip his head on one side', 1),

# BC4. ST6 mark-once-modernised, and the only race marker in the book. He is
#      last year's race winner and Henry's benchmark; the line is admiring and
#      spoken by a small boy. Unmarking him would delete him from a scene in
#      which he beat a college runner.
('BC4', 'chapter-10.xhtml',
 'And the little colored boy over there won it.',
 'And the little Black boy over there won it.', 1),

]


# ═══════════════════════════════════════════════════════════════════════════
# RUTH FIELDING OF THE RED MILL - 51 rows
#
# Three passes: 13 always-fix `ejaculat*`, 2 single-token always-fix, 23
# narratorial disability labels, 5 Mammy 'Liza.
#
# RF-X1. ⚠️ THE DISABILITY ITSELF IS UNTOUCHED AND MUST STAY UNTOUCHED.
#   Mercy Curtis is in a wheel chair; she is savage, bitter, funny and the best
#   thing in the book. Ruth's refusal to pity her is the arc, Uncle Jabez's
#   unexpected tenderness toward her is the subplot, and a surgeon arrives in
#   ch. 23. 14b sub-rule 1 applies in full: DO NOT ERASE THE DISABILITY. What
#   comes out is 23 places where the NARRATOR uses it as her NAME - `the
#   cripple` x13 and `the lame girl` / `the crippled girl` x10 as bare noun
#   substitutes, including in dialogue TAGS (`snapped the cripple`). 14b's
#   adjective-in-passing / defining-label split, plus 14g's narrator-vs-
#   character split, dispose of every one.
#
# RF-X2. ⚠️ JAKE'S SELF-REFERENCE RULING HAS ZERO SITES IN THIS BOOK, AND THAT
#   IS WORTH RECORDING RATHER THAN SILENTLY DROPPING.
#   Jake: "If Mercy ever refers to herself as lame or crippled, I would keep it
#   there for the same reason you kept her bitterness."
#   VERIFIED: she never does. Her self-references are `tied to this chair like
#   I have`, `this old chair`, `when the grape leaves get big enough to hide
#   me`, `I'll never get that far away` - she names the CHAIR, never herself.
#   ⚠️ THE RULING STILL BINDS THE REST OF THE SERIES. Ruth Fielding runs to 30
#   books and Mercy is in most of them; a later volume that has her say the word
#   about herself KEEPS IT. Do not apply this table's pattern mechanically to
#   book 2.
#
# RF-X3. LEFT - characters speaking, 14g:
#   ch-15 Ruth: `"The lame girl, sir?" cried Ruth, in wonder.`
#   ch-20 Aunt Alvirah: `that leetle lame gal ye was tellin' us about`
#   ch-21 Uncle Jabez: `"Who's that? Sam Curtis' gal--the cripple?"`
#   Jabez's is the closest call - he is gruff, not a villain, and it is his only
#   use - but it is how he identifies which girl, and the book spends the next
#   two chapters making him her champion.
#
# RF-X4. LEFT - plain description, not a naming habit:
#   `Tom, crippled as he was` and `her crippled brother` (Tom's broken arm);
#   `the memory of Sam Curtis' crippled daughter` (single identifying use,
#   narrator relaying Jabez's frame).
#   ⚠️ ALSO LEFT, AND FLAGGED RATHER THAN FIXED: `the unfortunate and much to be
#   pitied Mercy` (ch-17). This is narrator sentiment, not naming-by-disability,
#   and it was NOT in the table Jake approved. It sits oddly against Ruth's
#   whole refusal-to-pity arc. Raise it next time rather than fold it in.
#
# RF-X5. False positives, do not re-read: `brave`/`bravely` x7 (all adjectival;
#   the TIER1 `brave` block wants the noun), `japanned` x6 (Uncle Jabez's
#   lacquered cash-box - a finishing term doing no ethnic work, and the batch-22
#   `Turkish fashion` test applies: it names a posture, not a people),
#   `seraglio` x3 (⚠️ A WORD ON THE SPELLING-BEE LIST - it is in the book
#   BECAUSE it is hard to spell, and it is the word Ruth gets right and Rosa
#   gets wrong), `insane` (inside a rhyming spelling list: inane, profane,
#   humane, insane), `cannibalistic` (Ruth's spelling prowess), `pirate` (a head
#   bandage), `asylum`, `bosom` x2, `breast`, `panting`, `little black`
#   (mourning frocks), `colored` (a fawn-colored mastiff).
# ═══════════════════════════════════════════════════════════════════════════

RF = [

# ---------------------------------------------------------------- ejaculat* x13
# Always-fix since batch 3, Jake's upgrade. VARIED per speaker and moment
# rather than collapsed to `exclaimed` thirteen times.

('RF1', 'chapter-02.xhtml',
 '"Plague take the dog!" ejaculated the conductor',
 '"Plague take the dog!" exclaimed the conductor', 1),

('RF2', 'chapter-05.xhtml',
 'ejaculated the same shrill voice.',
 'cried the same shrill voice.', 1),

# RF3. ⚠️ TWO PASSES LAND ON ONE SPAN - the always-fix verb and a narratorial
#      naming-by-disability (`the invalid`). One row, so they cannot collide.
#      `snapped` is the book's own verb for Mercy, used five times elsewhere.
('RF3', 'chapter-05.xhtml',
 'ejaculated the very unpleasant, but much to be pitied invalid.',
 'snapped Mercy.', 1),

('RF4', 'chapter-06.xhtml',
 'ejaculated the amazed Helen.',
 'exclaimed the amazed Helen.', 1),

('RF5', 'chapter-07.xhtml',
 'ejaculated she, rising upright by degrees',
 'cried she, rising upright by degrees', 1),

('RF6', 'chapter-07.xhtml',
 'ejaculated Aunt Alvirah. "How did that happen?"',
 'exclaimed Aunt Alvirah. "How did that happen?"', 1),

('RF7', 'chapter-07.xhtml',
 'her ejaculation was changed to a moan of pain',
 'her exclamation was changed to a moan of pain', 1),

('RF8', 'chapter-07.xhtml',
 'ejaculated Aunt Alviry, again, shaking her head.',
 'exclaimed Aunt Alviry, again, shaking her head.', 1),

('RF9', 'chapter-11.xhtml',
 'ejaculated Uncle Jabez, starting.',
 'exclaimed Uncle Jabez, starting.', 1),

('RF10', 'chapter-20.xhtml',
 'ejaculated Aunt Alvirah. "How did you know?"',
 'cried Aunt Alvirah. "How did you know?"', 1),

# RF11. The noun, not the verb. Aunt Alvirah's back-and-bones refrain.
('RF11', 'chapter-20.xhtml',
 'with many ejaculations of "Oh, my back and oh, my bones!"',
 'with many murmurs of "Oh, my back and oh, my bones!"', 1),

# RF12. `whistled` for `"Whew!"` - the sound the word describes.
('RF12', 'chapter-24.xhtml',
 '"Whew!" ejaculated Tom.',
 '"Whew!" whistled Tom.', 1),

('RF13', 'chapter-25.xhtml',
 'he ejaculated, softly,',
 'he exclaimed, softly,', 1),

# ---------------------------------------------------------------- single tokens

# RF14. `gay` always-fix. A car horn.
('RF14', 'chapter-09.xhtml',
 'when the gay tooting of the Cameron automobile horn',
 'when the cheery tooting of the Cameron automobile horn', 1),

# RF15. `gipsy/gypsy*` always-fix. A fat pony jogging down country lanes; the
#       sense is aimless-and-pleasant, so `rambling` is what the word meant.
('RF15', 'chapter-16.xhtml',
 'in a most delightfully gypsyish way',
 'in a most delightfully rambling way', 1),

# ------------------------------------------------- Mercy Curtis, narrator x23

# RF16. Her parents are the subject; `their daughter's` is warmer and truer to
#       the sentence, which is about their patience with her.
('RF16', 'chapter-05.xhtml',
 'ill-nature on the part of the lame girl',
 'ill-nature on their daughter&#x27;s part', 1),

('RF17', 'chapter-17.xhtml',
 'the outline of the lame girl&#x27;s figure at one of the windows',
 'the outline of Mercy&#x27;s figure at one of the windows', 1),

('RF18', 'chapter-17.xhtml',
 'waved her hand at the lame girl&#x27;s window',
 'waved her hand at Mercy&#x27;s window', 1),

('RF19', 'chapter-17.xhtml',
 'before the lame girl recovered from her amazement',
 'before Mercy recovered from her amazement', 1),

# RF20. `the girl` for the second reference, so the sentence does not say
#       Mercy twice in nine words.
('RF20', 'chapter-17.xhtml',
 'to take the lame girl&#x27;s, but Mercy struck it smartly',
 'to take Mercy&#x27;s, but the girl struck it smartly', 1),

('RF21', 'chapter-17.xhtml',
 'snapped the cripple. "If you&#x27;d been tied to this chair',
 'snapped Mercy. "If you&#x27;d been tied to this chair', 1),

('RF22', 'chapter-17.xhtml',
 'but the cripple only returned her pleasant salutation',
 'but Mercy only returned her pleasant salutation', 1),

('RF23', 'chapter-17.xhtml',
 'to try and bring the cripple to a better mind',
 'to try and bring Mercy to a better mind', 1),

('RF24', 'chapter-17.xhtml',
 'the cripple finally admitted, grudgingly',
 'Mercy finally admitted, grudgingly', 1),

('RF25', 'chapter-17.xhtml',
 'snapped the cripple, chopping off her speech',
 'snapped Mercy, chopping off her speech', 1),

('RF26', 'chapter-17.xhtml',
 'snarled the cripple again.',
 'snarled Mercy again.', 1),

# RF27. RECAST, not swapped - `Mercy` is already the subject of the clause.
('RF27', 'chapter-17.xhtml',
 'That the thought pleased Mercy, the cripple could not deny.',
 'That the thought pleased her, Mercy could not deny.', 1),

('RF28', 'chapter-17.xhtml',
 'said the cripple&#x27;s mother,',
 'said Mercy&#x27;s mother,', 1),

('RF29', 'chapter-17.xhtml',
 'The cripple&#x27;s mind was evidently coaxed',
 'Mercy&#x27;s mind was evidently coaxed', 1),

('RF30', 'chapter-17.xhtml',
 'smiling at the cripple in the window',
 'smiling at Mercy in the window', 1),

# RF31. RECAST - `Mercy` is not in the sentence, but Ruth is stooping to her,
#       so the pronoun is unambiguous and lighter.
('RF31', 'chapter-21.xhtml',
 'stooping to kiss the crippled girl.',
 'stooping to kiss her.', 1),

('RF32', 'chapter-22.xhtml',
 'and of the fancy the lame girl had taken for Uncle Jabez',
 'and of the fancy she had taken for Uncle Jabez', 1),

('RF33', 'chapter-22.xhtml',
 'declared the lame girl. "I asked Doctor Davison',
 'declared Mercy. "I asked Doctor Davison', 1),

('RF34', 'chapter-22.xhtml',
 'that way was not the way to the cripple&#x27;s heart',
 'that way was not the way to Mercy&#x27;s heart', 1),

('RF35', 'chapter-22.xhtml',
 'Uncle Jabez had taken in the crippled girl',
 'Uncle Jabez had taken in Mercy', 1),

('RF36', 'chapter-22.xhtml',
 'said the crippled girl, in her sharp way',
 'said Mercy, in her sharp way', 1),

# RF37. `the girl` again - the previous sentence already names Mercy.
('RF37', 'chapter-22.xhtml',
 'she took the lame girl seriously in her ugly moods',
 'she took the girl seriously in her ugly moods', 1),

('RF38', 'chapter-22.xhtml',
 'For a moment the cripple was silent',
 'For a moment Mercy was silent', 1),

('RF39', 'chapter-22.xhtml',
 'murmured the crippled girl. "I want to be alone.',
 'murmured Mercy. "I want to be alone.', 1),

('RF40', 'chapter-23.xhtml',
 'or little to say at first to the crippled girl',
 'or little to say at first to Mercy herself', 1),

# RF41. RECAST - `the removal of Mercy` reads like freight; the doctor is
#       helping her indoors.
('RF41', 'chapter-23.xhtml',
 'superintended the removal of the cripple into the house',
 'superintended getting her into the house', 1),

('RF42', 'chapter-23.xhtml',
 'for a time at least, in the cripple&#x27;s room',
 'for a time at least, in Mercy&#x27;s room', 1),

# RF48 and RF49. ⚠️ FOUND BY THE POST-APPLY RESIDUAL SCAN, NOT BY MY READING.
#   I tabled "26 narratorial sites" and wrote 25 rows; these two are the same
#   class, the same token and the same ruling, and I simply missed them.
#   ⚠️ THE REASON RF49 ESCAPED IS A PATTERN GAP OF MY OWN MAKING: I enumerated
#   the sites with a grep for `the crippled girl`, and this one reads `the
#   LITTLE crippled girl`. An intervening adjective defeated the pattern - the
#   same shape as `/\bpecker\b/` (16a) and the written `gay*` stem that cannot
#   reach `gaiety` (25j). ⚠️ WHEN ENUMERATING SITES FOR A TABLE, ALLOW FOR AN
#   INTERVENING WORD: `the [a-z]* cripple`, not `the cripple`. Third time in
#   this project that the verification battery caught what the reading did not.
('RF48', 'chapter-17.xhtml',
 'The crippled girl was in her wheel chair by the window.',
 'Mercy was in her wheel chair by the window.', 1),

('RF49', 'chapter-23.xhtml',
 'so intent a look that the little crippled girl was half frightened',
 'so intent a look that the girl was half frightened', 1),

# --------------------------------------------- `the invalid` x4, JAKE'S BATCH-26 RULING
# Jake: "If Mercy is calling herself an invalid, then it stays. If it's someone
# else - including the narrator calling her that - then it needs to be updated."
# ⚠️ VERIFIED: Mercy never uses the word. All four are the narrator or Ruth's
# point of view, so all four go. This is the SAME instrument as the `the
# cripple` pass and the same 14g split; `invalid` was simply a token I failed to
# enumerate when I built the table, which is the RF49 lesson repeating within one
# batch - I greped the labels I expected instead of reading for the FUNCTION.
# ⚠️ A FIFTH INSTANCE WAS ALREADY FIXED as row RF3 (`ejaculated the very
# unpleasant, but much to be pitied invalid` -> `snapped Mercy`), because it
# shared a span with an approved always-fix row. Shipping four unfixed beside one
# fixed is what made this need a ruling rather than my judgment.

# RF50. ⚠️ THE ONE THAT IS NOT STRICTLY COVERED BY THE RULING, taken anyway.
#       Generic plural describing a KIND of chair - Mercy is not present and is
#       not being called anything ("of the occupant of either she saw not a
#       sign"). Included because the replacement is lossless and leaving one
#       `invalid` standing after removing four would be the inconsistency the
#       ruling exists to end. Say so rather than fold it in silently.
('RF50', 'chapter-05.xhtml',
 'such as Ruth knew was used by invalids who could not walk',
 'such as Ruth knew was used by people who could not walk', 1),

# RF51. Ruth has not learned her name yet - the next line of dialogue is where
#       `Mercy` first appears - so the replacement cannot be the name. The chair
#       has just been described, so it is the reference the reader already has.
('RF51', 'chapter-05.xhtml',
 'which Ruth supposed must belong to the invalid.',
 'which Ruth supposed must belong to the child in the wheel-chair.', 1),

# RF52. Mercy IS named, one sentence earlier ("for child Mercy Curtis was").
('RF52', 'chapter-05.xhtml',
 'To Ruth&#x27;s surprise the first greeting of the invalid was a most ill-natured one.',
 'To Ruth&#x27;s surprise Mercy&#x27;s first greeting was a most ill-natured one.', 1),

# RF53. Mercy is named in the same clause, which is what made this the clearest
#       of the four and the reason the question was worth asking.
('RF53', 'chapter-23.xhtml',
 'running in to see Mercy, or to bring something for the invalid.',
 'running in to see Mercy, or to bring her something.', 1),

# ------------------------------------------------------- Mammy 'Liza, ch-16 x5
# A walk-on cluster in ONE scene. 'Liza never appears on the page - she is
# referred to three times and cooks. The child who brings the tray is nameless,
# has one line, and is described by her hair. Batch-11 Chump Cyril ruling: full
# unmark, because three lines of stock business is not a portrayal worth
# protecting. The doctor's affection for 'Liza survives without the honorific.

('RF43', 'chapter-16.xhtml',
 'He&#x27;s got a colored Mammy for cook who makes the most wonderful jumbles',
 'He&#x27;s got a cook who makes the most wonderful jumbles', 1),

('RF44', 'chapter-16.xhtml',
 'the opportunity of judging Mammy &#x27;Liza&#x27;s goodies for herself',
 'the opportunity of judging &#x27;Liza&#x27;s goodies for herself', 1),

# RF45. ⚠️ THE BODY BUSINESS IS THE MARKING, not the label. `wool` for hair,
#       `brown head`, and hair `like tiny horns` is the batch-14 white-teeth
#       template: a feature offered as the notable thing about a person whose
#       colour has just been named. The pigtails stay - she is a small girl with
#       her hair in pigtails, which is a real and harmless image.
('RF45', 'chapter-16.xhtml',
 'when a little colored girl with her wool "done" in innumerable pigtails, like tiny horns, and sticking out all over her brown head in every direction, came in with a tray',
 'when a little girl with her hair in innumerable pigtails, sticking out in every direction, came in with a tray', 1),

# RF46. Option B on one line: respellings out, colloquial grammar KEPT.
#       `as how you-all` is her voice and stays; `hongry`/`aftah`/`yo'` are
#       spellings a student types letter by letter and go.
('RF46', 'chapter-16.xhtml',
 '"&#x27;Liza done sez as how yo&#x27;-all might be hongry aftah yo&#x27; ride,"',
 '"&#x27;Liza done says as how you-all might be hungry after your ride,"', 1),

('RF47', 'chapter-16.xhtml',
 '"That&#x27;s Mammy &#x27;Liza all over,"',
 '"That&#x27;s &#x27;Liza all over,"', 1),

]


# ═══════════════════════════════════════════════════════════════════════════
# TOM SWIFT AND HIS MOTOR-CYCLE - 95 rows. OPTION B, JAKE'S RULING.
#
# TS-POLICY. ⚠️ READ THIS BEFORE ADDING, REMOVING OR "IMPROVING" ANY TS ROW.
#
# Jake, batch 26: "Let's go with option 2." That is batch-14's option B applied
# to Eradicate Andrew Jackson Abraham Lincoln Sampson - the elderly Black
# whitewasher who appears in ch. 7, 8, 10, 17, 20, 21 and 22, and whose
# information cracks the case in ch. 22 ("Dad, I've got a clew!").
#
# THE DIAGNOSTIC, from Mammy Jinny (14): separate the JOKE from the MARKING.
#
#   STRIPPED - phonetic respellings, i.e. letter strings that are not words and
#   that a student would type one character at a time with no idea what is
#   coming:
#     dat/dis/dese/dey/dem/dere/den/de -> that/this/these/they/them/there/
#     then/the; ob -> of; yo' -> you/your; mah -> my; suah -> sure;
#     suttinly -> certainly; gwine -> going; heah, dis yeah -> here, this here;
#     wif/wid -> with; dar -> there; lib -> live; wuk -> work; eber -> ever;
#     neber -> never; hab -> have; laik -> like; sah -> sir; Yais -> Yes;
#     Mistah -> Mister; I'se -> I'm / I've; doan't -> don't; kin -> can;
#     whar -> where; anudder -> another; t'ing/t'ink/t'row -> thing/think/throw;
#     wuss -> worse; radder -> rather; seberal -> several; cobered -> covered;
#     sabed -> saved; spah -> spare; mattah -> matter; truff -> truth;
#     summah -> summer; moah -> mower; bresh -> brush; hoss -> horse;
#     tech -> touch; askeered -> scared; laffin' -> laughin'; figgers ->
#     figures; reg'lar -> regular; uster -> used to; ginnerally -> generally;
#     perfessions -> professions; gen'men -> gentleman; axes -> asks;
#     Suffin' -> Somethin'; fitten -> fitting; wah -> war; inter -> into;
#     onct -> once; eben -> even; gib -> give; trabeled -> traveled.
#
#   KEPT - grammar and general vernacular, because 14 says so in as many words
#   ("Keep the colloquial grammar - stripping that too makes the servant speak
#   like the mistress, which is its own erasure"), and because these are
#   correctly-spelled words a touch-typist can predict:
#     zero copula and `am`/`is` substitution: `dat's what I is`, `de mule am
#     still alive`, `Does yo' t'ink I can?`, `yo' has got a memory`, `he do`,
#     `I feels`, `I guarantees`, `I saws de wood`, `it suah do work`;
#     double negatives: `I ain't never had no liverage`, `it won't cut no
#     grass`; relative `what`: `de man what I'm wukin' wif`;
#     g-dropping (`fixin'`, `whitewashin'`, `helpin'`) and the elisions the
#     book ALSO gives its white characters: an', t', fer, git, jest, ef,
#     'scuse, 'clar, 'preciate, 'specially, 'vested, 'tic'lar, allers, pow'ful,
#     ole, indeedy, G'lang, Good landy, Good land o' massy, Golly.
#
#   ⚠️ EVERY MALAPROPISM IS KEPT, WITHOUT EXCEPTION. They are the character's
#   actual running gag, they are separable from the spelling, and they all work
#   in standard English:
#     `de most outrageous quadruped dat ever CIRCUMLOCUTED` (ch. 8)
#     `I ain't never had no LIVERAGE on dis wagon` / the livery-stable riff
#       (ch. 8) - the longest joke in the book and it survives intact
#     `a CONJURE-MAN when it comes t' fixin' wagons` (ch. 8)
#     `dat MONSTROUSNESS machine` (ch. 8)
#     `I didn't know mah lawn-moah was named PAUL` for `pawl` (ch. 17)
#     `I'll EXPLANATION it to yo'` (ch. 20)
#     `What's dat 'bout MUSH?` for `mesh` (ch. 21)
#
#   RACE LABELS, 37 sites - `darky` x10, `negro` x7, `colored man/men` x27,
#   `nigger` x1, `coon` x2. ST6 mark-once applies at the FIRST introduction
#   (ch. 7, row T1: `an old colored man` -> `an old Black man`, modernised per
#   Jake's batch-8 preference for the modern word). Every later narratorial
#   repetition is unmarked, VARIED across `the driver` (⚠️ the book's own word,
#   supplied two paragraphs later - "either the driver could not understand"),
#   `the old man`, `Eradicate`, `the whitewasher`, `the sawyer`, and pronouns.
#   `nigger` and both `coon` are in HIS OWN MOUTH, which under batch 9 and 14g
#   changes nothing: he is the sympathetic character, not the villain.
#
# ⚠️ TS-X1. THE TRAMP'S DIALECT IS A PLOT DEVICE AND IS NOT TOUCHED. NOT ONE
#   TOKEN. Happy Harry (ch. 11, 19, 20) speaks Bowery cant - `youse`, `dat`,
#   `de`, `cully`, `fer`, `nuttin'` - and TOM SOLVES THE MYSTERY BY NOTICING IT
#   SLIP: "The tramp in his second remarks used language more in keeping with
#   his character, whereas, in his first surprise and anger, he had talked much
#   as any other person would." Two paragraphs later Tom spots the false beard.
#   A pass that regularised this dialect would delete the clue. It is also not
#   racial. ⚠️ The interviewed hobo in ch. 20 likewise keeps `dat`, `de` and
#   `fer` - so this book has TWO dialect speakers with OPPOSITE rulings, the
#   batch-10 Prito/Rocco shape pointed at dialect instead of at caricature.
#   ASSERTED AT COUNT IN verify.py LEAVES, per batch 25's rule that a keep-it
#   ruling lives in a harness and not in prose.
#
# TS-X2. FLAGGED, NOT EDITED - a portrayal fact with no vocabulary to strip.
#   Ch. 21: `I uster wuk dere befo' de wah` - Eradicate worked at the Harkness
#   mansion before the Civil War, and the book never says in what capacity.
#   `since quality folks libed dere` is his own phrase for the family. This is
#   the batch-9 rule: slavery is never glossed, and the only question is whether
#   the text treats him as a person. It does - he is the one who knows the house,
#   and that knowledge is what breaks the case. The respellings go; the history
#   stays. Do not "resolve" it.
#
# TS-X3. False positives, do not re-read: `queer` x10 (strange; corpus ruling),
#   `savage` x2 (a bulldog), `savagely` x2 (Andy Foger's temper), `injunction`,
#   `member(s)` x4 (a law firm's junior partner; Tom's own arms and legs),
#   `shack` x3 / `shanty` x2 (the engineer's room, a charcoal-burner's hut),
#   `little black mustache`, `tramp*` x75 (Happy Harry is the antagonist and it
#   is the book's own plot vocabulary), `hell` -> `Hello`.
# ═══════════════════════════════════════════════════════════════════════════

TS = [

# ============================================================ ch-07: the crash
# T1. ⚠️ ST6 MARK-ONCE. His first appearance in the book, modernised. Every
#     later narratorial marker is unmarked; this one stays so he does not become
#     invisible (batch-8 ruling, and batch-9 on ethnonyms).
('T1', 'chapter-07.xhtml',
 'Beside the animal walked an old colored man.',
 'Beside the animal walked an old Black man.', 1),

# T2. `the driver` is APPLEDON'S OWN WORD, two paragraphs down. Prefer the
#     author's alternative term over an invented one.
('T2', 'chapter-07.xhtml',
 'cried Tom to the negro.',
 'cried Tom to the driver.', 1),

('T3', 'chapter-07.xhtml',
 'The darky looked up.',
 'The old man looked up.', 1),

# T4. `Suffin'` -> `Somethin'`: the g-drop is kept, the respelling of `some`
#     goes.
('T4', 'chapter-07.xhtml',
 'cried the negro. "Whoa! Suffin&#x27;s gwine t&#x27; happen!"',
 'cried the driver. "Whoa! Somethin&#x27;s going t&#x27; happen!"', 1),

('T5', 'chapter-07.xhtml',
 'The colored man hurried to the head of the animal',
 'The old man hurried to the head of the animal', 1),

('T6', 'chapter-07.xhtml',
 '"Whoa, Boomerang! Jest yo&#x27; stand still!" he said.',
 '"Whoa, Boomerang! Jest you stand still!" he said.', 1),

('T7', 'chapter-07.xhtml',
 'He struck the darky with the front wheel.',
 'He struck the old man with the front wheel.', 1),

('T8', 'chapter-07.xhtml',
 'As it was, the colored man was gently lifted away',
 'As it was, the driver was gently lifted away', 1),

('T9', 'chapter-07.xhtml',
 'The colored man was sitting up, looking dazed.',
 'The old man was sitting up, looking dazed.', 1),

('T10', 'chapter-07.xhtml',
 'he murmured. "Suffin&#x27;s happened!"',
 'he murmured. "Somethin&#x27;s happened!"', 1),

('T11', 'chapter-07.xhtml',
 'hurried to where the colored man was sitting.',
 'hurried to where the old man was sitting.', 1),

# ===================================================== ch-08: the introduction
('T12', 'chapter-08.xhtml',
 'and stood beside the negro.',
 'and stood beside the old man.', 1),

# T13. `I is` KEPT (grammar). `dat ar' mule` -> `that there mule`, which is the
#      same dialect idiom in typable spelling. `am still alive` KEPT.
('T13', 'chapter-08.xhtml',
 'repeated the darky. "I&#x27;se killed, dat&#x27;s what I is! I ain&#x27;t got a whole bone in mah body! Good landy, but I suttinly am in a awful state! Would yo&#x27; mind tellin&#x27; me if dat ar&#x27; mule am still alive?"',
 'repeated the old man. "I&#x27;m killed, that&#x27;s what I is! I ain&#x27;t got a whole bone in my body! Good landy, but I certainly am in a awful state! Would you mind tellin&#x27; me if that there mule am still alive?"', 1),

# T14. ⚠️ THE BOOK'S ONE n-WORD, and it is Eradicate about himself. Batch 9 and
#      14g both say the speaker being sympathetic is not a reason to keep it -
#      it is the reason it has to go. `this here old fellow` keeps the
#      self-deprecating joke, which is the point of the line.
('T14', 'chapter-08.xhtml',
 '"No, sah! No, indeedy, sah!" replied the colored man. "Yo&#x27; doan&#x27;t catch dis yeah nigger lookin&#x27; around!"',
 '"No, sir! No, indeedy, sir!" replied the old man. "You don&#x27;t catch this here old fellow lookin&#x27; around!"', 1),

# T15. `am yo' suah` -> `am you sure`: the copula substitution is grammar and
#      stays; only the spellings change.
('T15', 'chapter-08.xhtml',
 '"Why not? &#x27;Cause I&#x27;ll tell yo&#x27; why not. I&#x27;m so stiff an&#x27; I&#x27;m so nearly broke t&#x27; pieces, dat if I turn mah head around it suah will twist offen mah body. No, sah! No, indeedy, sah, I ain&#x27;t gwine t&#x27; turn &#x27;round. But am yo&#x27; suah dat mah mule Boomerang ain&#x27;t hurted?"',
 '"Why not? &#x27;Cause I&#x27;ll tell you why not. I&#x27;m so stiff an&#x27; I&#x27;m so nearly broke t&#x27; pieces, that if I turn my head around it sure will twist off of my body. No, sir! No, indeedy, sir, I ain&#x27;t going t&#x27; turn &#x27;round. But am you sure that my mule Boomerang ain&#x27;t hurted?"', 1),

# T16. ⚠️ `circumlocuted` KEPT. Malapropism, and the best line he has.
('T16', 'chapter-08.xhtml',
 '"Oh, dat&#x27;s all right. Doan&#x27;t mind me," went on the colored man. "It was mah fault fer gittin in de road. But dat mule Boomerang am suttinly de most outrageous quadruped dat ever circumlocuted."',
 '"Oh, that&#x27;s all right. Don&#x27;t mind me," went on the old man. "It was my fault fer gittin in the road. But that mule Boomerang am certainly the most outrageous quadruped that ever circumlocuted."', 1),

('T17', 'chapter-08.xhtml',
 'asked Tom, wondering if the negro really was hurt.',
 'asked Tom, wondering if the old man really was hurt.', 1),

# T18. ⚠️ THE AUSTRALIAN ASIDE - found by gapcheck's phrase-form race-label
#      probe (`black man` x1), which scan.py cannot see at all. `dem Australian
#      black mans what go around wid a circus` puts Aboriginal Australians on
#      display as a circus exhibit, which really happened and which they were
#      on the receiving end of (batch-10: historically real is a reason to
#      CHECK, not a reason to keep). ⚠️ THE JOKE DOES NOT NEED THEM - the joke
#      is the stick, and it survives whole.
('T18', 'chapter-08.xhtml',
 '"What fo&#x27; I call him Boomerang? Did yo&#x27; eber see dem Australian black mans what go around wid a circus t&#x27;row dem crooked sticks dey calls boomerangs?"',
 '"What fo&#x27; I call him Boomerang? Did you ever see those crooked sticks they throw at a circus, what they calls boomerangs?"', 1),

('T19', 'chapter-08.xhtml',
 '"Well, Boomerang, mah mule, am jest laik dat. He&#x27;s crooked, t&#x27; begin wid, an&#x27; anudder t&#x27;ing, yo&#x27; can&#x27;t never tell when yo&#x27; start him whar he&#x27;s gwine t&#x27; land up. Dat&#x27;s why I calls him Boomerang."',
 '"Well, Boomerang, my mule, am jest like that. He&#x27;s crooked, t&#x27; begin with, an&#x27; another thing, you can&#x27;t never tell when you start him where he&#x27;s going t&#x27; land up. That&#x27;s why I calls him Boomerang."', 1),

# T20. `Does yo' t'ink` -> `Does you think`. KEEPS the nonstandard `Does you`.
('T20', 'chapter-08.xhtml',
 '"Does yo&#x27; t&#x27;ink I can?"',
 '"Does you think I can?"', 1),

('T21', 'chapter-08.xhtml',
 'but folks most ginnerally calls me Eradicate Sampson, an&#x27; some doan&#x27;t eben go to dat length. Dey jest calls me Rad, fo&#x27; short."',
 'but folks most generally calls me Eradicate Sampson, an&#x27; some don&#x27;t even go to that length. They jest calls me Rad, fo&#x27; short."', 1),

('T22', 'chapter-08.xhtml',
 '"Well, yo&#x27; see I eradicates de dirt. I&#x27;m a cleaner an&#x27; a whitewasher by profession, an&#x27; somebody gib me dat name. Dey said it were fitten an&#x27; proper, an&#x27; I kept it eber sence. Yais, sah, I&#x27;se Eradicate Sampson, at yo&#x27; service. Yo&#x27; ain&#x27;t got no chicken coops yo&#x27; wants cleaned out, has yo&#x27;? Or any stables or fences t&#x27; whitewash? I guarantees satisfaction."',
 '"Well, you see I eradicates the dirt. I&#x27;m a cleaner an&#x27; a whitewasher by profession, an&#x27; somebody give me that name. They said it were fitting an&#x27; proper, an&#x27; I kept it ever since. Yes, sir, I&#x27;m Eradicate Sampson, at your service. You ain&#x27;t got no chicken coops you wants cleaned out, has you? Or any stables or fences t&#x27; whitewash? I guarantees satisfaction."', 1),

('T23', 'chapter-08.xhtml',
 'as good a means as any of placating the darky.',
 'as good a means as any of placating the old man.', 1),

('T24', 'chapter-08.xhtml',
 '"I guess not. I feels better now. Where am dat work yo&#x27; was speakin&#x27; ob?"',
 '"I guess not. I feels better now. Where am that work you was speakin&#x27; of?"', 1),

('T25', 'chapter-08.xhtml',
 '"Yais, sah, I guess I be. Whar did yo&#x27; say, yo&#x27; had some whitewashin&#x27; t&#x27; do?"',
 '"Yes, sir, I guess I be. Where did you say, you had some whitewashin&#x27; t&#x27; do?"', 1),

('T26', 'chapter-08.xhtml',
 '"Yais, sah, I&#x27;ll be sure to call,"',
 '"Yes, sir, I&#x27;ll be sure to call,"', 1),

('T27', 'chapter-08.xhtml',
 'Tom told the colored man how to find the Swift home',
 'Tom told him how to find the Swift home', 1),

('T28', 'chapter-08.xhtml',
 'when he noticed that the negro was tying one wheel',
 'when he noticed that the old man was tying one wheel', 1),

('T29', 'chapter-08.xhtml',
 '"Got to, t&#x27; git downhill wid dis load ob fence posts," was the answer. "Ef I didn&#x27;t it would be right on to de heels ob Boomerang, an&#x27; wheneber he feels anyt&#x27;ing on his heels he does act wuss dan a circus mule."',
 '"Got to, t&#x27; git downhill with this load of fence posts," was the answer. "Ef I didn&#x27;t it would be right on to the heels of Boomerang, an&#x27; whenever he feels anything on his heels he does act worse than a circus mule."', 1),

('T30', 'chapter-08.xhtml',
 '"&#x27;Scuse me, Mistah Swift, &#x27;scuse me!" exclaimed Eradicate quickly. "But yo&#x27; doan&#x27;t know dat brake. It&#x27;s wuss dan none at all. It doan&#x27;t work, fer a fact. No, indeedy, sah. I&#x27;se got to rope de wheel."',
 '"&#x27;Scuse me, Mister Swift, &#x27;scuse me!" exclaimed Eradicate quickly. "But you don&#x27;t know that brake. It&#x27;s worse than none at all. It don&#x27;t work, fer a fact. No, indeedy, sir. I&#x27;ve got to rope the wheel."', 1),

('T31', 'chapter-08.xhtml',
 'The colored man looked on in open-mouthed amazement',
 'Eradicate looked on in open-mouthed amazement', 1),

('T32', 'chapter-08.xhtml',
 '"&#x27;Scuse me, Mistah Swift, but what&#x27;s dat yo&#x27; said?"',
 '"&#x27;Scuse me, Mister Swift, but what&#x27;s that you said?"', 1),

# T33. ⚠️ `liverage` KEPT - and so is the entire livery-stable misunderstanding
#      that follows from it. This is the longest joke in the book, Tom lets it
#      go rather than explain, and it works in plain English exactly as written.
('T33', 'chapter-08.xhtml',
 '"No, sah, Mistah Swift, &#x27;scuse me, but yo&#x27; made a slight mistake. I ain&#x27;t never had no liverage on dis yeah wagon. It ain&#x27;t dat kind ob a wagon. I onct drove a livery rig, but dat were some years ago. I ain&#x27;t worked fo&#x27; de livery stable in some time now. Dat&#x27;s why I know dere ain&#x27;t no livery on dis wagon. Yo&#x27;ll &#x27;scuse me, but yo&#x27; am slightly mistaken."',
 '"No, sir, Mister Swift, &#x27;scuse me, but you made a slight mistake. I ain&#x27;t never had no liverage on this here wagon. It ain&#x27;t that kind of a wagon. I once drove a livery rig, but that were some years ago. I ain&#x27;t worked fo&#x27; the livery stable in some time now. That&#x27;s why I know there ain&#x27;t no livery on this wagon. You&#x27;ll &#x27;scuse me, but you am slightly mistaken."', 1),

('T34', 'chapter-08.xhtml',
 'and seeing that the colored man was able to mount',
 'and seeing that Eradicate was able to mount', 1),

# T35. `it suah do work` -> `it sure do work`. `do` KEPT twice: grammar.
('T35', 'chapter-08.xhtml',
 '"It suah do work, Mistah Swift!" called the darky to Tom, who was waiting the result of his little repair job. "It suah do work!"',
 '"It sure do work, Mister Swift!" called Eradicate to Tom, who was waiting the result of his little repair job. "It sure do work!"', 1),

# T36. ⚠️ `conjure-man` KEPT. Malapropism-adjacent and entirely his own idiom.
('T36', 'chapter-08.xhtml',
 '"Mah golly! But yo&#x27; am suttinly a conjure-man when it comes t&#x27; fixin&#x27; wagons! Did yo&#x27; eber work fer a blacksmith?"',
 '"My golly! But you am certainly a conjure-man when it comes t&#x27; fixin&#x27; wagons! Did you ever work fer a blacksmith?"', 1),

('T37', 'chapter-08.xhtml',
 'speeded off ahead of the colored man and his rig',
 'speeded off ahead of Eradicate and his rig', 1),

# T38. ⚠️ `monstrousness` KEPT. Malapropism.
('T38', 'chapter-08.xhtml',
 '"Mah golly! He suttinly go laik de wind! An&#x27; t&#x27; t&#x27;ink dat I were hit by dat monstrousness machine, an&#x27; not hurted! Mah golly! T&#x27;ings am suttinly happenin&#x27;! G&#x27;lang, Boomerang!"',
 '"My golly! He certainly go like the wind! An&#x27; t&#x27; think that I were hit by that monstrousness machine, an&#x27; not hurted! My golly! Things am certainly happenin&#x27;! G&#x27;lang, Boomerang!"', 1),

# ====================================================== ch-10: the whitewashing
('T39', 'chapter-10.xhtml',
 '"Whoa dar, Boomerang!" exclaimed a voice, and Eradicate Sampson hurried around the corner of the house. "Dat&#x27;s jest lake yo&#x27;," went on the colored man. "Movin&#x27; when yo&#x27; ain&#x27;t wanted to." Then, as he caught sight of Tom, he exclaimed, "Why, if it ain&#x27;t young Mistah Swift! Good lordy! But dat livery brake yo&#x27; done fixed on mah wagon suttinly am fine. Ah kin go down de steepest hill widout ropin&#x27; de wheel."',
 '"Whoa there, Boomerang!" exclaimed a voice, and Eradicate Sampson hurried around the corner of the house. "That&#x27;s jest like you," went on the old man. "Movin&#x27; when you ain&#x27;t wanted to." Then, as he caught sight of Tom, he exclaimed, "Why, if it ain&#x27;t young Mister Swift! Good lordy! But that livery brake you done fixed on my wagon certainly am fine. I can go down the steepest hill without ropin&#x27; the wheel."', 1),

('T40', 'chapter-10.xhtml',
 '"Yais, sah, I done did. I found I had some time t&#x27; spah, an&#x27; thinks I dere might be some whitewashin&#x27; I could do. Yo&#x27; see, I lib only &#x27;bout two mile from heah."',
 '"Yes, sir, I done did. I found I had some time t&#x27; spare, an&#x27; thinks I there might be some whitewashin&#x27; I could do. You see, I live only &#x27;bout two mile from here."', 1),

('T41', 'chapter-10.xhtml',
 'The darky was soon at work.',
 'The old man was soon at work.', 1),

('T42', 'chapter-10.xhtml',
 '"Why, de whitewash done persist in runnin&#x27; down de bresh handle an&#x27; inter mah sleeve. I&#x27;m soakin&#x27; wet from it now, an&#x27; I has t&#x27; stop ebery onct in a while &#x27;case mah sleeve gits full."',
 '"Why, the whitewash done persist in runnin&#x27; down the brush handle an&#x27; into my sleeve. I&#x27;m soakin&#x27; wet from it now, an&#x27; I has t&#x27; stop every once in a while &#x27;case my sleeve gits full."', 1),

('T43', 'chapter-10.xhtml',
 'The colored man was very willing to take a rest',
 'Eradicate was very willing to take a rest', 1),

('T44', 'chapter-10.xhtml',
 'handing the brush back to the negro, told him to try it',
 'handing the brush back to the old man, told him to try it', 1),

('T45', 'chapter-10.xhtml',
 '"Did yo&#x27; done put a charm on mah bresh?"',
 '"Did you done put a charm on my brush?"', 1),

('T46', 'chapter-10.xhtml',
 'The darky dipped his brush in the pail of whitewash',
 'The old man dipped his brush in the pail of whitewash', 1),

('T47', 'chapter-10.xhtml',
 '"Well, I &#x27;clar t&#x27; goodness! That suttinly am a mighty fine charm!" cried the colored man. "Yo&#x27; suah am a pert gen&#x27;men, all right. Now I kin work widout stoppin&#x27; t&#x27; empty mah sleeve ob lime juice ebery minute. I&#x27;se suttinly obliged t&#x27; yo&#x27;."',
 '"Well, I &#x27;clar t&#x27; goodness! That certainly am a mighty fine charm!" cried Eradicate. "You sure am a pert gentleman, all right. Now I can work without stoppin&#x27; t&#x27; empty my sleeve of lime juice every minute. I&#x27;m certainly obliged t&#x27; you."', 1),

('T48', 'chapter-10.xhtml',
 '"Doan&#x27;t do dat! Doan&#x27;t do dat!" begged Eradicate earnestly. "Dis, an&#x27; makin&#x27; dirt disappear, am de only perfessions I got. Doan&#x27;t go &#x27;ventin&#x27; no machine, Mistah Swift."',
 '"Don&#x27;t do that! Don&#x27;t do that!" begged Eradicate earnestly. "This, an&#x27; makin&#x27; dirt disappear, am the only professions I got. Don&#x27;t go &#x27;ventin&#x27; no machine, Mister Swift."', 1),

# T49. `Then you going` keeps the zero copula.
('T49', 'chapter-10.xhtml',
 '"Ha, ha! Den yo&#x27; gwine t&#x27; wait a pow&#x27;ful long time," chuckled Eradicate',
 '"Ha, ha! Then you going t&#x27; wait a pow&#x27;ful long time," chuckled Eradicate', 1),

# ======================================================== ch-17: the lawn-mower
('T50', 'chapter-17.xhtml',
 'mused Tom, for the colored man was out of the wagon',
 'mused Tom, for the old man was out of the wagon', 1),

('T51', 'chapter-17.xhtml',
 'The colored man was pushing a lawn-mower slowly to and fro',
 'The old man was pushing a lawn-mower slowly to and fro', 1),

('T52', 'chapter-17.xhtml',
 'at the sound of Tom&#x27;s motor-cycle the negro looked up',
 'at the sound of Tom&#x27;s motor-cycle he looked up', 1),

('T53', 'chapter-17.xhtml',
 '"Mattah, Mistah Swift? Why, dere&#x27;s a pow&#x27;ful lot de mattah, an&#x27; dat&#x27;s de truff. I&#x27;se been swindled, dat&#x27;s what I has."',
 '"Matter, Mister Swift? Why, there&#x27;s a pow&#x27;ful lot the matter, an&#x27; that&#x27;s the truth. I&#x27;ve been swindled, that&#x27;s what I has."', 1),

('T54', 'chapter-17.xhtml',
 '"Well, it&#x27;s dis-a-way. Yo&#x27; see dis yeah lawn-moah?"',
 '"Well, it&#x27;s this-a-way. You see this here lawn-mower?"', 1),

('T55', 'chapter-17.xhtml',
 '"No, sah, it doan&#x27;t work, an&#x27; dat&#x27;s how I&#x27;ve been swindled, Mistah Swift. Yo&#x27; see, I done traded mah ole grindstone off for dis yeah lawn-moah, an&#x27; I got stuck."',
 '"No, sir, it don&#x27;t work, an&#x27; that&#x27;s how I&#x27;ve been swindled, Mister Swift. You see, I done traded my ole grindstone off for this here lawn-mower, an&#x27; I got stuck."', 1),

('T56', 'chapter-17.xhtml',
 '"Dat&#x27;s what I mean, Mistah Swift. Why, it was all right. I mended it so dat de break wouldn&#x27;t show, an&#x27; it would sharpen things if yo&#x27; run it slow. But dis yeah lawn-moah won&#x27;t wuk slow ner fast."',
 '"That&#x27;s what I mean, Mister Swift. Why, it was all right. I mended it so that the break wouldn&#x27;t show, an&#x27; it would sharpen things if you run it slow. But this here lawn-mower won&#x27;t work slow ner fast."', 1),

('T57', 'chapter-17.xhtml',
 '"Yo&#x27; doan&#x27;t s&#x27;pose yo&#x27; kin fix dis yeah moah so&#x27;s I kin use it, does yo&#x27;, Mistah Swift?"',
 '"You don&#x27;t s&#x27;pose you can fix this here mower so&#x27;s I can use it, does you, Mister Swift?"', 1),

('T58', 'chapter-17.xhtml',
 '"I reckon now with summah comin&#x27; on I kin make mo&#x27; with a lawn-moah than I kin with a grindstone--dat is, ef I kin git it to wuk. I jest got it a while ago an&#x27; decided to try it, but it won&#x27;t cut no grass."',
 '"I reckon now with summer comin&#x27; on I can make mo&#x27; with a lawn-mower than I can with a grindstone--that is, ef I can git it to work. I jest got it a while ago an&#x27; decided to try it, but it won&#x27;t cut no grass."', 1),

('T59', 'chapter-17.xhtml',
 '"Am dat so, Mistah Swift?"',
 '"Am that so, Mister Swift?"', 1),

# T60. ⚠️ `Paul` for `pawl` KEPT. This is the whole point of the exchange and it
#      needs no dialect at all to land.
('T60', 'chapter-17.xhtml',
 '"I--I didn&#x27;t know mah lawn-moah was named Paul," said the colored man. "Is it writ on it anywhere?"',
 '"I--I didn&#x27;t know my lawn-mower was named Paul," said the old man. "Is it writ on it anywhere?"', 1),

('T61', 'chapter-17.xhtml',
 '"Yo&#x27; suah am a wonder at inventin&#x27;!" cried the colored man gratefully. "I&#x27;ll cut yo&#x27; grass all summah fo&#x27; yo&#x27; to pay fo&#x27; this, Mistah Swift."',
 '"You sure am a wonder at inventin&#x27;!" cried Eradicate gratefully. "I&#x27;ll cut your grass all summer fo&#x27; you to pay fo&#x27; this, Mister Swift."', 1),

('T62', 'chapter-17.xhtml',
 '"Well, yo&#x27; saved me from bein&#x27; swindled, Mistah Swift, an&#x27; I suah does &#x27;preciate dat."',
 '"Well, you saved me from bein&#x27; swindled, Mister Swift, an&#x27; I sure does &#x27;preciate that."', 1),

# T63. ⚠️ `coon` #1, and it is aimed at the WHITE man he traded the cracked
#      grindstone to. The insult survives as an insult.
('T63', 'chapter-17.xhtml',
 '"Oh, well, ef he done run it slow it won&#x27;t fly apart, an&#x27; he&#x27;ll do dat, anyhow, fo&#x27; he suah am a lazy coon. I guess we am about even there, Mistah Swift."',
 '"Oh, well, ef he done run it slow it won&#x27;t fly apart, an&#x27; he&#x27;ll do that, anyhow, fo&#x27; he sure am a lazy fellow. I guess we am about even there, Mister Swift."', 1),

# ========================================================= ch-20: the sawmill
('T64', 'chapter-20.xhtml',
 '"Now, Boomerang, yo&#x27; might jest as well start now as later," Tom heard a voice saying--a voice he recognized well. "Yo&#x27; hab got t&#x27; do dis yeah wuk, an&#x27; dere ain&#x27;t no gittin&#x27; out ob it. Dis yeah wood am got to be sawed, an&#x27; yo&#x27; hab got to saw it. But it am jest laik yo&#x27; to go back on yo&#x27; ole friend Eradicate in dis yeah fashion. I neber could tell what yo&#x27; were gwine t&#x27; do next, an&#x27; I cain&#x27;t now. G&#x27;lang, now, won&#x27;t yo&#x27;? Let&#x27;s git dis yeah sawmill started."',
 '"Now, Boomerang, you might jest as well start now as later," Tom heard a voice saying--a voice he recognized well. "You have got t&#x27; do this here work, an&#x27; there ain&#x27;t no gittin&#x27; out of it. This here wood am got to be sawed, an&#x27; you have got to saw it. But it am jest like you to go back on your ole friend Eradicate in this here fashion. I never could tell what you were going t&#x27; do next, an&#x27; I can&#x27;t now. G&#x27;lang, now, won&#x27;t you? Let&#x27;s git this here sawmill started."', 1),

('T65', 'chapter-20.xhtml',
 'toward where he had heard the voice of the colored man',
 'toward where he had heard the voice of the old man', 1),

('T66', 'chapter-20.xhtml',
 'cried the darky. "Howdy, Mistah Swift! Howdy! I&#x27;m jest tryin&#x27; t&#x27; saw some wood, t&#x27; make a livin&#x27;, but Boomerang he doan&#x27;t seem t&#x27; want t&#x27; lib,"',
 'cried the old man. "Howdy, Mister Swift! Howdy! I&#x27;m jest tryin&#x27; t&#x27; saw some wood, t&#x27; make a livin&#x27;, but Boomerang he don&#x27;t seem t&#x27; want t&#x27; live,"', 1),

('T67', 'chapter-20.xhtml',
 '"Good land o&#x27; massy! Ef it ain&#x27;t young Mistah Swift!"',
 '"Good land o&#x27; massy! Ef it ain&#x27;t young Mister Swift!"', 1),

# T68. ⚠️ `explanation` as a verb KEPT. Malapropism.
('T68', 'chapter-20.xhtml',
 '"I&#x27;ll tell yo&#x27;, Mistah Swift, I&#x27;ll tell yo&#x27;," spoke Eradicate. "Sit right yeah on dis log, an&#x27; I&#x27;ll explanation it to yo&#x27;."',
 '"I&#x27;ll tell you, Mister Swift, I&#x27;ll tell you," spoke Eradicate. "Sit right here on this log, an&#x27; I&#x27;ll explanation it to you."', 1),

('T69', 'chapter-20.xhtml',
 '"Yais, sah! Dat&#x27;s right. So I was. Yo&#x27; has got a memory, yo&#x27; suah has. But it am dis yeah way. Grass ain&#x27;t growin&#x27; quick enough, an&#x27; so I traded off dat lawn-moah an&#x27; bought dis yeah mill. But now it won&#x27;t go, an&#x27; I suah am in trouble,"',
 '"Yes, sir! That&#x27;s right. So I was. You has got a memory, you sure has. But it am this here way. Grass ain&#x27;t growin&#x27; quick enough, an&#x27; so I traded off that lawn-mower an&#x27; bought this here mill. But now it won&#x27;t go, an&#x27; I sure am in trouble,"', 1),

# =========================================== ch-21: the clue that cracks the case
# T70. `the aged whitewasher` - his own word for his own trade, and it keeps
#      Tom's warmth, which is the point of the sentence.
('T70', 'chapter-21.xhtml',
 'for he had a friendly feeling toward the aged darky.',
 'for he had a friendly feeling toward the aged whitewasher.', 1),

('T71', 'chapter-21.xhtml',
 '"Well," began Eradicate, "I suah thought I were gwine to make money cuttin&#x27; grass, &#x27;specially after yo&#x27; done fixed mah moah. But &#x27;peared laik nobody wanted any grass cut. I trabeled all ober, an&#x27; I couldn&#x27;t git no jobs. Now me an&#x27; Boomerang has to eat, no mattah ef he is contrary, so I had t&#x27; look fo&#x27; some new wuk. I traded dat lawn-moah off fo&#x27; a cross-cut saw, but dat was such hard wuk dat I gib it up. Den I got a chance to buy dis yeah outfit cheap, an&#x27; I bought it."',
 '"Well," began Eradicate, "I sure thought I were going to make money cuttin&#x27; grass, &#x27;specially after you done fixed my mower. But &#x27;peared like nobody wanted any grass cut. I traveled all over, an&#x27; I couldn&#x27;t git no jobs. Now me an&#x27; Boomerang has to eat, no matter ef he is contrary, so I had t&#x27; look fo&#x27; some new work. I traded that lawn-mower off fo&#x27; a cross-cut saw, but that was such hard work that I give it up. Then I got a chance to buy this here outfit cheap, an&#x27; I bought it."', 1),

('T72', 'chapter-21.xhtml',
 'cutting down considerable timber, for the colored man was a willing worker',
 'cutting down considerable timber, for the old man was a willing worker', 1),

# T73. The longest speech in the book. `I saws de wood`, `de trouble am`,
#      `not a stick hab I sawed`, `he say ef I doan't` - all the grammar stays.
('T73', 'chapter-21.xhtml',
 '"All he has to do is walk on dat tread mill, an&#x27; keep goin&#x27;. Dat makes de saw go &#x27;round, an&#x27; I saws de wood. But de trouble am dat I can&#x27;t git Boomerang to move. I done tried ebery means I knows on, an&#x27; he won&#x27;t go. I talked kind to him, an&#x27; I talked harsh. I done beat him wif a club, an&#x27; I rub his ears soft laik, an&#x27; he allers did laik dat, but he won&#x27;t go. I fed him on carrots an&#x27; I gib him sugar, an&#x27; I eben starve him, but he won&#x27;t go. Heah I been tryin&#x27; fo&#x27; three days now t&#x27; git him started, an&#x27; not a stick hab I sawed. De man what I&#x27;m wukin&#x27; wif on shares he git mad, an&#x27; he say ef I doan&#x27;t saw wood pretty soon he gwine t&#x27; git annuder mill heah. Now I axes yo&#x27; fair, Mistah Swift, ain&#x27;t I got lots ob trouble?"',
 '"All he has to do is walk on that tread mill, an&#x27; keep goin&#x27;. That makes the saw go &#x27;round, an&#x27; I saws the wood. But the trouble am that I can&#x27;t git Boomerang to move. I done tried every means I knows on, an&#x27; he won&#x27;t go. I talked kind to him, an&#x27; I talked harsh. I done beat him with a club, an&#x27; I rub his ears soft like, an&#x27; he allers did like that, but he won&#x27;t go. I fed him on carrots an&#x27; I give him sugar, an&#x27; I even starve him, but he won&#x27;t go. Here I been tryin&#x27; fo&#x27; three days now t&#x27; git him started, an&#x27; not a stick have I sawed. The man what I&#x27;m workin&#x27; with on shares he git mad, an&#x27; he say ef I don&#x27;t saw wood pretty soon he going t&#x27; git another mill here. Now I asks you fair, Mister Swift, ain&#x27;t I got lots of trouble?"', 1),

('T74', 'chapter-21.xhtml',
 '"Dat&#x27;s what done happened to Boomerang," declared Eradicate. "He done back up against de bar, an&#x27; dere he stay."',
 '"That&#x27;s what done happened to Boomerang," declared Eradicate. "He done back up against the bar, an&#x27; there he stay."', 1),

('T75', 'chapter-21.xhtml',
 '"Heah I done gone an&#x27; &#x27;vested mah money in dis yeah mill," complained Eradicate, "an&#x27; I ain&#x27;t sawed up a single stick. Ef I wasn&#x27;t so kind-hearted I&#x27;d chastise dat mule wuss dan I has, dat&#x27;s what I would."',
 '"Here I done gone an&#x27; &#x27;vested my money in this here mill," complained Eradicate, "an&#x27; I ain&#x27;t sawed up a single stick. Ef I wasn&#x27;t so kind-hearted I&#x27;d chastise that mule worse than I has, that&#x27;s what I would."', 1),

('T76', 'chapter-21.xhtml',
 '"Me? Good land, Mistah Swift, no, sah! I wouldn&#x27;t tech it. It&#x27;s jest as I got it from de man I bought it off. It worked when he had it, but he used a hoss. It&#x27;s all due to de contrariness ob Boomerang, an&#x27; if I--"',
 '"Me? Good land, Mister Swift, no, sir! I wouldn&#x27;t touch it. It&#x27;s jest as I got it from the man I bought it off. It worked when he had it, but he used a horse. It&#x27;s all due to the contrariness of Boomerang, an&#x27; if I--"', 1),

('T77', 'chapter-21.xhtml',
 '"It suah am goin&#x27;!" he added',
 '"It sure am goin&#x27;!" he added', 1),

('T78', 'chapter-21.xhtml',
 '"But de saw doan&#x27;t move, Mistah Swift. Yo&#x27; am pretty smart at fixin&#x27; it as much as yo&#x27; has, but I reckon it&#x27;s too busted t&#x27; eber saw any wood. I&#x27;se got bad luck, dat&#x27;s what I has."',
 '"But the saw don&#x27;t move, Mister Swift. You am pretty smart at fixin&#x27; it as much as you has, but I reckon it&#x27;s too busted t&#x27; ever saw any wood. I&#x27;ve got bad luck, that&#x27;s what I has."', 1),

# T79. ⚠️ `mush` for `mesh` KEPT. Malapropism.
('T79', 'chapter-21.xhtml',
 '"What&#x27;s dat &#x27;bout mush?" asked Eradicate.',
 '"What&#x27;s that &#x27;bout mush?" asked Eradicate.', 1),

('T80', 'chapter-21.xhtml',
 '"Hurrah! Dere it goes! Golly! see de saw move!" cried the delighted colored man.',
 '"Hurrah! There it goes! Golly! see the saw move!" cried the delighted old man.', 1),

('T81', 'chapter-21.xhtml',
 '"Whoop!" yelled Eradicate. "I&#x27;m sabed now! Bless yo&#x27;, Mistah Swift, yo&#x27; suttinly am a wondah!"',
 '"Whoop!" yelled Eradicate. "I&#x27;m saved now! Bless you, Mister Swift, you certainly am a wonder!"', 1),

('T82', 'chapter-21.xhtml',
 'and he showed the darky how to do it',
 'and he showed Eradicate how to do it', 1),

# T83. `the sawyer` - his new trade as of this chapter, and it is what the
#      sentence is actually describing him doing.
('T83', 'chapter-21.xhtml',
 'with a most energetic colored man feeding in logs',
 'with a most energetic sawyer feeding in logs', 1),

# T84. ⚠️ `coon` #2 - HIS OWN, about himself, and the line's punch is the pride
#      in it: a tramp had the nerve to beg from a working man. `hard-workin'
#      man` keeps the punch exactly. ⚠️ `seberal colored men` -> `several men I
#      know`: unmarked to match the rest of the pass, and the sentence loses
#      nothing, because the contrast the line runs on is WORKER vs TRAMP, not
#      Black vs white. ⚠️ `a white man` is KEPT - it is his own observation and
#      his own voice, and it is the batch-22 rule pointed the other way: fix
#      the frame, not the man inside it.
('T84', 'chapter-21.xhtml',
 '"Dat&#x27;s right, Mistah Swift, so I had. But I &#x27;done tried, an&#x27; couldn&#x27;t git any. I ast seberal colored men, but dey&#x27;d radder whitewash an&#x27; clean chicken coops. I guess I&#x27;ll hab t&#x27; go it alone. I ast a white man yisterday ef he wouldn&#x27;t like t&#x27; pitch in an&#x27; help, but he said he didn&#x27;t like to wuk. He was a tramp, an&#x27; he had de nerve to ask me fer money--me, a hard-wukin&#x27; coon."',
 '"That&#x27;s right, Mister Swift, so I had. But I &#x27;done tried, an&#x27; couldn&#x27;t git any. I ast several men I know, but they&#x27;d rather whitewash an&#x27; clean chicken coops. I guess I&#x27;ll have t&#x27; go it alone. I ast a white man yisterday ef he wouldn&#x27;t like t&#x27; pitch in an&#x27; help, but he said he didn&#x27;t like to work. He was a tramp, an&#x27; he had the nerve to ask me fer money--me, a hard-workin&#x27; man."', 1),

('T85', 'chapter-21.xhtml',
 '"No, indeedy, but he come so close to me dat I was askeered he might take it from me, so I kept hold ob a club. He suah was a bad-lookin&#x27; tramp, an&#x27; he kept laffin&#x27; all de while, like he was happy."',
 '"No, indeedy, but he come so close to me that I was scared he might take it from me, so I kept hold of a club. He sure was a bad-lookin&#x27; tramp, an&#x27; he kept laughin&#x27; all the while, like he was happy."', 1),

('T86', 'chapter-21.xhtml',
 'cried Tom, struck by the words of the colored man.',
 'cried Tom, struck by the words of the old man.', 1),

('T87', 'chapter-21.xhtml',
 '"Dat&#x27;s what he had," answered Eradicate, pausing in the midst of his work. "He suah were a funny sort ob tramp. His hands done looked laik he neber wuked, an&#x27; he had a funny blue ring one finger, only it wasn&#x27;t a reg&#x27;lar ring, yo&#x27; know. It was pushed right inter his skin, laik a man I seen at de circus once, all cobered wid funny figgers."',
 '"That&#x27;s what he had," answered Eradicate, pausing in the midst of his work. "He sure were a funny sort of tramp. His hands done looked like he never worked, an&#x27; he had a funny blue ring one finger, only it wasn&#x27;t a regular ring, you know. It was pushed right into his skin, like a man I seen at the circus once, all covered with funny figures."', 1),

('T88', 'chapter-21.xhtml',
 '"Let me see, it were on de right--no, it were on de little finger ob de left hand."',
 '"Let me see, it were on the right--no, it were on the little finger of the left hand."', 1),

('T89', 'chapter-21.xhtml',
 '"Suah, Mistah Swift. I took &#x27;tic&#x27;lar notice, &#x27;cause he carried a stick in dat same hand."',
 '"Sure, Mister Swift. I took &#x27;tic&#x27;lar notice, &#x27;cause he carried a stick in that same hand."', 1),

('T90', 'chapter-21.xhtml',
 '"He went up de lake shore," replied the colored man. "He asked me if I knowed ob an ole big house up dere, what nobody libed in, an&#x27; I said I did. Den he left, an&#x27; I were glad ob it."',
 '"He went up the lake shore," replied Eradicate. "He asked me if I knowed of an ole big house up there, what nobody lived in, an&#x27; I said I did. Then he left, an&#x27; I were glad of it."', 1),

('T91', 'chapter-21.xhtml',
 '"Why, dat ole mansion what General Harkness used t&#x27; lib in befo&#x27; de wah. Dere ain&#x27;t nobody libed in it fo&#x27; some years now, an&#x27; it&#x27;s deserted. Maybe a lot ob tramps stays in it, an&#x27; dat&#x27;s where dis man were goin&#x27;."',
 '"Why, that ole mansion what General Harkness used t&#x27; live in befo&#x27; the war. There ain&#x27;t nobody lived in it fo&#x27; some years now, an&#x27; it&#x27;s deserted. Maybe a lot of tramps stays in it, an&#x27; that&#x27;s where this man were goin&#x27;."', 1),

# T92. ⚠️ TS-X2 LIVES IN THIS ROW. `befo' de wah` -> `befo' the war` and
#      `quality folks` stays. The history is not edited, only the spelling.
('T92', 'chapter-21.xhtml',
 '"Away up at de head ob Lake Carlopa. I uster wuk dere befo&#x27; de wah, but it&#x27;s been a good many years since quality folks libed dere. Why, did yo&#x27; want t&#x27; see dat man, Mistah Swift?"',
 '"Away up at the head of Lake Carlopa. I used t&#x27; work there befo&#x27; the war, but it&#x27;s been a good many years since quality folks lived there. Why, did you want t&#x27; see that man, Mister Swift?"', 1),

('T93', 'chapter-21.xhtml',
 '"Well, I suah am obliged to yo&#x27;, Mistah Swift, fo&#x27; fixin&#x27; mah sawmill."',
 '"Well, I sure am obliged to you, Mister Swift, fo&#x27; fixin&#x27; my sawmill."', 1),

('T94', 'chapter-21.xhtml',
 'but very much delighted, colored man behind him',
 'but very much delighted, whitewasher behind him', 1),

# =============================================================== ch-22: the clew
('T95', 'chapter-22.xhtml',
 'Whereupon Tom told of his meeting with the colored man',
 'Whereupon Tom told of his meeting with the old man', 1),

]


# ═══════════════════════════════════════════════════════════════════════════
# TITLE-PAGE NOTES - 3 rows, and ⚠️ THIS IS A CORRECTION, NOT AN INSERTION.
#
# ⚠️ ALL THREE FILES ARRIVED WITH THE CLASSROOM NOTE ALREADY PRESENT, inserted
# by the structural pass (`ttb-fix-epubs.py`) before any language pass had run.
# `rawcheck.py --fingerprint` reports it as a previous-pass fingerprint on all
# three, which is exactly the 17a trap: the note is evidence about the note, not
# about the book. On arrival the sentence was simply FALSE - nothing had been
# reworded. It is now true, but the SHIPPED WORDING WAS STILL WRONG in a way
# that matters, and this is 17e repeating:
#
#   "...Victor Appleton's stories, characters, and dialect are otherwise
#    unchanged."
#
# ⚠️ THE DIALECT IS THE ONE THING THIS BATCH CHANGED MOST. A note claiming
# otherwise is a false provenance claim on the deliverable, and it is the single
# edit a reader could reasonably call dishonest (the 23-batch rule about
# disclosing a rewritten quotation, pointed at our own boilerplate). All three
# notes are therefore restated to describe what actually happened, per the
# standing instruction to vary the wording when the work was more than lexical.
# ═══════════════════════════════════════════════════════════════════════════

FRONT = [

# N1. ⚠️ Names the de-dialect AND names the deliberate exception, so a reader -
#     or a future instance - can see that the tramp's dialect surviving is a
#     ruling and not an oversight.
('N1', 'titlepage.xhtml',
 'Classroom edition. This public-domain text has had a small number of period racial slurs and dated terms reworded for classroom use by Claude with supervision. Victor Appleton&#x27;s stories, characters, and dialect are otherwise unchanged.',
 'Classroom edition. This public-domain text has had period racial slurs and dated terms reworded, and the phonetic dialect spelling of one character regularised into ordinary English, for classroom use by Claude with supervision. Victor Appleton&#x27;s story and characters are unchanged, his characters&#x27; grammar and turns of phrase are kept, and the tramp&#x27;s dialect, which the plot turns on, is untouched.', 1),

# N2. Names the disability-label pass, because "reworded" would not cover
#     replacing a narrator's naming habit across 27 sites.
('N2', 'titlepage.xhtml',
 'Classroom edition. This public-domain text has had a small number of period racial slurs and dated terms reworded for classroom use by Claude with supervision. Alice B. Emerson&#x27;s stories, characters, and dialect are otherwise unchanged.',
 'Classroom edition. This public-domain text has had a small number of period racial slurs and dated terms reworded, and the narrator&#x27;s habit of naming one character after her disability replaced with her own name, for classroom use by Claude with supervision. Alice B. Emerson&#x27;s story, characters, and dialect are otherwise unchanged.', 1),

# N3. Four small rows and no dialect in the book at all, so the claim about
#     dialect is dropped rather than left to sit there vacuously.
('N3', 'titlepage.xhtml',
 'Classroom edition. This public-domain text has had a small number of period racial slurs and dated terms reworded for classroom use by Claude with supervision. Gertrude Chandler Warner&#x27;s stories, characters, and dialect are otherwise unchanged.',
 'Classroom edition. This public-domain text has had four dated terms reworded for classroom use by Claude with supervision. Gertrude Chandler Warner&#x27;s story and characters are unchanged.', 1),

]

FRONTBOOK = {'N1': 'TS', 'N2': 'RF', 'N3': 'BC'}


ALL = [(i, b, f, raw(o), raw(n), c)
       for b, rows in (('TS', TS), ('RF', RF), ('BC', BC))
       for i, f, o, n, c in rows]
ALL += [(i, FRONTBOOK[i], f, raw(o), raw(n), c) for i, f, o, n, c in FRONT]


def check_amp():
    """13c: a bare & in a replacement breaks the XML and only one check in five
    catches it. Refuse to run rather than discover it in the dry run."""
    bad = []
    for i, _b, _f, old, new, _c in ALL:
        for label, s in (('old', old), ('new', new)):
            if s == DELETE:
                continue
            for k, ch in enumerate(s):
                if ch == '&' and not any(s.startswith(e, k) for e in
                                         ('&amp;', '&quot;', '&#x27;', '&lt;', '&gt;')):
                    bad.append(f'{i} {label}')
    if bad:
        print('  BARE AMPERSAND in: ' + ', '.join(bad))
        return False
    return True


def table():
    for key, rows in (('TS', TS), ('RF', RF), ('BC', BC),
                      ('front matter', FRONT)):
        print(f'\n## {TITLES[key]} - {len(rows)} rows\n')
        print('| id | file | old | new |')
        print('|---|---|---|---|')
        for i, f, o, n, _c in rows:
            shown = 'DELETED' if n == DELETE else n
            print(f'| {i} | {f.replace(".xhtml","")} | {o[:70]} | {shown[:70]} |')


def dry():
    if not check_amp():
        return False
    fail = 0
    seen = {}
    for i, book, f, old, new, cnt in ALL:
        p = os.path.join(book, TEXTDIR, f)
        if not os.path.exists(p):
            print(f'  MISS {i:5} no such file {p}')
            fail += 1
            continue
        s = open(p, encoding='utf-8').read()
        found = s.count(old)
        if found != cnt:
            print(f'  FAIL {i:5} {book} {f:20} expect {cnt} found {found}')
            fail += 1
        # 19b-adjacent: two rows whose old spans overlap in one file would let
        # apply order decide the result. Catch it here, not after apply.
        key = (book, f)
        for j, prev in seen.get(key, []):
            if prev in old or old in prev:
                print(f'  OVERLAP {i} and {j} in {book}/{f}')
                fail += 1
        seen.setdefault(key, []).append((i, old))
    print(f'\n{len(ALL)} rows, {fail} failing')
    return fail == 0


if __name__ == '__main__':
    if '--table' in sys.argv:
        table()
    else:
        sys.exit(0 if dry() else 1)
