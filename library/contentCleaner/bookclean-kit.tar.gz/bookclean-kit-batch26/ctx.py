#!/usr/bin/env python3
"""Print full paragraph context for every hit of a pattern.

⚠️ BATCH 15b: this helper does NOT splice >>> <<< markers into the context.
The splice arithmetic in the old version ate characters after every hit and
produced edit strings that did not exist in the file. Hit and context are
printed as SEPARATE FIELDS. The context is a verbatim slice.
"""
import re, sys
from scan import load_spine

def paragraphs(body):
    """Split into paragraph-ish units with their absolute offsets."""
    out, pos = [], 0
    for chunk in body.split('\n'):
        if chunk.strip():
            out.append((pos, chunk))
        pos += len(chunk) + 1
    return out

def show(dumpfile, pattern, files=None, para=True, window=220):
    spine = load_spine(dumpfile)
    n = 0
    for fname, body in spine:
        if files and not any(f in fname for f in files):
            continue
        paras = paragraphs(body)
        for m in re.finditer(pattern, body, re.I):
            n += 1
            if para:
                ctx = ''
                for p0, ptext in paras:
                    if p0 <= m.start() < p0 + len(ptext) + 1:
                        ctx = ptext.strip()
                        break
                if not ctx:
                    ctx = body[max(0, m.start()-window):m.end()+window]
            else:
                ctx = body[max(0, m.start()-window):m.end()+window]
            print(f'--- [{n}] {fname}  @{m.start()}')
            print(f'    HIT     : {m.group(0)!r}')
            print(f'    CONTEXT : {ctx}')
            print()
    print(f'== {n} hits ==')

if __name__ == '__main__':
    dumpfile, pattern = sys.argv[1], sys.argv[2]
    files = sys.argv[3].split(',') if len(sys.argv) > 3 else None
    show(dumpfile, pattern, files)
