#!/usr/bin/env python3
"""apply.py - BATCH 26. Applies edits.py with per-row assertions.

NEVER FILTER THIS OUTPUT (10b). A silently-not-applied row looks identical to an
applied one in a filtered log, and the reverse-diff cannot catch a no-op.

Takes a pristine snapshot of every touched file into ORIG/ first, so verify.py
can run BOTH the reverse-diff (substitution rows) and the forward-diff
(deletion rows) required by 21b.
"""
import os, shutil, sys
from edits import ALL, DELETE, TEXTDIR, TEXTDIR

ORIG = 'ORIG'


def snapshot():
    touched = {(b, f) for _i, b, f, _o, _n, _c in ALL}
    for b, f in sorted(touched):
        dst = os.path.join(ORIG, b, f)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if not os.path.exists(dst):
            shutil.copy2(os.path.join(b, TEXTDIR, f), dst)
    print(f'  snapshot: {len(touched)} files -> {ORIG}/')


def apply_all():
    fail = 0
    for i, book, f, old, new, cnt in ALL:
        p = os.path.join(book, TEXTDIR, f)
        s = open(p, encoding='utf-8').read()
        found = s.count(old)
        if found != cnt:
            print(f'  FAIL {i:7} {book:8} {f:20} expect {cnt} found {found} - NOT APPLIED')
            fail += 1
            continue
        repl = '' if new == DELETE else new
        s = s.replace(old, repl, cnt)
        after = s.count(old)
        if after != 0 and repl != old:
            print(f'  FAIL {i:7} residual {after} after replace')
            fail += 1
            continue
        open(p, 'w', encoding='utf-8').write(s)
        kind = 'CUT ' if new == DELETE else 'sub '
        print(f'  {kind}{i:7} {book:8} {f:20} x{cnt}')
    return fail


if __name__ == '__main__':
    print('BATCH 26 APPLY\n')
    snapshot()
    print()
    fail = apply_all()
    dels = sum(1 for r in ALL if r[4] == DELETE)
    print(f'\n  {len(ALL)} rows applied, {fail} failures, {dels} deletion rows')
    sys.exit(1 if fail else 0)
