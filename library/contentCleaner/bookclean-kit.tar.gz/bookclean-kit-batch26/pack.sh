#!/usr/bin/env bash
# pack.sh 1.0.0 - build the bookclean-kit tarball.
#
# ⚠️ WHY THIS IS A SCRIPT AND NOT A HABIT (batch 20):
# Batches 17, 18 and 19 each published a README listing an eight-step toolchain
# and then shipped four files, by hand, three times running. "Remember to include
# everything" is not a control. This is.
#
# It REFUSES to build if:
#   - the .py count is not TOOL_COUNT
#   - any required file is missing
#   - any .py fails to parse
#   - any selftest fails
#
# A refusal here is the point. Do not add --force.
#
# USAGE
#   ./pack.sh 21                # batch number
#   ./pack.sh 21 --no-selftest  # ONLY when the reference books are absent

set -euo pipefail

BATCH="${1:?usage: ./pack.sh <batch-number> [--no-selftest]}"
SKIP_SELFTEST="${2:-}"
# ⚠️ BATCH 25: 13 -> 14. `typefix.py` is a new LIBRARY tool (untypable-character
# normalisation), not a batch-local one: it is book-agnostic and every future
# Standard Ebooks source will want it.
# BATCH 25b: 14 -> 15. `notefix.py` is a library tool - Gutenberg `{n}` footnote
# anchors will recur in every PG-derived book in the queue.
# BATCH 25c: 15 -> 16. `extract.py` joins the kit (with `checkmatter.js` as a
# doc sidecar, since it is JS and not counted among the Python tools).
TOOL_COUNT=16

LIB=(dump.py scan.py ctx.py stemaudit.py rawcheck.py gapcheck.py scene.py quality.py measure.py typefix.py notefix.py extract.py)
BATCHLOCAL=(edits.py apply.py verify.py frontmatter.py)
# BATCH 25c: checkmatter.js is JS, so it ships as a doc/sidecar rather than in
# the Python tool count. It is useless without extract.py; keep them together.
DOCS=(TOOLKIT.md HANDOFF-bookclean.md checkmatter.js)
# ⚠️ batch 22: edits.py can carry a DATA SIDECAR - a deletion row whose `old` is
# thousands of bytes (Big Horn's 44-paragraph ad block) lives in a .txt so the
# assertion is a real string count on reviewable text rather than a computed
# slice. If the sidecar is not packed, a future instance's edits.py crashes on
# import. Any file matching *-adblock.txt or *-cut.txt is packed automatically.
DATA=( $(ls -1 *-adblock.txt *-cut.txt 2>/dev/null || true) )

KIT="bookclean-kit-batch${BATCH}"
TAR="${KIT}.tar.gz"

echo "=== pack.sh: building ${TAR} ==="

# ---- 1. inventory -----------------------------------------------------------
n=$(ls -1 *.py 2>/dev/null | wc -l | tr -d ' ')
if [ "$n" -ne "$TOOL_COUNT" ]; then
  echo "REFUSING: found ${n} .py files, expected ${TOOL_COUNT}."
  echo "  present: $(ls -1 *.py | tr '\n' ' ')"
  echo "  see TOOLKIT.md for the full inventory."
  exit 1
fi
for f in "${LIB[@]}" "${BATCHLOCAL[@]}" "${DOCS[@]}"; do
  [ -f "$f" ] || { echo "REFUSING: missing ${f}"; exit 1; }
done
echo "  inventory      : ${TOOL_COUNT}/${TOOL_COUNT} tools + ${#DOCS[@]} docs + ${#DATA[@]} data sidecars"

# ---- 2. every script must parse --------------------------------------------
for f in *.py; do
  python3 -c "import ast,sys;ast.parse(open(sys.argv[1]).read())" "$f" \
    || { echo "REFUSING: ${f} does not parse"; exit 1; }
done
echo "  syntax         : all ${TOOL_COUNT} parse"

# ---- 3. selftests ----------------------------------------------------------
if [ "$SKIP_SELFTEST" != "--no-selftest" ]; then
  for cmd in "measure.py selftest" "quality.py --selftest" "scene.py --selftest" "scan.py --selftest" "typefix.py --selftest" "notefix.py --selftest"; do
    if ! python3 $cmd > /tmp/pack_selftest.log 2>&1; then
      echo "REFUSING: '${cmd}' failed:"; sed 's/^/    /' /tmp/pack_selftest.log; exit 1
    fi
  done
  echo "  selftests      : 6/6 pass"
else
  echo "  selftests      : SKIPPED (reference books absent)"
fi

# ---- 4. stage and checksum -------------------------------------------------
rm -rf "$KIT" "$TAR"
mkdir -p "$KIT"
cp "${LIB[@]}" "${BATCHLOCAL[@]}" "${DOCS[@]}" "$KIT/"
if [ ${#DATA[@]} -gt 0 ]; then cp "${DATA[@]}" "$KIT/"; fi
cp "$0" "$KIT/"
[ -f "README-bookclean-batch${BATCH}.md" ] && cp "README-bookclean-batch${BATCH}.md" "$KIT/"

( cd "$KIT" && sha256sum ./* > MANIFEST.sha256 )

{
  echo "bookclean-kit, batch ${BATCH}"
  echo "built $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  echo
  echo "LIBRARY TOOLS (${#LIB[@]}) - book-agnostic, run from anywhere:"
  printf '  %s\n' "${LIB[@]}"
  echo
  echo "BATCH-LOCAL TOOLS (${#BATCHLOCAL[@]}) - copy into the batch dir; they use"
  echo "relative paths and will FileNotFoundError from the kit folder. That is correct."
  printf '  %s\n' "${BATCHLOCAL[@]}"
  echo
  if [ ${#DATA[@]} -gt 0 ]; then
    echo "DATA SIDECARS (${#DATA[@]}) - large deletion spans referenced by edits.py:"
    printf '  %s\n' "${DATA[@]}"
    echo
  fi
  echo "Verify:  sha256sum -c MANIFEST.sha256"
  echo "Read:    TOOLKIT.md first."
} > "$KIT/CONTENTS.txt"

tar -czf "$TAR" "$KIT"
rm -rf "$KIT"

echo "  tarball        : ${TAR} ($(du -h "$TAR" | cut -f1))"
echo "=== ok ==="
