#!/usr/bin/env python3
"""gapcheck.py 1.0.0 - which terms is scan.py NOT looking for?

Ran unshipped in batches 17 and 18; produced the absent-stem lists in HANDOFF
17d and 18h. Written to disk in batch 20.

⚠️ THE PROBLEM THIS EXISTS FOR: five consecutive batches (13, 16, 17, 18 twice)
the finding was a pattern that DID NOT EXIST rather than one that misfired.
`stemaudit.py` audits the patterns that ARE there for hidden inflections. Nothing
audited the absence. That asymmetry is why `Mahoun`, `dwarf`, `crookback`,
`leper`, the `black girl` phrase form and the whole skin-descriptor family all
reached a shipped book unseen.

⚠️ AND ONE FAILURE MODE WORTH ITS OWN LINE (18h): `breast` has a paragraph in
the handoff's HIGH-FREQUENCY FALSE POSITIVES table explaining it is noise in two
books - and was never written into a pattern block. Somebody scanned for it once,
dismissed it in prose, and left it unscanned forever. `--table` compares that
table against scan.py: anything in the table but not in the blocks is a term
NOBODY IS CHECKING.

USAGE
  python3 gapcheck.py book.txt              # candidate terms scan.py misses
  python3 gapcheck.py --coverage            # which CANDIDATES are in scan.py
  python3 gapcheck.py --table               # false-positive table vs the blocks
"""
import re, sys, os

VERSION = '1.0.0'

# Candidate vocabulary a period children's book can carry, grouped by the era or
# genre that supplies it. Not a fix list - a LOOK list.
CANDIDATES = {
 'medieval / romance': [
   'mahoun', 'mahound', 'termagant', 'paynim', 'saracen', 'moor', 'infidel',
   'crookback', 'hunchback', 'dwarf', 'dwarfish', 'leper', 'lepros', 'crookèd',
   'witch', 'sorcer', 'heretic', 'papist', 'popish', 'usury', 'gibbet',
 ],
 'skin / hair descriptors': [
   'copper-coloured', 'copper-colored', 'coppery', 'dusky', 'swarthy', 'sallow',
   'olive-skinned', 'brown-skinned', 'black-faced', 'dark-skinned',
   'woolly', 'kinky', 'frizzled', 'hook-nosed', 'beetle-browed', 'thick-lipped',
 ],
 'phrase-form race labels': [
   'black girl', 'black boy', 'black child', 'black man', 'black woman',
   'black folk', 'coloured troops', 'colored troops', 'white folk',
   'little black', 'small black',
 ],
 'colonial / mission': [
   'cannibal', 'native', 'heathen', 'idol', 'fetish', 'witch-doctor',
   'civilised', 'uncivilised', 'primitive', 'barbarous', 'stone age',
   'beads and brandy', 'trading post', 'allotment',
 ],
 'antisemitic coding': [
   'jewess', 'sheeny', 'usurer', 'moneylender', 'shylock', 'pawnbroker',
   'levinstein', 'rosenbaum', 'curved nose', 'hooked nose',
 ],
 'disability': [
   'tongue-tied', 'goitre', 'goiter', 'clubfoot', 'harelip', 'stammer',
   'stutter', 'simpleton', 'natural', 'afflicted', 'wanting',
 ],
 'body / anatomy': [
   'breast', 'bosom', 'thigh', 'belly', 'navel',
 ],
 'minced oaths / period profanity': [
   'zounds', 'gadzooks', 'begad', 'egad', 'tarnation', 'thunderation',
   'doggone', 'dad-burn', 'consarn', 'jiminy',
 ],
}


def term_pattern(t):
    """⚠️ BATCH 20 BUG: the first draft did
           t.replace(' ', r'[\\s-]+').replace('-', r'[- ]')
       and the SECOND replace ate the hyphen inside the FIRST one's character
       class, producing `[\\s[- ]]+` and a regex compile error. Chained
       .replace() on regex source is a trap: each call sees the previous call's
       metacharacters. Tokenise once instead."""
    parts = re.split(r'[\s-]+', t.strip())
    return r'\b' + r'[\s-]+'.join(re.escape(p) for p in parts) + r'\w*'


def load_blocks():
    """Import scan.py's live BLOCKS - never a copy of them."""
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, here)
    from scan import BLOCKS
    return BLOCKS


def covered(term, blocks):
    """Would ANY pattern in scan.py match this term?"""
    for pats in blocks.values():
        for p in pats:
            try:
                if re.search(p, term, re.I):
                    return True
            except re.error:
                pass
    return False


def load_spine(dumpfile):
    text = open(dumpfile, encoding='utf-8').read()
    parts = re.split(r'\n\n===== FILE: (.+?) =====\n', text)
    return [(parts[i], parts[i + 1]) for i in range(1, len(parts), 2)]


def gaps(dumpfile):
    blocks = load_blocks()
    spine = load_spine(dumpfile)
    print(f'\n########## {os.path.basename(dumpfile)} - GAP SCAN ##########')
    print('  terms present in the book that scan.py CANNOT see:\n')
    any_hit = False
    for group, terms in CANDIDATES.items():
        rows = []
        for t in terms:
            if covered(t, blocks):
                continue
            pat = term_pattern(t)
            n = sum(len(re.findall(pat, b, re.I)) for _, b in spine)
            if n:
                files = sorted({f.replace('.xhtml', '')
                                for f, b in spine if re.search(pat, b, re.I)})
                rows.append((t, n, files))
        if rows:
            any_hit = True
            print(f'  -- {group} --')
            for t, n, files in sorted(rows, key=lambda r: -r[1]):
                print(f'     {t:22s} {n:4d}  [{", ".join(files[:5])}]')
    if not any_hit:
        print('  none - every candidate present in this book is already covered')
    return any_hit


def coverage():
    blocks = load_blocks()
    print('\n########## CANDIDATE COVERAGE BY scan.py ##########')
    for group, terms in CANDIDATES.items():
        miss = [t for t in terms if not covered(t, blocks)]
        print(f'\n  {group}: {len(terms) - len(miss)}/{len(terms)} covered')
        if miss:
            print(f'    ABSENT: {", ".join(miss)}')


# terms the handoff's HIGH-FREQUENCY FALSE POSITIVES section discusses in prose
FP_TABLE = ['breast', 'bosom', 'niggardly', 'chink', 'cock', 'ass', 'queer',
            'gay', 'native', 'brave', 'member', 'crack', 'balls', 'lame',
            'dumb', 'mistress', 'coloured', 'den', 'moor', 'hun', 'jew',
            'indian', 'savage', 'tramp', 'wanton', 'lust', 'panting']


def table_audit():
    blocks = load_blocks()
    print('\n########## FALSE-POSITIVE TABLE vs scan.py BLOCKS ##########')
    print('  \u26a0\ufe0f Anything ABSENT below is a term that was scanned once, dismissed')
    print('     in prose, and never written into a block - so it is not being')
    print('     scanned at all. That is how `breast` went five batches unseen.\n')
    bad = []
    for t in FP_TABLE:
        c = covered(t, blocks)
        if not c:
            bad.append(t)
        print(f'   {"OK    " if c else "ABSENT"}  {t}')
    print(f'\n  {len(bad)} of {len(FP_TABLE)} discussed-but-unscanned: {bad}')
    return bad


if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    if sys.argv[1] == '--coverage':
        coverage()
    elif sys.argv[1] == '--table':
        table_audit()
    else:
        for f in sys.argv[1:]:
            gaps(f)
