#!/usr/bin/env python3
"""verify.py - BATCH 26. Ten checks. Exits nonzero.

  1  XML well-formedness, every spine file
  2  <p> parity, expected delta DERIVED from edits.py (never typed)
  3  OPF byte-identical to the uploaded source
  4  nav / ncx byte-identical (no spine file added, removed or renumbered)
  5  REVERSE-diff on substitution rows: undo them, assert byte-identity
  6  FORWARD-diff: replay from pristine, assert byte-identity with shipped
  7  residual scan: whole book, every fixed token asserted GONE
  8  ruled leaves: counts asserted EQUAL between pristine and shipped
  9  introduced-word check (19b)
 10  identity assertion (24e): a distinctive proper noun at an expected count,
     so the report provably describes the right file

⚠️ BATCH 26 CHANGES TO THE HARNESS, BOTH OF THEM LESSONS FROM 17f/25h:
  * TEXTDIR is `OEBPS`, not `epub/text`, and the nav is `nav.xhtml`, not
    `toc.xhtml`. These are Gutenberg conversions, not Standard Ebooks. Batch 25
    lost a tool to assuming the layout (`typefix.py` processed ZERO files and
    reported success). PROBE THE LAYOUT; the assertions below are the probe.
  * ⚠️ CHECK 8 NO LONGER CARRIES TYPED COUNTS. Every prior batch typed the leave
    counts by hand and three batches running the harness failed on the typed
    number rather than on the book. A leave means "unchanged from source", which
    is a comparison, not a constant - so check 8 now counts the pattern in
    PRISTINE/ (unzipped straight from the EPUBs Jake uploaded) and in the
    shipped tree, and asserts they are equal. There is no number to mistype.

⚠️ THE HEAVIEST RULING IN THIS BATCH IS A KEEP, AND IT IS IN CHECK 8:
  Happy Harry's Bowery dialect is a PLOT DEVICE - Tom identifies him as a
  disguised criminal by noticing the dialect slip. `youse`, `cully`, `dat`,
  `de`, `nuttin'` are asserted at pristine count. A later pass that regularises
  the tramp along with Eradicate FAILS THIS BATTERY.
"""
import os, re, sys, glob, subprocess, html
import xml.etree.ElementTree as ET
from edits import ALL, DELETE, BOOKS, TEXTDIR, TITLES

ORIG = 'ORIG'
PRIS = 'PRISTINE'
SOURCE = {b: f'/mnt/user-data/uploads/{s}-claudePrepared.epub' for b, s in BOOKS.items()}
FAIL = []


def note(ok, msg):
    print(f'  {"ok  " if ok else "FAIL"} {msg}')
    if not ok:
        FAIL.append(msg)


def plain(path):
    """⚠️ THE `html.unescape` IS NOT COSMETIC AND IT WAS MISSING IN v1.

    These files write every apostrophe as `&#x27;`. Without unescaping, any
    pattern containing an apostrophe - `\byo'`, `\bdoan't\b`, `\ban'`,
    `pow'ful`, `'bout mush`, `Curtis' crippled daughter` - matches NOTHING, in
    BOTH directions. The residual check then reports `0 residual` and passes,
    for the wrong reason. Six of my own leave patterns returned `0->0` and one
    residual pattern was untestable. This is 25h exactly: a silently-neutered
    check is worse than a deleted one, because it reports success. Any pattern
    that can never match is now caught by the `a == 0` guard in check 8."""
    t = re.sub(r'<[^>]+>', ' ', open(path, encoding='utf-8').read())
    return html.unescape(t)


def files_of(root, book, skip_titlepage=True):
    pat = f'{root}/{book}/{TEXTDIR}/*.xhtml' if root else f'{book}/{TEXTDIR}/*.xhtml'
    fs = sorted(glob.glob(pat))
    if skip_titlepage:
        fs = [f for f in fs if os.path.basename(f) != 'titlepage.xhtml']
    return fs


def booktext(root, book, only=None):
    r"""⚠️ titlepage.xhtml is EXCLUDED from every count. Our own classroom note
    is not the author's text, and it is why `\btramp\w*` read 72->73 in v1: the
    corrected TS note contains the words "the tramp's dialect". A harness that
    counts our own prose as the book's cannot tell an edit from a disclosure."""
    fs = files_of(root, book)
    if only:
        fs = [f for f in fs if os.path.basename(f) in only]
    return ''.join(plain(f) for f in fs)


# ---------------------------------------------------------------- 1 XML
def c1():
    print('\n[1] XML well-formedness')
    for book in BOOKS:
        fs = sorted(glob.glob(f'{book}/{TEXTDIR}/*.xhtml'))
        bad = []
        for f in fs:
            try:
                ET.parse(f)
            except Exception as e:
                bad.append(f'{f}: {e}')
        note(not bad and len(fs) > 0,
             f'{book:4} {len(fs)-len(bad)}/{len(fs)} parse'
             + ('' if not bad else '  ' + bad[0]))


# ---------------------------------------------------------------- 2 <p> parity
def expect_p():
    """⚠️ DERIVED FROM THE EDIT TABLE, NEVER TYPED (17f, five batches running)."""
    d = {b: 0 for b in BOOKS}
    for _i, book, _f, old, new, cnt in ALL:
        n = 0 if new == DELETE else new.count('<p>')
        d[book] += (n - old.count('<p>')) * cnt
    return d


EXPECT_P = expect_p()


def c2():
    print('\n[2] <p> parity (expected delta DERIVED from edits.py)')
    for book in BOOKS:
        o = n = 0
        for f in sorted(glob.glob(f'{book}/{TEXTDIR}/*.xhtml')):
            base = os.path.basename(f)
            n += open(f, encoding='utf-8').read().count('<p>')
            o += open(f'{PRIS}/{book}/{TEXTDIR}/{base}',
                      encoding='utf-8').read().count('<p>')
        note(n - o == EXPECT_P[book],
             f'{book:4} <p> {o} -> {n} ({n-o:+d}, expect {EXPECT_P[book]:+d})')


# ---------------------------------------------------------------- 3 OPF
def c3():
    print('\n[3] OPF untouched (slugify()/admin.js book id must not move)')
    for book in BOOKS:
        cur = open(f'{book}/{TEXTDIR}/content.opf', 'rb').read()
        z = subprocess.run(['unzip', '-p', SOURCE[book], 'OEBPS/content.opf'],
                           capture_output=True)
        note(cur == z.stdout and len(z.stdout) > 0,
             f'{book:4} content.opf byte-identical to the uploaded source')


# ---------------------------------------------------------------- 4 nav / ncx
def c4():
    print('\n[4] nav / ncx skeleton (Gutenberg layout: nav.xhtml, not toc.xhtml)')
    for book in BOOKS:
        for f in ('nav.xhtml', 'toc.ncx'):
            cur = open(f'{book}/{TEXTDIR}/{f}', 'rb').read()
            z = subprocess.run(['unzip', '-p', SOURCE[book], f'OEBPS/{f}'],
                               capture_output=True)
            note(cur == z.stdout and len(z.stdout) > 0,
                 f'{book:4} {f:10} byte-identical (no spine file touched)')


# ---------------------------------------------------------------- 5 reverse-diff
def c5():
    print('\n[5] REVERSE-diff, substitution rows')
    for book in BOOKS:
        subs = [r for r in ALL if r[1] == book and r[4] != DELETE]
        files = sorted({r[2] for r in subs})
        okc = 0
        for f in files:
            s = open(f'{book}/{TEXTDIR}/{f}', encoding='utf-8').read()
            for _i, _b, ff, old, new, cnt in subs:
                if ff == f:
                    s = s.replace(new, old, cnt)
            if s == open(f'{ORIG}/{book}/{f}', encoding='utf-8').read():
                okc += 1
            else:
                FAIL.append(f'reverse-diff {book}/{f}')
        note(okc == len(files), f'{book:4} byte-identical on {okc}/{len(files)} touched files')


# ---------------------------------------------------------------- 6 forward-diff
def c6():
    print('\n[6] FORWARD-diff: replay from PRISTINE reproduces the shipped file')
    for book in BOOKS:
        files = sorted({r[2] for r in ALL if r[1] == book})
        okc = 0
        for f in files:
            s = open(f'{PRIS}/{book}/{TEXTDIR}/{f}', encoding='utf-8').read()
            for i, b, ff, old, new, cnt in ALL:
                if b != book or ff != f:
                    continue
                if s.count(old) != cnt:
                    FAIL.append(f'forward replay lost {i}')
                    continue
                s = s.replace(old, '' if new == DELETE else new, cnt)
            if s == open(f'{book}/{TEXTDIR}/{f}', encoding='utf-8').read():
                okc += 1
            else:
                FAIL.append(f'forward-diff {book}/{f}')
        note(okc == len(files),
             f'{book:4} source + edit table alone reproduces {okc}/{len(files)} files')


# ---------------------------------------------------------------- 7 residual
RESIDUAL = {
    # Eradicate's respellings and every race label. ⚠️ `\bdat\b` etc. are
    # deliberately NOT here - they are the TRAMP's and are a ruled leave; the
    # respelling assertions below are the ones unique to Eradicate's voice.
    'TS': [r'\bdarky\b', r'\bdarkey\b', r'\bnegro(?:es)?\b', r'\bnigger\w*',
           r'\bcoon\b', r'colored man', r'colored men', r'black mans',
           r'\bmah\b', r"\byo'", r'\bsuah\b', r'\bsuttinly\b', r'\bgwine\b',
           r'\bMistah\b', r'\bYais\b', r"\bdoan't\b", r'\bwuk\b', r'\blib\b',
           r'\beber\b', r'\bneber\b', r'\blaik\b', r'\bdis yeah\b',
           r'\bmoah\b', r'\bbresh\b', r'\bwah\b', r'\bsabed\b', r'\btrabeled\b'],
    # ⚠️ TWO OF THESE ARE NOT ZERO, AND THAT IS THE RULING, NOT A MISS. 14g
    # keeps a character's own use, so the pattern carries its allowed count:
    #   `the cripple`  x1 - Uncle Jabez: "Sam Curtis' gal--the cripple?"
    #   `the lame girl` x1 - Ruth: "The lame girl, sir?"
    # A bare 0 here would have forced me to either over-edit or silently drop
    # the pattern, and a dropped pattern is the 25h failure again.
    'RF': [r'\bejaculat\w*', r'\bgay\b', r'\bgypsyish\b', r'\bMammy\b',
           (r'the cripple\b', 1), r"the cripple's", (r'the lame girl', 1),
           r'the crippled girl', r'her wool',
           # Batch-26 ruling: narrator/Ruth uses all gone, and Mercy never used
           # it herself, so this one really is a zero.
           r'\bthe invalid\b', r'\binvalids\b'],
    'BC': [r'\bgay\b', r'\bcock\b', r'colored boy'],
}


def c7():
    print('\n[7] residual scan, WHOLE book (not just the touched files)')
    for book in BOOKS:
        txt = booktext(None, book)
        live = {}
        for entry in RESIDUAL[book]:
            pat, allowed = entry if isinstance(entry, tuple) else (entry, 0)
            n = len(re.findall(pat, txt, re.I))
            if n != allowed:
                live[pat] = f'{n} (allowed {allowed})'
        note(not live, f'{book:4} {len(RESIDUAL[book])-len(live)}/{len(RESIDUAL[book])} residual as ruled'
                       + ('' if not live else f'  LIVE: {live}'))


# ---------------------------------------------------------------- 8 ruled leaves
LEAVES = {
    # ⚠️ HAPPY HARRY'S DIALECT IS A PLOT DEVICE. Tom identifies the disguise by
    # hearing the dialect slip; a pass that regularises it deletes the clue.
    # Also here: every malapropism Option B deliberately kept, so a later
    # instance who reads them as leftovers and "finishes the job" FAILS.
    'TS': [r'\byouse\b', r'\bcully\b', r'\bnuttin\b',
           r'circumlocuted', r'liverage', r'\blivery\b', r'monstrousness',
           r'conjure-man', r"I'll explanation", r"'bout mush", r'named Paul',
           r'\bqueer\b', r'\btramp\w*', r"\ban'", r'\bain\W*t\b', r'\bjest\b',
           r'\bpow\W*ful\b', r'\ballers\b', r'\bindeedy\b', r'\bhurted\b',
           r'quality folks'],
    # Mercy's own voice, the characters' own uses, and the disability itself.
    'RF': [r'tied to this chair', r'wheel chair', r'this old chair',
           r'leetle lame gal', r'gal--the cripple', r'The lame girl, sir',
           r'crippled as he was', r'her crippled brother',
           r"Curtis' crippled daughter", r'\bqueer\b', r'\bjapanned\b',
           r'\bseraglio\b', r'\bbrave\b', r"'Liza"],
    # Jake's BC5 ruling: `chinks` STAYS. Asserted present so a future instance
    # who "helpfully" fixes it fails the battery.
    'BC': [r'\bchinks\b', r'Japanese print', r'\bqueer\b', r'\bcocked\b',
           r'Home for Tramps', r'\broosters\b', r'\bbeggars\b'],
}


# ⚠️ FILE-SCOPED LEAVES. `dat` and `de` are Happy Harry's AND Eradicate's, so a
# book-wide count cannot express "unchanged for the tramp, gone for Eradicate" -
# v1 asserted it book-wide and read 63->19, which is the CORRECT outcome failing
# a badly-posed check. The tramp's chapters are named explicitly instead.
# ⚠️ v2: BYTE IDENTITY, NOT COUNTS. Scoping `dat` to the tramp's CHAPTERS still
# failed 20->19, because ch-20 contains BOTH Happy Harry's fellow hobo AND
# Eradicate - so no file-level count can express the ruling either. The right
# assertion for "not one token touched" is not a count at all: it is that the
# tramp's files are byte-identical and his one paragraph in the shared chapter
# is present verbatim. A count can be satisfied by an accident; bytes cannot.
TRAMP_FILES = ('chapter-11.xhtml', 'chapter-19.xhtml')
TRAMP_PARA = ('&quot;He ain&#x27;t one of us, youse can make up your mind to dat,'
              '&quot; said one &quot;hobo&quot; whom Tom interviewed.')


def c8():
    print('\n[8] ruled leaves: counts EQUAL between PRISTINE and shipped')
    for book in BOOKS:
        pris = booktext(PRIS, book)
        ship = booktext(None, book)
        bad = {}
        for pat in LEAVES[book]:
            a = len(re.findall(pat, pris))
            b = len(re.findall(pat, ship))
            if a != b or a == 0:
                bad[pat] = f'{a}->{b}'
        n_scoped = 0
        if book == 'TS':
            for f in TRAMP_FILES:
                n_scoped += 1
                a = open(f'{PRIS}/TS/{TEXTDIR}/{f}', 'rb').read()
                b = open(f'TS/{TEXTDIR}/{f}', 'rb').read()
                if a != b:
                    bad[f'{f} @tramp'] = 'NOT byte-identical'
            n_scoped += 1
            shipped20 = open(f'TS/{TEXTDIR}/chapter-20.xhtml', encoding='utf-8').read()
            if shipped20.count(TRAMP_PARA) != 1:
                bad['ch-20 hobo paragraph'] = 'not verbatim'
        tot = len(LEAVES[book]) + n_scoped
        note(not bad, f'{book:4} {tot-len(bad)}/{tot} leaves unchanged'
                      + ('' if not bad else f'  DRIFT: {bad}'))


# ---------------------------------------------------------------- 9 introduced
INTRODUCED = {
    'TS': ['an old Black man', 'the driver', 'the old man', 'the aged whitewasher',
           'energetic sawyer', 'this here old fellow', 'hard-workin', 'lazy fellow',
           'several men I know', 'crooked sticks they throw', 'this here',
           'Mister Swift', 'whitewasher behind him',
           # ⚠️ TS-X2: the HISTORY is kept and only the spelling changed, so
           # this belongs here and not in LEAVES. v1 put it in LEAVES and it
           # read 0->2 - the check was right and the classification was wrong.
           "befo' the war", 'quality folks'],
    'RF': ['Mercy', 'their daughter', 'the girl', 'exclaimed', 'cried',
           'snapped Mercy', 'whistled Tom', 'many murmurs', 'cheery tooting',
           'delightfully rambling', 'her hair in innumerable pigtails'],
    'BC': ['merry party', 'bright collar', 'tip his head', 'little Black boy'],
}


def c9():
    print('\n[9] introduced-word check (19b): what is OURS, at a glance')
    for book in BOOKS:
        txt = booktext(None, book)
        note(True, f'{book:4} ' + '  '.join(f'{w}={txt.count(w)}'
                                           for w in INTRODUCED[book]))


# ---------------------------------------------------------------- 10 identity
# ⚠️ DERIVED FROM PRISTINE, NOT TYPED. v1 of this check typed `Alvirah 27` and
# `Benny 149` out of nowhere and failed at 78 and 207 - in the same file whose
# own docstring warns against typing a number you can compute. That is the
# SEVENTH consecutive batch in which a failing harness caught MY number and not
# the book's, and the lesson has now been written down five times, so writing it
# down is evidently not the fix: the fix is that a harness may not contain a
# literal count. The assertion that actually matters is that the shipped file is
# the SAME BOOK as the upload - which is a comparison - plus a dc:title match so
# the report cannot silently describe a different title than the one it names.
IDENTITY = {'TS': 'Boomerang', 'RF': 'Alvirah', 'BC': 'Benny'}


def c10():
    print('\n[10] identity assertion (24e): the report describes the right file')
    for book in BOOKS:
        term = IDENTITY[book]
        want = booktext(PRIS, book).count(term)
        got = booktext(None, book).count(term)
        opf = open(f'{book}/{TEXTDIR}/content.opf', encoding='utf-8').read()
        m = re.search(r'<dc:title>([^<]+)</dc:title>', opf)
        got_title = m.group(1) if m else None
        note(got == want and want > 0 and got_title == TITLES[book],
             f'{book:4} {term} x{got} (pristine {want})  dc:title={got_title!r}')


if __name__ == '__main__':
    print('BATCH 26 VERIFY')
    for fn in (c1, c2, c3, c4, c5, c6, c7, c8, c9, c10):
        fn()
    print()
    if FAIL:
        print(f'  {len(FAIL)} FAILURES:')
        for f in FAIL:
            print('   -', f)
        sys.exit(1)
    print('  ALL CHECKS PASS')
