# bookclean-kit — TOOLKIT MANIFEST v1

**Read this before running anything. If you received fewer than 13 `.py` files, you received a
partial toolkit and the README you were handed was lying to you.**

⚠️ **THIS FILE EXISTS BECAUSE OF A REAL FAILURE.** Batches 17, 18 and 19 each shipped a README
listing an eight-step toolchain and then delivered **four** scripts. Five more tools were written,
used, and cited as evidence in the handoff — and never written to disk at all. Their numbers went
into three staging decisions that no shipped script could reproduce. A later instance noticed the
gap; that is the only reason it was caught.

**The rule that follows: the toolkit is a fixed inventory with a count. Check the count.**

---

## The 13 files

### Library tools — book-agnostic, no cwd dependency, copy once and keep

| # | File | Ver | Job | Origin |
|---|---|---|---|---|
| 1 | `dump.py` | — | EPUB → text in **spine order, read from the OPF**. Never sort filenames. | batch 6 |
| 2 | `scan.py` | — | The cumulative pattern scan, twelve blocks, deduped. **§16a CLOSED in batch 25**; `--selftest` added. | batch 2, grown 16× |
| 3 | `ctx.py` | — | Full paragraph per hit. Hit and context printed as **separate fields** (15b). | batch 7 |
| 4 | `stemaudit.py` | — | Audits **the pattern list** for hidden inflections, not the book. | batch 16 |
| 5 | `rawcheck.py` | 1.0.0 | Raw XHTML vs the dump. Attributes (16d), and **previous-pass fingerprints** (17a). | batch 17 |
| 6 | `gapcheck.py` | 1.0.0 | What `scan.py` is **not** looking for. Plus the false-positive-table audit. | batch 17 |
| 7 | `scene.py` | **1.1.0** | **Seven** shape probes: teeth, respelling, worship, spectacle, marking, hero contempt, **NAMEDBY**. | batches 17–18, 25 |
| 8 | `quality.py` | **1.3.0** | Conversion damage. Defects / **REVIEW** / expected noise, three tiers. ⚠️ batch 25 bumped the VERSION *constant*, which said 1.2.0 while this table said 1.3.0. | batch 17 |
| 9 | `measure.py` | **1.1.0** | Staging facts: TOC, archaic register, typability, dialect load, spine. ⚠️ **all pre-25 archaic-density figures WITHDRAWN.** | batches 17–19, 25 |

### Batch-local tools — rewritten every batch, live **in the batch directory**

| # | File | Job |
|---|---|---|
| 10 | `edits.py` | The edit table as **data**: id, file, old, new, count. Dry-run entry point. **`--table` renders the review table from the same rows.** May carry a data sidecar (see below). |
| 11 | `apply.py` | Applies with assertions. **Never filter its output** (10b). |
| 12 | `verify.py` | **Nine** checks + the frontmatter guarantee. Exits nonzero. Forward-diff is now standing, not optional. |
| 13 | `frontmatter.py` | Idempotent note + CC0 check. Imports `AUTHORS`/`BOOKS` from `edits.py`. |

⚠️ **10–13 use paths relative to the batch directory and will `FileNotFoundError` if run from the
toolkit folder.** That is correct behaviour, not a bug: they are scoped to one batch's books. Copy
them into the batch dir and edit. 1–9 run from anywhere.

---

---

## ⚠️ BATCH 26 — A COUNT CANNOT EXPRESS EVERY RULING, AND A SITE-LIST IS ITSELF A SCANNER

Three books shipped (Tom Swift, Ruth Fielding, Box-Car Children), 151 rows. Two tool lessons
that generalise past this batch, plus one new required artifact.

### ⚠️ NEW REQUIRED ARTIFACT: `PRISTINE/` — the uploads, unzipped, whole-book, read-only

`ORIG/` only ever held the files a row **touched**, which is why every prior batch's "ruled
leave" check had nothing to compare against and was forced to carry **typed constants** — the
direct cause of the harness failing on my own number in seven consecutive batches. Unzip the
uploaded EPUBs to `PRISTINE/<KEY>/` at the start of every batch. Then:

* check 8 (ruled leaves) becomes `count(PRISTINE) == count(shipped)` — **no number to mistype**
* check 10 (identity) becomes the same comparison plus a `dc:title` match against `TITLES[]`
* check 6 (forward-diff) can replay the WHOLE touched set from the upload, not from a partial

⚠️ **THE RULE THAT REPLACES THE PROSE: A HARNESS MAY NOT CONTAIN A LITERAL COUNT.** Writing
"do not type a number you can compute" into a docstring has now failed five times — batch 26
violated it *in the same file as the warning*. Derive from `edits.py` or derive from `PRISTINE/`.

### ⚠️ A COUNT CANNOT EXPRESS "NOT ONE TOKEN TOUCHED". USE BYTES.

*Tom Swift* has two dialect speakers with opposite rulings: Eradicate de-dialected, Happy Harry
untouched because his dialect slipping IS the clue that unmasks him. Asserting the tramp's
`dat` unchanged **book-wide** failed 63→19; scoping it to his **chapters** still failed 20→19,
because ch. 20 contains both him and Eradicate. Both failures were the check being right about
a badly-posed assertion.

**The correct assertion is byte identity**: chapters 11 and 19 byte-identical to `PRISTINE/`,
plus the ch. 20 hobo paragraph asserted present verbatim. **A count can be satisfied by
accident; bytes cannot.** Use this shape for every keep-it-entirely ruling that shares a file
with an edited one.

### ⚠️ `plain()` MUST UNESCAPE ENTITIES, OR EVERY APOSTROPHE PATTERN SILENTLY PASSES

Gutenberg conversions write every apostrophe as `&#x27;`. Without `html.unescape`, `\byo'`,
`\bdoan't`, `\ban'`, `pow'ful`, `'bout mush`, `Curtis' crippled daughter` match NOTHING in
both directions — six leave patterns read `0->0` and one residual pattern **reported success
while being incapable of failure.** 25h again. `verify.py` now guards with `a == 0`, so **a
pattern that can never match FAILS.** Add that guard to any comparison check you write.

### ⚠️ `titlepage.xhtml` IS EXCLUDED FROM EVERY COUNT

`\btramp\w*` read 72→73 because our own corrected classroom note contains the words "the
tramp's dialect". **A harness that counts our prose as the author's cannot tell an edit from a
disclosure.**

### ⚠️ THE SITE LIST YOU BUILD THE TABLE FROM IS ITSELF A SCANNER

I enumerated *Ruth Fielding*'s narratorial disability labels with a grep for `the crippled
girl` and missed `the LITTLE crippled girl`. **An intervening adjective defeated the pattern**
— the third instance of this exact shape after `/\bpecker\b/` (16a) and the written `gay*`
stem that cannot reach `gaiety` (25j). **Enumerate with `the [a-z]* cripple`, not `the
cripple`, and treat your own grep with the suspicion you give `scan.py`.** The post-apply
residual scan caught both misses; that is now the third time the battery found what the reading
did not.

### `edits.py` additions worth carrying forward

| Addition | Why |
|---|---|
| `raw()` | Single owner of readable-string → file-bytes entity mapping. Rows written readably, converted in one place (Rule 9). ⚠️ Deliberately does NOT touch `&`. |
| `check_amp()` | **Refuses to run the table** if any row carries a bare ampersand. 13c cost a batch to exactly that. |
| overlap detection in `dry()` | Two rows whose `old` spans nest in one file would let apply order decide the result. Caught before apply, not after. |
| `repack.sh` | `mimetype` stored first, uncompressed — and **asserted on the built file**, not assumed. |

### ⚠️ `scene.py` NAMEDBY FLOOR IS PROBABLY TOO HIGH FOR A SHORT BOOK

`the negro` scored **7** against the floor of **8**, so the probe printed no NAMING DECISION on
the single heaviest character problem in the batch. Found by reading and by `scan.py` raw counts
instead. Consider scaling the floor by word count rather than fixing it at 8.


## ⚠️ BATCH 25b — THE CONFIRMATION PASS ON *THE PRINCE AND THE PAUPER*, AND A FIFTH TOOL BUG

Jake asked for a full language pass on a book already deployed, read as new. **The prior pass was
real** — Twain's `wench` is `lass` in the shipped file, using his own word from two lines earlier
— but the read still turned up live items and one more scan bug.

### ⚠️ `scan.py` carried `lust\w*` UNBOUNDED

It fired inside **illustrious, illustrated, blustering, clustered** — 11 of 15
SEXUAL_REGISTER hits on this book, a block that was **73% noise**, every hit needing to be read
to be dismissed. ⚠️ **THIS IS THE IDENTICAL BUG 15a FIXED FOR `cock`** ("`\b` ADDED - was firing
in weathercock/peacock") **and it sat two lines away in the same list for ten batches.**

**When a fix is applied to one token in a pattern list, CHECK THE WHOLE LIST for the same shape.**
Batch 25 already learned this once (§16a's bounded literals were in five blocks, not the one the
write-up named). Twice in one batch is a pattern, not a coincidence.

### ⚠️ `gay*` AS A WRITTEN STEM CANNOT REACH `gaiety` OR `gaily`

CALIBRATION lists `gay*` as always-fix. **`gaiety` and `gaily` are spelled `gai-`, so
`\bgay\w*` does not match either.** In this book `gay` and `gaily` are at zero and `gaiety`
survives at 1 — the prior pass fixed what the stem reached and missed what it did not.
`scan.py` catches these through a separate alternation, so **the tool is right and the
DOCUMENTATION is wrong.** Read the always-fix list as a list of WORDS to hunt, never as a regex.

### The Tudor-English false-positive class, for the next pastiche book

EYE_DIALECT and RESPELL both fire on Twain's 16th-century register and every hit is innocent:
`dar’st` (darest) reads as Southern `dar`; `good den` (good evening) reads as `den`; `fleurs-de-lis`
trips the French-particle carve-out. WORSHIP fired 8 times on `prostrate`/`fell on his knees` — in
a novel set in a royal court, where people kneel professionally. **None is worth a code change;
all are worth knowing before you read 20 paragraphs to clear them.**

### A construction defect no language tool looks for

29 literal `{1}`-style footnote anchors survive in the text — 18 in chapters — with an
`endnotes.xhtml` that has matching labels and **exactly one hyperlink in the whole book.** So the
notes exist, the anchors exist, and nothing connects them. ⚠️ **`quality.py` flagged these as
`page-debris`, which is the right instinct and the wrong name** — they are not conversion litter,
they are Twain's own apparatus left half-converted. **Read a `page-debris` hit before believing
the label.**

---

## ⚠️ BATCH 25 — FOUR TOOL BUGS, AND THREE OF THEM FAILED *QUIETLY*

Found while staging *The Phantom of the Opera*, which Jake then declined. **The book was
vetoed and the session still paid for itself, because a declined book exercises the tools
exactly as hard as a shipped one.** Stage every candidate on the real toolchain even when you
expect a decline.

| Bug | How it failed | Why it survived |
|---|---|---|
| `measure.py spine()` regexed the attribute **pair** `id=...href=...`; SE writes `href` first | printed `?` and `0 words` for all 33 items, then **`total spine words: 0`** with no error | the output *looked like a report*. Fourth SE-specific break after 23a's three |
| `measure.py` ARCHAIC carried `\ban\b(?= [a-z]+ [a-z])` — **the indefinite article** | inflated every book by ~2/1,000 | it sat at the TOP of the top-forms table with the biggest count on the page, every run, for eight batches |
| `scene.py` RESPELL carried bare `\bde\b` | **147 hits on `de Chagny`**, on a book where the other five probes returned clean zeros | no probe had a ceiling assertion — only "does it still fire" |
| `quality.py` `VERSION` said `1.2.0` while this file's table said `1.3.0` | tells the next instance the SE fix is missing when it is present and working | version strings are not harnessed |

⚠️ **THE COMMON SHAPE: a wrong number that looks like a right number.** Three of the four
produced plausible output — a zero total, a 2.5 density, a 147-hit probe — and only the fourth
was a mislabel. §20a's "two published numbers were wrong" and §24a's heading-weld withdrawal are
the same failure a third and fourth time. **The defence that actually worked here was reading
the tool's own top-forms table instead of its summary line.** Do that once per batch.

### Consequences you must not skip

1. ⚠️ **EVERY ARCHAIC-DENSITY FIGURE BEFORE BATCH 25 IS WITHDRAWN.** The corpus's apparent
   `1.0–2.5/1,000` easy floor **was the word `an`**. Rough re-scaling: Black Arrow 18.5→~16.5,
   The Wood 32.4→~30. **Orderings are intact and no shipped or declined book was staged
   wrongly**, so do not re-open settled decisions — but never quote the old floor again.
   Trustworthy figures: *Phantom* 0.2, *Captains Courageous* 2.4. Mean-sentence figures are
   unaffected by this bug and batch 24 onward still stand.
2. **Never regex an attribute PAIR.** XML does not order attributes. `_manifest_map()` in
   `measure.py` is now the single place that parses the OPF manifest; route new code through it.
3. **A count-only probe needs a floor; a noisy probe needs a ceiling.** `scene.py` selftest cases
   now take an optional 4th element, a maximum. The `phantom.txt`/`RESPELL` row asserts `<= 2`
   rather than `== 0` deliberately — asserting zero invites a future instance to delete the probe
   instead of keeping the bound honest.

## ⚠️ NEW PROBE, BATCH 25: `NAMEDBY` — a character called by a group noun

*Phantom* calls a major **sympathetic** character `the Persian` **157 times** and `the daroga`
20 more, and **never gives him a personal name.** `scan.py` and `gapcheck.py` both carry
neither term, so both reported the book near-clean. The only thing that surfaced it was a
forward flag a predecessor wrote by hand.

⚠️ **`NAMEDBY` counts; it does not quote.** `the Italian` once is a description. `the Italian`
ninety times is the character's name, and that is **ST6 at book scale** — mark once, unmark the
rest. A pattern list cannot express "this word is doing a proper noun's job"; a count can. The
floor is 8 (`NAMEDBY_FLOOR`), and anything at or above it is flagged **NAMING DECISION**, which
is a question for Jake, not an edit.

`MARK` covers skin *descriptors* used as names and is structurally blind to bare nationality and
religion nouns. The two probes do not overlap.

## ⚠️ `measure.py typable` — READ THE CENSUS, NOT THE LIST (batch 25)

The mode used to print **one line per occurrence** with the count on the last line. That was
fine for 17g's ten hits. *Phantom* has **4,611**, so it emitted 4,611 lines and the *shape* of
the problem was invisible unless you piped it through `sort | uniq -c` yourself.

It also **counted markup** — it scanned raw XHTML, so a `lang="fr"` attribute counted as
characters a student must type. It now strips tags, resolves entities, excludes front/back
matter, and **leads with a census plus one sample per glyph**.

⚠️ **And the finding that mode produced is worth carrying forward to every Standard Ebook:**
SE wraps each ellipsis as `U+FEFF` + `U+200A` + `…` — a zero-width no-break space, a hair
space, and a single-glyph ellipsis. *Phantom* has 953 of them, one every 89 words, so
**~4,600 characters no student can key.** Ask about the ellipsis question before staging any
SE book with a heavy `…` habit; it is a formatting deliverable in its own right and it is
invisible to every other check in the kit.

---

## ⚠️ SOURCE PROFILE: STANDARD EBOOKS (new, batch 23)

Jake, batch 23: *"we have a few standard epubs for the next few rounds."* So this
is a recurring source type, not a one-off, and it differs from a Gutenberg
conversion in ways that break tools:

| | Gutenberg conversion | Standard Ebooks |
|---|---|---|
| text path | `OEBPS/*.xhtml` | **`epub/text/*.xhtml`** |
| nav file | `nav.xhtml` | **`toc.xhtml`** |
| title page | plain, often broken | **already correct** - `<h1 epub:type="title">` + byline |
| inline markup | sparse | **heavy** - `<abbr>`, `<i lang>`, `<b epub:type>` throughout |
| verse | run together | `<span>` per line, `<br/>` between |
| CC0 | absent | **already present**, SE's own, in `uncopyright.xhtml` |

Consequences, all of them learned the hard way in batch 23:

1. ⚠️ **`quality.py` 1.3.0 - INLINE vs BLOCK TAGS.** `re.sub(r'<[^>]+>', ' ', raw)`
   replaced EVERY tag with a space, MANUFACTURING the defects `double-space` and
   `space-before-punc` hunt for at every mid-sentence tag boundary:
   `<abbr>Mr.</abbr>&#160;Utterson` became `Mr.  Utterson`. On sparse Gutenberg
   markup this rarely fired; on Standard Ebooks it reported **155 defects in
   Jekyll and 311 in North Wind, and the raw files contain ZERO literal double
   spaces.** 466 phantom defects - crying wolf at the scale §20d says is worse
   than having no check at all. `plaintext()` now maps block tags to a newline
   and inline tags to nothing. **Both books report DEFECTS: none.** Harnessed.
2. **`frontmatter.py` must AUGMENT, not rebuild.** See the rule in that file: batch
   22 rebuilt a broken title page; a Standard Ebooks title page is already better
   than what we would write, so batch 23 appends one paragraph. **Check which case
   you are in; do not carry the previous batch's verb.**
3. **Our CC0 wording must not restate SE's.** They dedicate their transcription;
   we dedicate only our edits. `verify.py` asserts SE's own dedication survives
   untouched in its own file.
4. **`verify.py` paths and the nav filename both change.** `epub/content.opf`,
   `toc.xhtml` not `nav.xhtml`.

---

## ⚠️ THE REVIEW TABLE IS THE EDIT TABLE (new, batch 22 — Jake's instruction)

Jake, batch 22: *"I like seeing what you're changing before approving of it, for
future reference."* He had approved a batch where the review table said things
like *"narrator generalisations — recommend fix"* and never showed him a single
replacement string. That is not a review; it is a request for a blank cheque.

**The standing format from batch 23 forward: every row Jake sees carries the
exact `old` string and the exact `new` string.** Not a description of the change.
Not a category. The strings.

```bash
python3 edits.py --table      # the review table, rendered FROM the rows
python3 edits.py              # the dry run, over the SAME rows
python3 apply.py              # the application, over the SAME rows
```

⚠️ **This is not a formatting preference, it is a defence.** Batch 15b produced a
wrong edit string because a display helper corrupted what it printed; batch 3
produced six missed tokens because the edits were written from a summary of the
dump instead of the dump. Both failures are the same shape: **the thing reviewed
and the thing applied were different objects.** Rendering the table out of
`edits.py` makes them one object, so a table Jake approves cannot describe an
edit that is not the edit.

Rows too long to read in a table (a 44-paragraph advertising block) go in a
**data sidecar** — `bh13-adblock.txt` — and `edits.py` reads the file. The bytes
stay reviewable, the assertion stays a real `str.count`, and `pack.sh` packs any
`*-adblock.txt` / `*-cut.txt` automatically. **Never build a large `old` span by
slicing between markers**; a slice cannot be reviewed and cannot be asserted.

---

## ⚠️ EDITING VERSE (new, batch 23)

Prose takes a word swap. Verse does not, and batch 23 was the first batch to have
to compose rather than substitute.

**Before touching a line of verse, establish three things:** the rhyme partner,
the syllable count, and whether the token IS the joke. Then:

- **Mid-line, no rhyme involved, same syllable count** -> ordinary substitution.
  (`The gay wasp` -> `The bright wasp`.)
- **Rhyme-bound** -> the replacement must restore the rhyme, not just the sense.
  `where the cock never crew` rhymes with `blew`, so `crew` could not be swapped
  alone; `where the lark never flew` keeps rhyme, metre and meaning.
- **The token is the joke** -> recompose around a different base. MacDonald's
  `Cockchafers, henchafers, cockioli-birds / Cockroaches, henroaches...` IS the
  cock-/hen- pairing game. It became `Maychafers, haychafers, tickolori-birds /
  Black-beetles, hen-beetles...` - and **`maychafer` and `black-beetle` are both
  genuine Victorian English names for those same two insects**, so the real
  creatures survive under real names and only the nonsense twin is re-coined.
- ⚠️ **RECORD THE SCANSION IN THE EDIT ROW.** Every N6 row in batch 23's `edits.py`
  carries its syllable arithmetic as a comment, so the next instance can check the
  count instead of trusting a predecessor's ear. An edit to verse that no one can
  re-derive is not reviewable.
- **A third party's quoted poem is still editable if Jake says so.** Batch 23
  changed a line of James Hogg's *Kilmeny* quoted inside MacDonald. Jake: *"I
  don't care about the original quote. If I did, we wouldn't be doing this."*
  ⚠️ **But say plainly in the README that you did it** - silently rewriting a
  quotation attributed to a named author is the one edit a reader could call
  falsification, so it gets disclosed in the note on the title page too.

---

## Order of operations

```bash
# 0. STAGING — before any scan. Free, and it has been right every time (19a).
python3 measure.py toc      BOOK/
python3 measure.py register BOOK.txt          # 16j: prose can disqualify a clean book
python3 measure.py dialect  BOOK.txt Name,Name2   # 19c: what typing does to dialect

# 1. WHAT ALREADY HAPPENED TO THIS FILE (17a)
python3 rawcheck.py BOOK/ --fingerprint

# 2. FORMATTING — is this a content pass or a repair job?
python3 quality.py       BOOK/
python3 measure.py typable BOOK/

# 3. READING
python3 dump.py      BOOK/OEBPS/content.opf > book.txt
python3 stemaudit.py book.txt                 # the patterns, not the book
python3 scan.py      book.txt
python3 gapcheck.py  book.txt                 # what the scan cannot see
python3 scene.py     book.txt                 # what no pattern can see
python3 ctx.py       book.txt '\bpattern\w*'
python3 rawcheck.py  BOOK/ --diff book.txt    # raw vs dump; attribute blind spot

# 4. TABLE THE FINDINGS AND STOP. Wait for Jake's rulings. (15f was a breach here.)

# 5. SHIP
python3 frontmatter.py                        # state, before anything
python3 edits.py                              # DRY RUN vs raw source
python3 apply.py                              # asserted
python3 verify.py                             # 8 checks
```

---

## Self-tests — run these first on any new machine

```bash
python3 measure.py selftest      # reproduces the numbers cited in HANDOFF 17f / 19c
python3 quality.py --selftest    # proves the three false-positive fixes
python3 scene.py  --selftest     # proves every probe still fires on its own case
```

⚠️ **`measure.py selftest` needs the batch 17–19 books unpacked at `../batch17/`, `../b18/`,
`../b19/`.** If they are gone it prints `SKIP`, which is honest but useless. **Keep one unpacked
book per staging decision, or the selftest is decoration.**

---

## Two bugs found while writing this manifest — both worth remembering

**1. Chained `.replace()` on regex source.** `gapcheck.py` and `rawcheck.py` both built patterns as:

```python
t.replace(' ', r'[\s-]+').replace('-', r'[- ]')     # BROKEN
```

The second call ate the hyphen **inside the first call's character class**, producing `[\s[- ]]+`
and a compile error on any multi-word term. ⚠️ **Each `.replace()` sees the previous one's
metacharacters.** Both now tokenise once through `term_pattern()`.

**2. `quality.py` cried wolf for three batches.** `/\.\.(?!\.)/` matched the last two dots of every
legitimate three-dot ellipsis; `/[,;]{2,}/` matched across the entity `&#x27;,`; and `mojibake`
matched the curly quotes themselves, reporting 3,339 hits on a clean book. **Every "defect" I
dismissed by hand in batches 17–19 was one of these three.** A check that cries wolf trains you to
skim it, which is worse than not having it. Fixed in 1.1.0, and the selftest asserts zero spurious
hits on four already-shipped books.

---

## Known outstanding work, oldest first

1. ✅ **CLOSED, BATCH 25: the §16a hard-bounded literals.** Open since batch 16, nine batches.
   ⚠️ **The reason it stayed open is that THE REGEX RULE's own prescription is wrong here.**
   `\bass\w*` matches *assistant, assume, assembly, assassin* — hundreds of hits per novel, the
   23a cry-wolf failure at a scale that would make the ANATOMY block unreadable. `\w*` is right
   for stems like `gay`/`cock` where the inflections are few and glanceable; it does not
   generalise to a short word that is also the prefix of a common one. **The actual gap §16a
   named was PLURALS, so batch 25 added plurals and nothing else** — `plural()` + `PLURALISE`,
   applied to every block, not just the one the write-up mentioned. `peckers` now matches;
   `assistant` still does not. `python3 scan.py --selftest` asserts **both** directions, 28
   cases. Scan totals on the batch-25 books were unchanged, so this is coverage without noise.
   ⚠️ Terms deliberately NOT pluralised (dialect function words, invariant ethnonyms, mass
   nouns, adjectives) are listed with a reason each in the file. Read that list before adding.
2. ⚠️ **`weld-in-para` (quality.py 1.2.0) is a REVIEW tier, not a gate, and that is
   deliberate.** `weld-no-space` only ever matched at a `</p><p>` boundary, so a
   line-break weld *inside* a paragraph was structurally invisible: Ranch Girls
   ch. 11 reads `She paused fora long moment` and 1.1.0 reported `DEFECTS: none`.
   The new check flags a once-only token that splits into two attested fragments
   **whose pair occurs elsewhere in the book as a bigram** — `agray` → `a gray`
   fires, `Andrew` → `an drew` does not. It still returns ~10–25 lines per book
   with maybe 3 real hits, so it **prints the whole short list and never fails a
   build**: §20d says a check that cries wolf is worse than no check, and the
   honest response to a check that cannot reach zero is to stop calling it a
   defect. ⚠️ Its first version had an off-by-one (`range(1, len(lw)-1)`) that
   made it unable to see `fora`, **the single case it was written for** — the
   detector failed on its own founding example, and only running it against the
   book that contained the defect exposed that.
3. ⚠️ **`gapcheck.py --coverage` now quantifies §18h**, and it is worse than the handoff says:

   ```
   skin / hair descriptors      2/16 covered
   phrase-form race labels      2/11 covered
   disability                   1/11 covered
   antisemitic coding           2/10 covered
   minced oaths                 0/10 covered
   body / anatomy               1/5  covered
   ```

   These are the categories that produced the last five batches' findings.
4. ⚠️ **`breast` is the only term in the handoff's HIGH-FREQUENCY FALSE POSITIVES table that is not
   in any block** (`gapcheck.py --table` proves it, 1 of 27). It has a paragraph explaining it is
   noise in two books, and has therefore never actually been scanned. **A prose dismissal is not a
   pattern.**
5. **`customFlaggedWords` still has not been pasted into `settings/languageFilter`.** Open since
   batch 3, now sixteen batches.

---

## Packing — every batch, no exceptions

```bash
./pack.sh <batch-number>        # -> bookclean-kit-batch<N>.tar.gz
```

⚠️ **`pack.sh` is a GATE.** It refuses to build on: a `.py` count other than 13, a missing required
file, a script that will not parse, a failing selftest, or **a selftest that ran zero cases**. Do not
add `--force`. A refusal is the build telling you something is wrong.

`--no-selftest` exists only for a machine where the reference books are genuinely not unpacked.
Using it means the tarball ships unproven.

The tarball carries all 13 tools, both docs, `pack.sh` itself, `CONTENTS.txt` and
`MANIFEST.sha256`. Verify on arrival:

```bash
tar -xzf bookclean-kit-batch<N>.tar.gz
cd bookclean-kit-batch<N> && sha256sum -c MANIFEST.sha256
ls -1 *.py | wc -l             # must be 13
```

⚠️ **Cleaned EPUBs stay OUT of the tarball** — they deploy one at a time through the GitHub web UI,
so a tarball would have to be unpacked before it could be used. **Kit tarred, books loose.**
