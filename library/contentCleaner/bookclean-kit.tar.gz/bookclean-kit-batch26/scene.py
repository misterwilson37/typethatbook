#!/usr/bin/env python3
"""scene.py 1.1.0 - what a token list structurally cannot see.

Consolidates the ad-hoc probe scripts from batches 17 and 18 (`scene.py` and
`probe.py`, neither ever shipped). Written to disk in batch 20.

⚠️ EVERY BLOCK HERE EXISTS BECAUSE READING FOUND SOMETHING A PATTERN COULD NOT.
These are SHAPES, not words. A shape has no stem, so `scan.py` and
`stemaudit.py` are both structurally blind to it:

  TEETH      batch 14 documented "teeth offered as the notable feature of a
             person whose face has just been called dark" as a template, and
             four batches later still had no pattern for it. It fired once in
             The Phoenix and the Carpet, in the canonical form, and only
             reading caught it (18c).
  RESPELL    consonant-substitution respelling. EYE_DIALECT is built for the
             American South, so it caught 1 of 9 tokens of Levinstein's
             stage-Yiddish in The Story of the Amulet (18a). This looks for the
             MECHANISM instead of the vocabulary.
  WORSHIP    the white-person-as-god structure. No vocabulary at all (18c).
  SPECTACLE  narrator presenting a family's poverty/illness/violence as
             entertainment. This is what declined Penrod (19c).
  MARK       skin/ethnicity used as a person's standing NAME (ST6).
  HERO       a sympathetic character voicing contempt with no correction (9).

⚠️ EXPECT FALSE POSITIVES AND READ THEM. This tool proposes nothing; it points
at paragraphs. Batch 19's `brown-skinned youth` took three chapters to clear and
turned out to be a suntanned white schoolboy. That chase is the tool working.

USAGE
  python3 scene.py book.txt [book2.txt ...]
  python3 scene.py book.txt --only TEETH,MARK
  python3 scene.py --selftest
"""
import re, sys, os

VERSION = '1.1.0'

PROBES = {
 'TEETH': [
   r'\bteeth\b[^.]{0,70}\b(gleam\w*|flash\w*|shone|shine|white|gloss\w*)',
   r'\b(white|gleaming|flashing|glistening)\s+(?:\w+\s+){0,2}teeth\b',
   r'\bwhites? of (?:his|her|their) (?:eyes|teeth)\b',
 ],
 'RESPELL': [
   # voiced/unvoiced swaps and th-stopping: the mechanism behind stage-Yiddish,
   # stage-German, stage-Italian alike. \b-anchored to limit the noise.
   # ⚠️ BATCH 25: `de` was bare, and it fired 147 times in The Phantom of the
   # Opera - EVERY hit the French nobiliary particle (`de Chagny` x136,
   # `de Mattos`, `Roi de Lahore`). Five of the six probes returned a clean zero
   # on that book and this one returned 147, which is the 23a cry-wolf failure
   # exactly: a probe that fires on every French name trains you to skim the one
   # tool in the kit whose whole job is to be read by eye. Stage-German `de`
   # stands in for `the`, so it precedes a LOWERCASE noun; the particle always
   # precedes a capitalised surname. More French is queued (Musketeers), so this
   # would have recurred.
   r'\b(chust|goot|hant|hants|gommon|tream|dat|dis|dem|dey|vas|vell|vould)\b',
   r'\bde\b(?! [A-Z])',
   r'\b\w*(?:zh|tsch|shp|shtr)\w*\b',
   r'\b(ze|zat|zis|zose)\b',
 ],
 'WORSHIP': [
   r'\b(fell (?:flat |down )?(?:on|upon) (?:his|her|their) (?:faces|knees)'
   r'|prostrat\w+|grovell?\w+|strangely humble|crooning|kowtow\w*)\b',
   r'\b(white|pale)[- ](crowned|skinned|faced)\b[^.]{0,60}\b(queen|king|god|chief)\b',
   r'\bworshipp?\w*\b[^.]{0,50}\b(white|stranger|visitor)\b',
 ],
 'SPECTACLE': [
   r'\b(fascinating|remarkable|extraordinary|wonderful) (?:\w+ ){0,2}'
   r'(family|creature|people|specimen)\b',
   r'\bglamour of sensationalism\b|\brich glamour\b',
   r'\bwas rewarded by (?:a|the) (?:fine|good|excellent) view\b',
   r'\bfor the first time in (?:his|her|their) li(?:fe|ves)\b[^.]{0,60}\b(moved|figured|shone)\b',
   r'\byou (?:will|can|may) (?:look|see|observe)\b[^.]{0,50}\bnext\b[^.]{0,40}\byou meet\b',
 ],
 'MARK': [
   r'\bthe (copper|coppery|dark|dusky|swarthy|brown|black|yellow)[- ]?'
   r'(colou?red|skinned|faced)? ?ones\b',
   r'\bthe (copper|coppery|dark|dusky|swarthy|brown|black|yellow)[- ]'
   r'(colou?red|skinned|faced)\b',
   r'\b(copper|coppery|dark|dusky|swarthy|brown|black|yellow)[- ]'
   r'(colou?red|skinned|faced)\s+(language|tribe|subjects|natives|fingers|boys|girls)\b',
   r'\bthe (deformed|crippled|hunchbacked?|dwarfish|lame|blind|dumb)\s+'
   r'(leader|man|boy|girl|fellow|spy|one)\b',
 ],
 # ⚠️ BATCH 25. NAMEDBY is the only probe here that counts instead of quoting,
 # and it exists because of a book that was DECLINED before the probe could be
 # used on it. The Phantom of the Opera calls a major sympathetic character
 # `the Persian` 157 times and `the daroga` 16 more, and NEVER gives him a
 # personal name. Neither scan.py nor gapcheck.py carries `Persian` or `daroga`,
 # so both reported the book near-clean; the only reason it surfaced was a
 # forward flag a predecessor wrote by hand in the road map.
 #
 # ⚠️ THIS PROBE IS ABOUT FREQUENCY, NOT PRESENCE. `the Italian` once is a
 # description. `the Italian` ninety times is the character's name, and that is
 # the ST6 decision (mark once, unmark the rest) at book scale. A pattern list
 # cannot express "this word is doing a proper noun's job" - a count can.
 # MARK covers skin DESCRIPTORS used as names; this covers bare nationality and
 # religion nouns, which MARK is structurally blind to.
 'NAMEDBY': [
   r'\bthe (Persian|Portuguese|Italian|Frenchman|Spaniard|Dutchman|Turk|Arab'
   r'|Jew|Jewess|Hindoo|Hindu|Chinaman|Chinee|Negro|Negress|African|Moor'
   r'|Egyptian|Russian|Swede|Dane|Norwegian|Greek|Armenian|Syrian|Malay'
   r'|Kanaka|Lascar|Creole|Mulatto|Half-breed|Indian|Esquimau|Eskimo'
   r'|Gipsy|Gypsy|Mexican|Cuban|Jap|Japanese|Chinese|Irishman|Scotchman'
   r'|Welshman|Yankee|Britisher|German|Austrian|Pole|Bohemian|daroga)\b',
 ],
 'HERO': [
   r"\bthey(?:'| a)?re only\b",
   r"\bdon'?t know any better\b",
   r'\bof both kinds\b',
   r'\bI[\u2019\']ve[\u2014\-]?heard\b[^.]{0,40}\balways\b',
   r'\b(only|just|merely) (savages|natives|heathens|coloured|blacks)\b',
 ],
}


def load_spine(dumpfile):
    text = open(dumpfile, encoding='utf-8').read()
    parts = re.split(r'\n\n===== FILE: (.+?) =====\n', text)
    return [(parts[i], parts[i + 1]) for i in range(1, len(parts), 2)]


# ⚠️ BATCH 25: probes that report a CENSUS rather than paragraphs. NAMEDBY on a
# book like Phantom would print 173 paragraphs, which is not a finding anyone
# reads - the finding is the NUMBER against a character, and where it clusters.
COUNT_ONLY = ('NAMEDBY',)
NAMEDBY_FLOOR = 8      # below this it is a description, not a name (cf. 19c)


def run(dumpfile, only=None, verbose=True):
    import collections
    hits = {}
    if verbose:
        print(f'\n########## {os.path.basename(dumpfile)} ##########')
    for label, pats in PROBES.items():
        if only and label not in only:
            continue
        n = 0
        if label in COUNT_ONLY:
            forms = collections.Counter()
            where = collections.defaultdict(collections.Counter)
            first = {}
            for fname, body in load_spine(dumpfile):
                for p in pats:
                    for m in re.finditer(p, body, re.I):
                        n += 1
                        key = m.group(1).lower() if m.groups() else m.group(0).lower()
                        forms[key] += 1
                        where[key][fname] += 1
                        if key not in first:
                            st = max(0, m.start() - 110)
                            first[key] = re.sub(
                                r'\s+', ' ', body[st:m.end() + 110]).strip()
            hits[label] = n
            if verbose and n:
                print(f'  [{label}] a person referred to BY GROUP NOUN, by count.')
                print(f'          >= {NAMEDBY_FLOOR} means it is functioning as a '
                      f'NAME (naming decision), not a description.')
                for k, c in forms.most_common():
                    mark = '  <-- NAMING DECISION' if c >= NAMEDBY_FLOOR else ''
                    top = ', '.join(f'{f[:14]}x{v}' for f, v in
                                    where[k].most_common(4))
                    print(f'    the {k:14s} {c:4d}   [{top}]{mark}')
                for k, c in forms.most_common():
                    if c >= NAMEDBY_FLOOR:
                        print(f'    first use of `the {k}`:')
                        print(f'      ...{first[k]}...')
            continue
        for fname, body in load_spine(dumpfile):
            for p in pats:
                for m in re.finditer(p, body, re.I):
                    n += 1
                    if verbose:
                        s = max(0, m.start() - 130)
                        ctx = re.sub(r'\s+', ' ', body[s:m.end() + 130]).strip()
                        print(f'  [{label}] {fname[:20]} @{m.start()}')
                        print(f'      ...{ctx}...')
        hits[label] = n
    if verbose:
        print('  ' + '  '.join(f'{k}={v}' for k, v in hits.items()))
    return hits


def selftest():
    """⚠️ Rule 10: each probe must FIRE on the book it was derived from. A probe
    that no longer catches its own originating case is a dead probe."""
    here = os.path.dirname(os.path.abspath(__file__))
    cases = [
        ('../b18/carpet.txt', 'TEETH',     'the Carpet teeth template (18c)'),
        ('../b18/carpet.txt', 'MARK',      'copper-coloured as a standing name (18c)'),
        ('../b18/carpet.txt', 'WORSHIP',   'the Queen Cook structure (18c)'),
        ('../b18/carpet.txt', 'HERO',      "Cyril's 'only savages' (18c)"),
        ('../b18/amulet.txt', 'RESPELL',   'Levinstein stage-Yiddish (18a)'),
        ('../b19/penrod.txt', 'SPECTACLE', 'the Herman/Verman family page (19c)'),
        ('../b19/penrod.txt', 'RESPELL',   'Herman eye-dialect (19c)'),
        # ⚠️ BATCH 22: every case above lives in a SIBLING batch directory, so on a
        # fresh machine all seven SKIP and pack.sh correctly refuses to build.
        # §20c has asked since batch 20 that the reference books be kept and
        # nobody keeps them. The durable fix is to cite the CURRENT batch, whose
        # books are on disk by definition - `measure.py` and `quality.py` 1.2.0
        # now do the same. Each batch adds its own row; the probe that fired on
        # the batch's own books is the one worth asserting.
        ('bighorn.txt', 'TEETH',   'Virginia\'s "even white teeth" (22d) - the batch-14'
                                   ' template firing on a white character, which is why'
                                   ' the probe is shape-based and not race-based'),
        ('bighorn.txt', 'RESPELL', 'the ch.17 Latin recitation and ch.3 "fol-de-rol" (22d)'),
        ('ranch.txt',   'HERO',    "Jack's \"perfect dunces\" line (22b)"),
        # BATCH 23: the two probes that fired on Standard Ebooks. Both were false
        # positives on reading, and asserting them is still worth it - a probe
        # that stops firing has usually broken rather than improved.
        ('jekyll.txt',    'WORSHIP', 'Jekyll ch10 prostration - FP on reading (23)'),
        ('northwind.txt', 'TEETH',   'sheep in a nonsense rhyme - FP on reading (23)'),
        # BATCH 24: RESPELL fires x9 on Tik-Tok's syllable-hyphenated speech. All
        # false for eye-dialect purposes, but a real TYPING consideration - assert
        # it so nobody "fixes" the probe into silence.
        ('ozma.txt',   'RESPELL', "Tik-Tok's hyphenated speech - FP, but a typing note (24)"),
        ('goblin.txt', 'WORSHIP', 'goblin-court scenes - FP on reading (24)'),
        # ⚠️ BATCH 25. Two rows, and they assert OPPOSITE things about the same
        # book, which is the point.
        #  - NAMEDBY must FIRE on Phantom: 157 `the Persian` is the case the
        #    probe was written for, and it is the only book in the corpus known
        #    to contain it. If this stops firing the probe is dead.
        #  - RESPELL must NOT fire on Phantom's body text. It fired 147 times
        #    before the `de` fix, all of them `de Chagny`. The single surviving
        #    hit is the Standard Ebooks URL in colophon.xhtml, which is not body
        #    text; the assertion is therefore an UPPER BOUND, not zero, because
        #    asserting zero would make a future instance delete the probe rather
        #    than keep the bound honest.
        ('phantom.txt', 'NAMEDBY', '157 `the Persian` + 20 `the daroga` (25)'),
        ('phantom.txt', 'RESPELL', 'MAX 2 - the `de Chagny` FP is fixed (25)',
                                   2),
        # ⚠️ BATCH 26: current-batch dumps, on disk by definition, so these RUN.
        # Every prior reference dump is absent and pack.sh correctly REFUSED
        # until these were added. Each batch must add its own.
        ('TS.txt', 'RESPELL', 'Eradicate Sampson, 106 hits pre-edit (26a)'),
        ('RF.txt', 'MARK', '15 `the lame girl`/`the crippled girl` (26c)'),
        # ⚠️ NAMEDBY scored `the negro` at 7 against a floor of 8, so it printed
        # NOTHING on the single heaviest character problem in the batch. The
        # ceiling form cannot express "should have fired"; this row records the
        # near-miss so the floor question in 26f is not forgotten.
    ]
    ok = True
    ran = 0
    # ⚠️ BATCH 25: a case may carry an optional 4th element, a CEILING. Every
    # case before this asserted only `n > 0` - "the probe still fires" - which
    # cannot express "and it must not fire 147 times on French surnames". A
    # cry-wolf regression was structurally unassertable in a tool whose entire
    # value is being read by eye.
    for case in cases:
        f, label, why = case[0], case[1], case[2]
        ceiling = case[3] if len(case) > 3 else None
        p = os.path.normpath(os.path.join(here, f))
        if not os.path.exists(p):
            print(f'  SKIP {label:10s} {f}')
            continue
        ran += 1
        n = run(p, only={label}, verbose=False)[label]
        good = (n > 0) if ceiling is None else (0 < n <= ceiling)
        ok = ok and good
        bound = '' if ceiling is None else f' (max {ceiling})'
        print(f'  {"OK  " if good else "FAIL"} {label:10s} x{n:<4d}{bound} {why}')
    # ⚠️ BATCH 20: an all-SKIP run used to return SUCCESS, so pack.sh
    # printed '3/3 pass' on a machine with no reference books. A selftest
    # that proves nothing must FAIL.
    if ran == 0:
        print('\n*** SELFTEST FAILED: 0 cases ran - dumps absent. ***')
        return False
    print(f'\n{ran}/{len(cases)} cases ran')
    print('SELFTEST PASS' if ok else '*** SELFTEST FAILED - a probe went dead ***')
    return ok


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        sys.exit(0 if selftest() else 1)
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    only = None
    args = sys.argv[1:]
    if '--only' in args:
        i = args.index('--only')
        only = set(args[i + 1].split(','))
        args = args[:i]
    for f in args:
        run(f, only)
