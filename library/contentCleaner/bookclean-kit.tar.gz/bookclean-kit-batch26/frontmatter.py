#!/usr/bin/env python3
"""frontmatter.py - BATCH 23. Idempotent note + CC0 injection, then a structural
guarantee (18e).

⚠️ THIS IS THE INVERSE OF BATCH 22 AND THE DISTINCTION IS THE POINT.

Batch 22 ruled: "when the front matter is itself the defect, REBUILD it - do not
repair it in place." Big Horn's prepared title page was a caption blob with a
duplicated line, so it was replaced wholesale.

A Standard Ebooks title page is the opposite case. It ALREADY carries exactly
what the guarantee checks for, with better semantics than we would write:

    <h1 epub:type="title">...</h1>
    <p>By <b epub:type="z3998:author z3998:personal-name">...</b>.</p>

Rebuilding that would destroy correct epub:type semantics, the srcset title
image, and the SE stylesheet hooks - all to arrive somewhere worse. So here we
APPEND one paragraph and touch nothing else.

RULE: rebuild only when the existing front matter is broken. When the source got
it right, augment. Check before choosing; do not carry a previous batch's verb.

Note the CC0 wording is narrower than usual on these two books: Standard Ebooks
already dedicates its own transcription work to the public domain in
`uncopyright.xhtml`, so ours must claim only OUR edits and not restate theirs.
"""
import os, re, sys
from edits import BOOKS, AUTHORS, TITLES, TEXTDIR

CC0 = ('The editorial changes in this edition are dedicated to the worldwide '
       'public domain via the CC0 1.0 Universal Public Domain Dedication '
       '(https://creativecommons.org/publicdomain/zero/1.0/). You may reuse '
       'this edition freely, with or without credit.')

NOTE = {
 'OZMA': (
   'Classroom edition. This public-domain text has had two dated terms reworded '
   'for classroom use by Claude with supervision. L. Frank Baum\u2019s story and '
   'characters are unchanged. Prepared from the Standard Ebooks edition; see the '
   'Imprint and Uncopyright pages for that edition\u2019s own credits.'),
 'GOBLIN': (
   'Classroom edition. This public-domain text has had a small number of dated '
   'terms reworded for classroom use by Claude with supervision, and the goblin '
   'prince, whom the original names for a facial difference, has been renamed '
   'Grumble. George MacDonald\u2019s story and characters are otherwise unchanged. '
   'Prepared from the Standard Ebooks edition; see the Imprint and Uncopyright '
   'pages for that edition\u2019s own credits.'),
 'CC': (
   'Classroom edition. This public-domain text has had a small number of dated '
   'racial terms reworded for classroom use by Claude with supervision, and '
   'three words restored where an earlier digital source had corrupted them. '
   'Rudyard Kipling\u2019s story, characters and ending are unchanged, and the '
   'Gloucester fishermen\u2019s dialect has been kept exactly as he wrote it. '
   'Typographic characters that cannot be typed on a keyboard have been '
   'replaced with ones that can. Prepared from the Standard Ebooks edition; see '
   'the Imprint and Uncopyright pages for that edition\u2019s own credits.'),
}

MARK = 'Classroom edition.'


def inject():
    for book in BOOKS:
        p = os.path.join(book, TEXTDIR, 'titlepage.xhtml')
        s = open(p, encoding='utf-8').read()
        if MARK in s:                     # idempotent
            print(f'  {book:10} already carries the note - no change')
            continue
        para = (f'\t\t\t<p>{NOTE[book]} {CC0}</p>\n')
        assert s.count('\t\t</section>') == 1, f'{book}: unexpected titlepage shape'
        s = s.replace('\t\t</section>', para + '\t\t</section>')
        open(p, 'w', encoding='utf-8').write(s)
        print(f'  {book:10} note + CC0 appended to the existing SE title page')


def guarantee():
    """Structural, not a step. Nonzero exit if anything is missing."""
    bad = 0
    for book in BOOKS:
        p = os.path.join(book, TEXTDIR, 'titlepage.xhtml')
        s = open(p, encoding='utf-8').read()
        n  = s.count(MARK)
        c  = s.count('CC0 1.0 Universal')
        h  = len(re.findall(r'<h1[^>]*epub:type="title"', s))
        by = 1 if re.search(r'<p>By <b', s) else 0
        # SE's own dedication must survive untouched in its own file
        u = os.path.join(book, TEXTDIR, 'uncopyright.xhtml')
        se = open(u, encoding='utf-8').read().count('CC0 1.0 Universal')
        ok = (n == 1 and c == 1 and h == 1 and by == 1 and se == 1)
        if not ok: bad += 1
        print(f'  {"ok  " if ok else "FAIL"} {book:10} note x{n}  ourCC0 x{c}  '
              f'<h1 title> x{h}  byline x{by}  SE-uncopyright x{se}')
    return bad


if __name__ == '__main__':
    print('BATCH 24 FRONTMATTER\n')
    if '--check' not in sys.argv:
        inject()
        print()
    sys.exit(1 if guarantee() else 0)
