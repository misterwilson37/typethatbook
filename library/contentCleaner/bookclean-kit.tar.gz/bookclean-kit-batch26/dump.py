#!/usr/bin/env python3
"""Dump EPUB text in SPINE ORDER (read the OPF; never sort filenames)."""
import re, sys, os, html
import xml.etree.ElementTree as ET

OPF_NS = {'opf': 'http://www.idpf.org/2007/opf'}

def spine_files(opf_path):
    tree = ET.parse(opf_path)
    root = tree.getroot()
    base = os.path.dirname(opf_path)
    manifest = {}
    for item in root.iter('{http://www.idpf.org/2007/opf}item'):
        manifest[item.get('id')] = item.get('href')
    out = []
    for ref in root.iter('{http://www.idpf.org/2007/opf}itemref'):
        idr = ref.get('idref')
        if idr in manifest:
            href = manifest[idr]
            out.append(os.path.normpath(os.path.join(base, href)))
    return out

TAG = re.compile(r'<[^>]+>')
def strip(xhtml):
    # kill script/style, then tags; keep it simple and lossy-but-faithful for READING
    x = re.sub(r'<(script|style)\b.*?</\1>', ' ', xhtml, flags=re.S | re.I)
    x = re.sub(r'<(br|/p|/div|/h[1-6]|/li)\s*/?>', '\n', x, flags=re.I)
    x = TAG.sub('', x)
    return html.unescape(x)

if __name__ == '__main__':
    opf = sys.argv[1]
    files = spine_files(opf)
    for f in files:
        if not os.path.exists(f):
            print(f'### MISSING {f}', file=sys.stderr)
            continue
        raw = open(f, encoding='utf-8').read()
        print(f'\n\n===== FILE: {os.path.basename(f)} =====\n')
        print(strip(raw))
