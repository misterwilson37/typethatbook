#!/usr/bin/env python3
"""measure.py 1.0.0 - facts about a book that decide STAGING, before any edit table.

⚠️ WHY THIS FILE EXISTS (batch 20): every measurement in here was originally run as
a throwaway heredoc, and the numbers went into the handoff as evidence for three
staging decisions that could not be re-derived from any shipped script:

  17f  The Black Arrow shipped despite 18.7 archaic tokens/1000 words
  17g  ten untypable characters fixed across two books
  19c  Penrod DECLINED on 169 dialect-character mentions = 22% of the book
  19d  ~2,960-word PG licence found sitting in the spine

That is a Rule 10 failure in the plainest form: the numbers were authoritative,
they were reported to Jake, they decided whether books shipped - and no harness
existed to reproduce them. Fixed here. Every mode below is checked against the
books it was originally run on; see selftest.

USAGE
  python3 measure.py toc        BOOK/          # read this FIRST, always (19a)
  python3 measure.py register   book.txt       # archaic density, sentence length (16j/17f)
  python3 measure.py typable    BOOK/          # characters no student can key (13b/17g)
  python3 measure.py dialect    book.txt       # eye-dialect load per chapter (19c)
  python3 measure.py spine      BOOK/          # what is in the spine and how big (14e/19d)
  python3 measure.py all        BOOK/ book.txt
  python3 measure.py selftest                  # reproduce the handoff's cited numbers

`BOOK/` is the unpacked EPUB root (the directory containing OEBPS/ or epub/).
`book.txt` is dump.py output.
"""
import re, sys, os, glob, html

VERSION = '1.1.0'

# --------------------------------------------------------------------- helpers
def find_opf(root):
    for pat in ('OEBPS/content.opf', 'epub/content.opf', '*/content.opf', 'content.opf'):
        hit = glob.glob(os.path.join(root, pat))
        if hit:
            return hit[0]
    raise SystemExit(f'{root}: no content.opf found')


def _manifest_map(opf_path):
    """id -> href, parsing each attribute INDEPENDENTLY.

    ⚠️ BATCH 25. The old code was:

        dict(re.findall(r'<item[^>]*id="([^"]+)"[^>]*href="([^"]+)"', raw))

    which assumes `id` is written before `href`. Standard Ebooks writes `href`
    first, so on every SE book the map came back empty, every spine item
    resolved to `?`, every word count was 0, and the total printed as 0 with no
    error raised. Fourth SE-specific tool break after the three in 23a, and the
    worst-behaved of the four because it FAILED SILENTLY into a plausible-looking
    report. XML does not order attributes. Never regex an attribute PAIR.
    """
    raw = open(opf_path, encoding='utf-8').read()
    man = {}
    for tag in re.findall(r'<item\b[^>]*>', raw):
        i = re.search(r'\bid="([^"]+)"', tag)
        h = re.search(r'\bhref="([^"]+)"', tag)
        if i and h:
            man[i.group(1)] = h.group(1)
    return man


def _manifest_hrefs(opf_path):
    """hrefs in SPINE order."""
    raw = open(opf_path, encoding='utf-8').read()
    man = _manifest_map(opf_path)
    return [man[i] for i in re.findall(r'<itemref[^>]*idref="([^"]+)"', raw) if i in man]


def text_files(root):
    base = os.path.dirname(find_opf(root))
    out = sorted(glob.glob(os.path.join(base, '*.xhtml')))
    out += sorted(glob.glob(os.path.join(base, 'text', '*.xhtml')))
    return out


def strip(x):
    x = re.sub(r'<(script|style)\b.*?</\1>', ' ', x, flags=re.S | re.I)
    x = re.sub(r'<[^>]+>', ' ', x)
    return html.unescape(x)


def load_spine_dump(dumpfile):
    """(filename, body) pairs from dump.py output. Same split as scan.load_spine."""
    text = open(dumpfile, encoding='utf-8').read()
    parts = re.split(r'\n\n===== FILE: (.+?) =====\n', text)
    return [(parts[i], parts[i + 1]) for i in range(1, len(parts), 2)]


# ------------------------------------------------------------------------ TOC
def toc(root):
    """⚠️ 19a: free, and it was right on Penrod (3 titles) and Grace (1 false
    positive, cleared by reading). Run before the scan, every time."""
    base = os.path.dirname(find_opf(root))
    # ⚠️ BATCH 25: `toc.xhtml` added. Standard Ebooks names the nav `toc.xhtml`,
    # not `nav.xhtml` (TOOLKIT source profile), so on every SE book this fell
    # through to `toc.ncx`. That happened to work, but it was luck: the ncx is
    # optional in EPUB 3 and an SE book without one reported `0 nav entries`
    # rather than an error.
    labels, navsrc = [], None
    for cand in ('nav.xhtml', 'toc.xhtml'):
        p = os.path.join(base, cand)
        if os.path.exists(p):
            labels = re.findall(r'<a[^>]*>([^<]+)</a>', open(p, encoding='utf-8').read())
            navsrc = cand
            break
    if not labels:
        ncx = os.path.join(base, 'toc.ncx')
        if os.path.exists(ncx):
            labels = re.findall(r'<text>([^<]+)</text>', open(ncx, encoding='utf-8').read())
            navsrc = 'toc.ncx'
    print(f'  {len(labels)} nav entries  (from {navsrc})')
    for i, l in enumerate(labels, 1):
        print(f'   {i:3d}  {html.unescape(l)}')

    # ⚠️ BATCH 25: the CONFIRMATION PASS (road map, step 4) asks this mode for
    # "nav vs spine, and whether any file is orphaned" - and it never compared
    # them. It only listed labels. A documented check that does not exist is
    # worse than a missing one, because the procedure was written trusting it.
    href = _manifest_hrefs(os.path.join(base, os.path.basename(find_opf(root))))
    spine_hrefs = set(os.path.basename(h) for h in href)
    navtargets = set()
    for cand in ('nav.xhtml', 'toc.xhtml'):
        p = os.path.join(base, cand)
        if os.path.exists(p):
            for h in re.findall(r'<a[^>]+href="([^"#]+)', open(p, encoding='utf-8').read()):
                navtargets.add(os.path.basename(h))
    if navtargets:
        orphans = sorted(spine_hrefs - navtargets)
        dangling = sorted(navtargets - spine_hrefs)
        print(f'\n  spine files not reachable from the nav: {len(orphans)}')
        for o in orphans:
            print(f'     {o}')
        if dangling:
            print(f'  ⚠️ nav entries with no spine file: {len(dangling)}')
            for d in dangling:
                print(f'     {d}')
    return labels


# -------------------------------------------------------------------- register
# 16j / 17f. Archaic-register load: can disqualify a lexically spotless book.
ARCHAIC = [
    r"\bY[\u2019']are\b", r'\bye\b', r'\bthee\b', r'\bthou\b', r'\bthy\b', r'\bthine\b',
    r'\bhath\b', r'\bdoth\b', r'\bwot\b', r'\bmethinks\b', r'\bprithee\b', r'\bnay\b',
    r'\bforsooth\b', r'\bsith\b', r'\bwithal\b', r'\bhither\b',
    r'\bthither\b', r'\bwhither\b', r'\btrow\b', r'\bquoth\b', r'\bshalt\b',
    r'\bwilt\b', r'\bhast\b', r'\bere\b', r'\bsooth\b', r'\byea\b',
    # ⚠️ BATCH 25: two more patterns that fired on the MODERN sense. Same class
    # of error as `an` above, just smaller, and found by reading the top-forms
    # table instead of trusting the total.
    #   WAS r'\bart\b'   - 8 hits in Phantom, every one the noun (`a work of
    #                      art`, `the art of`). Archaic `art` is the verb and
    #                      always sits beside `thou`.
    #   WAS r'\bmarry\b' - 8 hits in Phantom, every one the verb. The archaic
    #                      interjection is sentence-initial and comma-followed
    #                      (`Marry, sir!`).
    r'\b(?:thou art|art thou)\b', r'\bmarry\b(?=[,!])',
    r'\bby the mass\b', r'\bby the rood\b', r'\bwhereof\b', r'\bwherefore\b',
    r'\bsaith\b',
    # ⚠️ BATCH 25: WAS r'\ban\b(?= [a-z]+ [a-z])'. That is the INDEFINITE ARTICLE.
    # It fired 179 times in Phantom and every sampled hit was `an inquiry`,
    # `an effort`, `an event`. 179 of 210 "archaic" tokens in that book were the
    # word `an` doing its ordinary job, so the reported 2.5/1,000 was really
    # 0.4/1,000. Because the article rate is roughly constant across English
    # prose, THIS INFLATED EVERY BOOK BY ABOUT THE SAME 2/1,000 - which is why
    # the corpus's two "easiest" books both landed at 2.0-2.5. That floor was an
    # artifact, not archaism. See the CITED withdrawals below.
    # Archaic `an` means `if` (`an it please you`, `an thou wilt`), so it is
    # followed by a pronoun or an expletive subject, never by a bare noun.
    r'\ban\b(?= (?:it|thou|thy|ye|you|he|she|they|I|we|so)\b)',
]
# typing-specific hazards: every one is a keystroke problem, not a reading problem
HAZARD = {
    "mid-word apostrophe (y'are, ha', o')": r"\b[a-z]{1,4}[\u2019'](?=[a-z])",
    "elision at word end (goin', an')":      r"\b[a-z]+[\u2019'](?=\s)",
    "double apostrophe in 3 chars":          r"[\u2019'][a-z]{1,2}[\u2019']",
    "'tis / 'twas / 'twere":                 r"[\u2019']t(is|was|were|will)\b",
}


def register(dumpfile):
    txt = ''.join(b for _, b in load_spine_dump(dumpfile))
    words = len(re.findall(r"[A-Za-z\u2019']+", txt))
    per, tot = {}, 0
    for p in ARCHAIC:
        n = len(re.findall(p, txt, re.I))
        tot += n
        if n:
            per[p] = n
    # ⚠️ BATCH 24 FIX. The old line was:
    #     re.split(r'(?<=[.!?])\s+', txt)
    # which splits ONLY on terminal punctuation. Chapter titles carry none, so
    # every heading welded onto the paragraph beneath it and counted as ONE
    # sentence. The Wood Beyond the World's "longest sentence" was 320 words and
    # began "Walter Sees a Shard in the Cliff-Wall" - a title plus three
    # paragraphs, measured as a single sentence.
    #
    # Inflation measured on this batch:
    #     Ozma of Oz              24.2 -> 17.6   (-6.6)
    #     The Wood Beyond World   42.1 -> 30.1  (-12.0)
    #
    # ⚠️ THE INFLATION IS NOT UNIFORM - it scales with how many unpunctuated
    # lines a book has, so it is larger for books with more chapters. That means
    # it corrupted RANKINGS as well as values, and EVERY mean-sentence figure
    # this project has published is suspect. See CITED below.
    #
    # In dump.py output a newline always marks a block boundary (</p>, </h*>,
    # <br/>), and no real sentence spans a block, so a line break IS a sentence
    # boundary. Caveat: each verse LINE therefore counts as a sentence, which is
    # arguably right but will read low on verse-heavy books.
    txt = re.sub(r'(?<![.!?\u201d\u2019"])\n', '.\n', txt)
    sents = [s for s in re.split(r'(?<=[.!?])\s+', txt) if len(s.split()) > 2]
    mean = sum(len(s.split()) for s in sents) / max(1, len(sents))
    dens = tot / max(1, words) * 1000
    print(f'  words                : {words}')
    print(f'  archaic tokens       : {tot}')
    print(f'  archaic per 1,000    : {dens:.1f}')
    print(f'  mean sentence length : {mean:.1f} words')
    print(f'  --- top archaic forms ---')
    for k, v in sorted(per.items(), key=lambda x: -x[1])[:12]:
        print(f'    {k:26s} {v}')
    print(f'  --- typing hazards ---')
    haz = {}
    for k, p in HAZARD.items():
        n = len(re.findall(p, txt))
        haz[k] = n
        if n:
            print(f'    {k:38s} {n}')
    # ⚠️ no verdict is printed on purpose. 16j is Jake's ruling, not the tool's.
    print(f'\n  reference points (measured with THIS list, v{VERSION}):')
    print(f'    ARCHAIC DENSITY - only these two are trustworthy:')
    print(f'      Phantom of the Opera  0.2/1000  (batch 25, new floor)')
    print(f'      Captains Courageous   2.4/1000  (batch 25; 118 of 132 are `ye`)')
    print(f'    ⚠️  ALL pre-batch-25 density figures are WITHDRAWN - the old list')
    print(f'        counted the indefinite article `an` and inflated every book by')
    print(f'        about 2/1000. The old 1.0-2.5 "easy floor" was the article.')
    print(f'        Rough re-scaling: Black Arrow 18.5->~16.5, Wood 32.4->~30.')
    print(f'    MEAN SENTENCE - unaffected by that bug, batch 24 onward stands:')
    print(f'      Captains Courageous 15.0   Phantom 16.0   Ozma 17.6')
    print(f'      Goblin 17.0   The Wood 30.1  (hardest known)')
    print(f'    ⚠️  pre-batch-24 mean-sentence figures are INFLATED and withdrawn')
    print(f'    Turn of the Screw  DECLINED on prose, not lexis (16j)')
    return dict(words=words, archaic=tot, density=dens, mean_sentence=mean, hazards=haz)


# --------------------------------------------------------------------- typable
# 13b / 17g. Whitelist EXACTLY the five curly quote/dash glyphs and print
# everything else. ⚠️ Do NOT filter by Unicode block: 'œ' and 'æ' are Latin-1
# and would survive a "European letters are fine" rule. The 'ö' in Zoölogy is a
# syllable-break diaeresis, not an umlaut, and no modern student reads it.
KEEP_GLYPHS = '\u201c\u201d\u2018\u2019\u2014\u2013'


# ⚠️ BATCH 25: this mode printed ONE LINE PER OCCURRENCE with no summary.
# Batch 17g had ten hits, so a flat list was fine. Phantom of the Opera has
# 4,605 and the mode emitted 4,605 lines with the count on the last one - so the
# shape of the problem (three characters, repeated 951 times each, wrapping
# every ellipsis) was invisible unless you piped it through `sort | uniq -c`
# yourself. §20d: a check whose output cannot be read is a check that gets
# skipped. Lead with the census, then show a bounded sample.
#
# ⚠️ AND IT COUNTED MARKUP. It scanned the raw XHTML, so a `lang="fr"`
# attribute or an `&#xfeff;` entity inside a tag counted as a character a
# student must type. Strip tags and resolve entities first: the question this
# mode answers is "what will a 13-year-old have to key", and that is the
# RENDERED text, not the source.
SKIP_FILES = ('toc.xhtml', 'nav.xhtml', 'colophon.xhtml', 'uncopyright.xhtml',
              'imprint.xhtml', 'titlepage.xhtml', 'endnotes.xhtml')

# Named so the report can say WHY a character is a problem, not just that it is.
GLYPH_NOTE = {
    '\ufeff': 'zero-width no-break space - INVISIBLE, unkeyable',
    '\u200a': 'hair space - looks like a space, is not one',
    '\u2009': 'thin space - looks like a space, is not one',
    '\u00a0': 'non-breaking space - looks like a space, is not one',
    '\u2026': 'ellipsis as ONE glyph - not three periods',
    '\u21a9': 'endnote back-link arrow',
    '\ufe0e': 'variation selector - INVISIBLE',
}


def typable(root, body_only=True):
    import collections
    census = collections.Counter()
    per_file = collections.defaultdict(collections.Counter)
    samples = {}
    for f in text_files(root):
        bn = os.path.basename(f)
        if body_only and bn in SKIP_FILES:
            continue
        raw = open(f, encoding='utf-8').read()
        txt = html.unescape(re.sub(r'<[^>]+>', '', raw))   # RENDERED text
        for m in re.finditer(r'[^\x00-\x7F]', txt):
            ch = m.group(0)
            if ch in KEEP_GLYPHS:
                continue
            census[ch] += 1
            per_file[bn][ch] += 1
            if ch not in samples:
                seg = txt[max(0, m.start() - 34):m.start() + 34]
                samples[ch] = ' '.join(seg.split())
    total = sum(census.values())
    if not total:
        print('  none')
        return census
    print(f'  {total} untypable characters in the body text'
          f'  ({len(census)} distinct)')
    print(f'  -- census --')
    for ch, n in census.most_common():
        note = GLYPH_NOTE.get(ch, '')
        print(f'    U+{ord(ch):04X} {n:6d}  {ch!r:10s} {note}')
    print(f'  -- one sample each --')
    for ch, n in census.most_common():
        print(f'    U+{ord(ch):04X}  {samples[ch][:70]}')
    worst = sorted(per_file.items(), key=lambda x: -sum(x[1].values()))[:5]
    print(f'  -- heaviest files --')
    for bn, c in worst:
        print(f'    {bn:24s} {sum(c.values()):6d}')
    if body_only:
        print(f'  (front/back matter excluded: {", ".join(SKIP_FILES)})')
    return census


# --------------------------------------------------------------------- dialect
# 19c. The instrument that declined Penrod. Eye-dialect is a READING problem in
# a book and a KEYSTROKE problem in a typing program - this measures the second.
DIALECT = (r"\bLawd\w*|\bwuz\b|\bdey\b|\bdem\b|\bdat\b|\bdis\b|\bde\b|\bwif\b"
           r"|\bhaid\b|\bmo[\u2019']\b|\bain[\u2019']\b|\bgwine\b|\bgwan\b|\bclim\b"
           r"|\bnuff[\u2019']?m\b|\bcain[\u2019']t\b|\bsuh\b|\bmammy\b|\bpappy\b"
           r"|\bmassa\w*|\bmarse\b|\bchillun\w*|\btroof\b|\bheah\b|\bwheah\b"
           r"|\bchile\b|\bculled\b|\byo[\u2019']\b|\bmah\b|\bLawsy\b|\bLawdy\b")


MENTION_FLOOR = 8   # a chapter is part of the THREAD, not a passing reference


def dialect(dumpfile, names=None):
    """names: character names whose thread to measure, e.g. Herman,Verman.
    If omitted, they are guessed from the chapters with the densest dialect."""
    spine = [(f, b) for f, b in load_spine_dump(dumpfile) if 'chapter' in f.lower()]
    total_words = sum(len(re.findall(r"[A-Za-z\u2019']+", b)) for _, b in spine)
    rows = []
    for f, b in spine:
        w = len(re.findall(r"[A-Za-z\u2019']+", b))
        d = len(re.findall(DIALECT, b, re.I))
        nm = {n: len(re.findall(r'\b' + n + r'\b', b)) for n in (names or [])}
        rows.append((f, w, d, nm))
    print(f'  {"file":18s} {"words":>6s} {"dialect":>8s} {"/1000":>7s}'
          + ''.join(f' {n:>8s}' for n in (names or [])))
    thread_w = thread_m = 0
    for f, w, d, nm in rows:
        if d or any(nm.values()):
            print(f'  {f:18s} {w:6d} {d:8d} {d / max(1, w) * 1000:7.1f}'
                  + ''.join(f' {nm[n]:8d}' for n in (names or [])))
        if any(nm.values()):
            thread_w += w
            thread_m += sum(nm.values())
    tot_d = sum(d for _, _, d, _ in rows)
    # ⚠️ TWO thread figures, and the difference is not cosmetic. "Chapters
    # with ANY mention" sweeps in chapters where a character is named once in
    # passing; "SUBSTANTIAL" (>= MENTION_FLOOR) is the thread a student actually
    # spends time in. Batch 19 described "six substantial chapters" in prose and
    # then published a percentage computed from neither definition. Report both,
    # label both, and let the ruling cite one.
    sub = [(f, w, m) for f, w, d, nm in rows
           for m in [sum(nm.values())] if m >= MENTION_FLOOR]
    sub_w, sub_m = sum(w for _, w, _ in sub), sum(m for _, _, m in sub)
    print(f'\n  book words (chapters only) : {total_words}')
    print(f'  dialect tokens             : {tot_d}'
          f'  ({tot_d / max(1, total_words) * 1000:.1f} per 1,000)')
    if names:
        print(f'  named-thread mentions      : {thread_m}')
        print(f'  any-mention chapters       : {thread_w} words '
              f'({thread_w / max(1, total_words) * 100:.1f}% of book)')
        print(f'  SUBSTANTIAL (>={MENTION_FLOOR} mentions) : {sub_w} words '
              f'({sub_w / max(1, total_words) * 100:.1f}% of book) in {len(sub)} chapters')
    print(f'\n  reference point: Penrod DECLINED at 169 mentions, 6 substantial')
    print(f'                  chapters, 14,887 words = 25.6% of the book (19c)')
    return dict(words=total_words, dialect=tot_d, thread_mentions=thread_m,
                thread_words=thread_w, sub_words=sub_w, sub_chapters=len(sub))


# ----------------------------------------------------------------------- spine
# 14e / 19d. ⚠️ Jake CLOSED the PG-licence question: admin.js handles copyright
# pages, so a big uncopyright.xhtml is not a defect. This mode stays because the
# general check is still worth having - "it is in the spine" is not the same as
# "a student types it", and admin.js sits between the two. Report, do not judge.
def spine(root):
    opf = find_opf(root)
    base = os.path.dirname(opf)
    raw = open(opf, encoding='utf-8').read()
    man = _manifest_map(opf)          # ⚠️ batch 25, see _manifest_map
    refs = re.findall(r'<itemref[^>]*idref="([^"]+)"', raw)
    order = [man.get(i, '?') for i in refs]
    tot, unresolved = 0, 0
    print(f'  {len(order)} spine items')
    for h in order:
        if h == '?':
            unresolved += 1
            print(f'   {"?":26s}     ?? UNRESOLVED idref')
            continue
        p = os.path.join(base, h)
        w = len(strip(open(p, encoding='utf-8').read()).split()) if os.path.exists(p) else 0
        tot += w
        flag = ''
        if re.search(r'uncopyright|colophon|imprint|license|advert', h, re.I):
            flag = '   <- front/back matter'
        print(f'   {h:26s} {w:6d} words{flag}')
    print(f'\n  total spine words: {tot}')
    # ⚠️ BATCH 25: the old version printed `?` and 0 words per item and then a
    # total of 0, which reads like a finding about the book. It was a finding
    # about the parser. Make it impossible to mistake one for the other.
    if unresolved:
        raise SystemExit(f'\n  *** {unresolved}/{len(order)} spine idrefs did not '
                         f'resolve against the manifest. The word counts above are '
                         f'MEANINGLESS. Fix the parser, do not report the number. ***')
    print(f'  note: admin.js handles copyright pages on import (19d, CLOSED)')
    return tot


# -------------------------------------------------------------------- selftest
CITED = {
    # ⚠️ HANDOFF 17f published 18.7. The canonical figure is 18.5. The
    # difference is the PATTERN LIST, not the book: the batch-17 ad-hoc list
    # included /thereafter/, which is not archaic. A density number means
    # nothing without the list that produced it - which is exactly why the list
    # now lives in a versioned file instead of a heredoc.
    # ══════════════════════════════════════════════════════════════════════
    # ⚠️ BATCH 25: EVERY ARCHAIC-DENSITY FIGURE BELOW IS WITHDRAWN.
    #
    # The `an` pattern was matching the INDEFINITE ARTICLE (see ARCHAIC). It
    # contributed roughly 2 tokens per 1,000 words to every book ever measured,
    # because that is simply how often English prose says `an`. Two smaller
    # patterns (`art`, `marry`) fired on the modern noun and verb.
    #
    # This is the SAME SHAPE as batch 24's heading-weld withdrawal, and the
    # lesson is the same one twice: a density number means nothing without the
    # list that produced it, and the list had never been read line by line
    # against a book's top-forms table. The `an` bug was visible in every single
    # register run this project has done - `\ban\b(?= [a-z]+ [a-z])` sat at the
    # TOP of the top-forms table with the largest count on the page - and nobody
    # looked at it, because the total at the top of the report was plausible.
    #
    # ⚠️ WHAT THIS MEANS FOR THE STAGING DECISIONS ALREADY TAKEN: nothing.
    # The inflation was near-constant, so the ORDERING is intact and no shipped
    # or declined book was staged wrongly. But the corpus's apparent
    # 1.0-2.5/1,000 "easy floor" WAS THE ARTICLE, not archaism, and must not be
    # quoted again. The Wood (declined at 32.4) is really ~30; The Black Arrow
    # (shipped at 18.5) is really ~16.5. Both re-measurable only with the books,
    # which are not on this machine - hence withdrawn rather than corrected.
    #
    # WITHDRAWN, batch 25 (article inflation). Old values kept for the record:
    #   '17f Black Arrow density'  18.5      '22 Ranch density'      2.2
    #   '17f Barry Locke density'   2.0      '22 Big Horn density'   1.6
    #   '23 Jekyll density'         2.5      '23 North Wind density' 1.0
    #   '24 Ozma density'           1.5      '24 Wood density'      32.4
    #   '24 Goblin density'         1.2
    #
    # Mean-sentence figures are UNAFFECTED by this bug and stand.
    # ══════════════════════════════════════════════════════════════════════
    '24 Ozma sentence':         ('sentence', 'ozma', 17.6, 0.15),
    '24 Wood sentence':         ('sentence', 'wood', 30.1, 0.15),
    '24 Goblin sentence':       ('sentence', 'goblin', 17.0, 0.15),
    # ⚠️ BATCH 25 - the FIRST trustworthy archaic-density figures in the
    # project, and the first two rows measured on books that are on this
    # machine. Both are re-derivable by anyone holding this tarball.
    # Phantom is the new floor and it is an order of magnitude below the old
    # bogus floor: 19 real archaic tokens in 84,417 words.
    '25 Phantom density':       ('register', 'phantom', 0.2, 0.30),
    '25 Phantom sentence':      ('sentence', 'phantom', 16.0, 0.15),
    '25 Captains density':      ('register', 'cc', 2.4, 0.15),
    '25 Captains sentence':     ('sentence', 'cc', 15.0, 0.15),
    '19c Penrod thread pct':    ('threadpct', 'penrod', 25.6, 0.3),
    # ⚠️ BATCH 26. The batch-22 pattern applied again, and it is the ONLY reason
    # this selftest ran at all: every batch-17-to-25 reference book is absent
    # from this machine, so all 8 prior cases SKIP and `pack.sh` correctly
    # REFUSED to build until current-batch rows were added. ⚠️ THE STANDING
    # PROBLEM IS UNSOLVED, NOT SOLVED: these three will be absent for the NEXT
    # instance too, and it will hit the same refusal. **Every batch must add its
    # own rows here.** All three measured on the PRISTINE dumps (pre-edit), which
    # is what a staging figure means. Trustworthy under measure.py 1.1.0.
    '26 Tom Swift density':     ('register', 'ts', 0.0, 0.30),
    '26 Tom Swift sentence':    ('sentence', 'ts', 13.5, 0.15),
    '26 Ruth Fielding density': ('register', 'rf', 2.1, 0.20),
    '26 Ruth Fielding sentence':('sentence', 'rf', 15.4, 0.15),
    '26 Box-Car sentence':      ('sentence', 'bc', 13.5, 0.15),
}


def selftest():
    """⚠️ Rule 10: prove it on the real books the numbers were taken from."""
    import subprocess
    books = {'ba': ('../batch17/ba', '../batch17/ba.txt'),
             'hb': ('../batch17/hb', '../batch17/hb.txt'),
             'penrod': ('../b19/penrod', '../b19/penrod.txt'),
             # current-batch books: present by definition, so these cases
             # actually RUN rather than SKIP. See the CITED comment.
             'ranch': ('RANCH', 'ranch.txt'),
             'bighorn': ('BIGHORN', 'bighorn.txt'),
             'jekyll': ('JEKYLL', 'jekyll.txt'),
             'northwind': ('NORTHWIND', 'northwind.txt'),
             'ozma': ('OZMA', 'ozma.txt'),
             'wood': ('WOOD', 'wood.txt'),
             'goblin': ('GOBLIN', 'goblin.txt'),
             # batch 25 - present by definition, so these cases RUN.
             'phantom': ('phantom', 'phantom.txt'),
             'cc': ('cc', 'cc.txt'),
             # batch 26 - present by definition, so these cases RUN.
             'ts': ('PRISTINE/TS', 'TS.txt'),
             'rf': ('PRISTINE/RF', 'RF.txt'),
             'bc': ('PRISTINE/BC', 'BC.txt')}
    here = os.path.dirname(os.path.abspath(__file__))
    ok = True
    ran = 0
    for key, (which, book, want, tol) in CITED.items():
        root, dmp = books[book]
        root = os.path.normpath(os.path.join(here, root))
        dmp = os.path.normpath(os.path.join(here, dmp))
        if not os.path.exists(dmp):
            print(f'  SKIP {key}: {dmp} absent')
            continue
        ran += 1
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            if which in ('register', 'sentence'):
                r = register(dmp)
                got = r['density'] if which == 'register' else r['mean_sentence']
            else:
                r = dialect(dmp, ['Herman', 'Verman'])
                got = r['sub_words'] / r['words'] * 100
        good = abs(got - want) <= tol
        ok = ok and good
        print(f'  {"OK  " if good else "FAIL"} {key:28s} cited {want}  got {got:.1f}')
    # ⚠️ BATCH 20: a selftest where every case SKIPped used to return SUCCESS.
    # That is worse than no selftest - pack.sh printed "3/3 pass" on a machine
    # with no reference books. An all-SKIP run proves nothing and must FAIL.
    if ran == 0:
        print('\n*** SELFTEST FAILED: 0 of '
              f'{len(CITED)} cases ran - reference books absent. ***')
        print('    Unpack one book per staging decision at ../batch17/, ../b19/,')
        print('    or add the CURRENT batch\'s two register rows to CITED (batch 22 pattern)')
        print('    or this check is decoration. See TOOLKIT.md.')
        return False
    print(f'\n{ran}/{len(CITED)} cases ran')
    print('SELFTEST PASS' if ok else '*** SELFTEST FAILED ***')
    return ok


if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    mode = sys.argv[1]
    if mode == 'selftest':
        sys.exit(0 if selftest() else 1)
    a = sys.argv[2:]
    if mode == 'toc':
        toc(a[0])
    elif mode == 'register':
        register(a[0])
    elif mode == 'typable':
        typable(a[0])
    elif mode == 'dialect':
        dialect(a[0], a[1].split(',') if len(a) > 1 else None)
    elif mode == 'spine':
        spine(a[0])
    elif mode == 'all':
        root, dmp = a[0], a[1]
        for name, fn, arg in (('TOC', toc, root), ('REGISTER', register, dmp),
                              ('TYPABLE', typable, root), ('DIALECT', dialect, dmp),
                              ('SPINE', spine, root)):
            print(f'\n===== {name} =====')
            fn(arg)
    else:
        raise SystemExit(__doc__)
