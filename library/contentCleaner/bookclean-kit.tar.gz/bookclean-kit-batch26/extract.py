#!/usr/bin/env python3
"""extract.py 1.0.0 - BATCH 25b. Lift admin.js's matter-classification code
VERBATIM into extracted.js for checkmatter.js to run.

⚠️ VERBATIM IS THE WHOLE POINT. See checkmatter.js's header. Re-run this after
every admin.js change; extracted.js is a snapshot and goes stale silently.
"""
import re, sys

CONSTS = ['SE_PART_CHAPTER', 'FRONT_MATTER_FILE', 'BACK_MATTER_FILE',
          'ABOUT_FILE', 'ABOUT_EPUB_TYPE']
OBJECTS = ['MATTER_FILE_NAMES']
FUNCS = ['classifyDocument', 'detectAbout', 'matterTitleFrom',
         'assignChapterIds', 'detectPart']


def brace_block(s, start):
    """Read from `start` to the matching close brace."""
    depth, j = 0, start
    while True:
        if s[j] == '{':
            depth += 1
        elif s[j] == '}':
            depth -= 1
            if depth == 0:
                return s[start:j + 1]
        j += 1


def main(path='admin.js', out='extracted.js'):
    s = open(path, encoding='utf-8').read()
    parts, missing = [], []
    for name in CONSTS:
        m = re.search(r'^const ' + name + r'\s*=.*?;$', s, re.M)
        parts.append(m.group(0)) if m else missing.append(name)
    for name in OBJECTS:
        i = s.find('const ' + name)
        if i < 0:
            missing.append(name); continue
        parts.append(s[i:s.index('};', i) + 2])
    for name in FUNCS:
        i = s.find('function ' + name + '(')
        if i < 0:
            missing.append(name); continue
        parts.append(brace_block(s, i))
    parts.append('module.exports={' + ','.join(FUNCS) + '};')
    open(out, 'w', encoding='utf-8').write('\n\n'.join(parts))
    print(f'  extracted {len(parts)-1} definitions from {path} -> {out}')
    # A missing name means admin.js was refactored and this extractor is stale.
    # Fail loudly: a partial extract would run and give a WRONG verdict, which
    # is worse than no verdict at all.
    if missing:
        raise SystemExit(f'\n  *** NOT FOUND in {path}: {", ".join(missing)}.\n'
                         f'      admin.js has been refactored. Do NOT trust a\n'
                         f'      partial extract - update extract.py first. ***')


if __name__ == '__main__':
    main(*sys.argv[1:])
