#!/usr/bin/env python3
"""Cumulative bookclean scanner.

Batch 8a: finditer + group(0), NEVER findall (grouped patterns return groups).
Batch 15a: dedupe by offset; drop any match wholly contained in a longer one.
Batch 7d: report which spine file each hit lives in (PG licence inflates scans).
"""
import re, sys, os
from collections import Counter, defaultdict

# ---------------------------------------------------------------- pattern sets
BLOCKS = {}

BLOCKS['TIER1_CORE'] = [
    r'\bn[i1]gg\w*', r'\bdark(y|ies|ey|eys)\b', r'\bcoon\w*', r'\bsambo\b',
    r'\bnegro\w*', r'\bnegress\w*', r'\bmulatto\w*', r'\bquadroon\w*', r'\boctoroon\w*',
    r'\bpickaninn\w*', r'\bwench\w*',
    r'\bchinaman\w*', r'\bchinee\b', r'\bchink\w*', r'\bjap\w*', r'\bnip\b',
    r'\bcoolie\w*', r'\bhalf[- ]?breed\w*', r'\bmongrel\w*',
    r'\bgips\w*|\bgyps\w*', r'\binjun\w*', r'\bredskin\w*', r'\bsquaw\w*',
    r'\bsavage\w*', r'\bheathen\w*', r'\bhottentot\w*', r'\bkaffir\w*',
    r'\bdago\w*', r'\bwop\b', r'\bgreaser\w*', r'\bhun\b|\bhuns\b',
    r'\byid\b|\byids\b', r'\bhebrew\w*', r'\bjew\w*', r'\bsheeny\w*',
    r'\bdutchman\b|\bdutchmen\b', r'\bpolack\w*', r'\beskimo\w*|\besquimaux?\b',
    r'\bnative\w*', r'\baborigin\w*', r'\bbrave\b|\bbraves\b',
]

BLOCKS['RELIGIOUS_ETHNIC'] = [
    r'mo(h)?ammed\w*', r'mahomet\w*', r'mo(s|z)lem\w*', r'mussulman\w*',
    r'lascar\w*', r'hindoo\w*', r'blackamoor\w*', r'red[- ]indian\w*',
    r'mu(h)?ammad\w*', r'\bharam\b|\bhareem\w*|\bharem\w*|\bseraglio\w*',
    r'\b(al)?qu?r.?an\b', r'\bbushm[ae]n\b', r'\basiatic\w*',
    r'\btzigane\w*|\bzigeuner\w*', r'\bromany\w*|\bromani\w*', r'\bszgany\w*',
    r'\boriental\w*', r'\bturk\w*', r'\bnubian\w*', r'\binfidel\w*', r'\bpagan\w*',
]

BLOCKS['SURFACE'] = [   # batch 6: etymology is not a defence
    r'\bniggardly\b|\bniggard\w*',
    r'\bfag\b|\bfags\b|\bfagged\b|\bfagging\b|\bfaggot\w*',
    r'\bqueer\w*', r'\bejaculat\w*',
    r'\bgay\w*',                 # batch 15a: dedupe handles the gayly overlap
    r'\bgai(ly|ety|eties)\b',    # en-GB forms; Jake rules these STAY, but surface them
]

BLOCKS['NAMED_PEOPLES'] = [   # batch 13
    r'\bcomanche\w*|\bapache\w*|\bsioux\b|\bcherokee\w*|\bmohawk\w*',
    r'\bnavaj(o|oe)\w*|\bpawnee\w*|\biroquois\b|\bseminole\w*|\bshawnee\w*',
    r'\bcheyenne\w*|\bblackfo(o|e)t\w*|\bmingo\w*|\bhuron\w*|\bmohican\w*',
    r'\bzulu\w*|\bfiji\w*|\bmaori\w*|\baztec\w*|\bpygm\w*',
    r'\bcossack\w*|\bmongol\w*|\btart?ar\w*|\bbedouin\w*',
    r'\bwar[- ]?(whoop|paint|dance|cry)\w*|\bscalp\w*|\btomahawk\w*|\bwigwam\w*',
    r'\bpapoose\w*|\bpow[- ]?wow\w*|\btotem\w*|\bteepee\w*|\btepee\w*',
    r'\bindian\w*',
]

BLOCKS['ETHNONYM_IDIOM'] = [   # NEW batch 16: 'street Arab' was invisible to every block
    r'\barab\w*', r'\bstreet[- ]arab\w*', r'\bbohemian\w*', r'\bvandal\w*',
    r'\bphilistine\w*', r'\bbarbar\w*', r'\bcannibal\w*', r'\bpirate\w*',
    r'\bgoth\b|\bgoths\b|\bvisigoth\w*', r'\bwelsh(ed|ing|er)\b', r'\bgyp(ped|ping)\b',
    r'\bmoor\w*|\bsaracen\w*', r'\bafric\w*|\bchinese\b|\bjapanese\b|\bhindu\w*',
    r'\bslav\w*', r'\bdervish\w*', r'\bmandarin\w*', r'\bpygmy\b|\bpigmy\b',
]

BLOCKS['EYE_DIALECT'] = [   # batch 5; smoke detector only
    r'\bdat\b|\bdis\b|\bdem\b|\bdey\b|\bdar\b|\bden\b',
    r'\bmassa\b|\bmarse\b|\bmassah\b',
    r'\bchillun\w*|\bpickaninn\w*',
    r'\bgwine\b|\bgwan\b',
    r'\bLawd\w*|\bLawsy\b|\bLawdy\b',
    r'\bsuah\b|\btroof\b|\bheah\b|\bwheah\b|\bthah\b|\bchile\b',
    r'\bcain[’\']?t\b|\bnuffin\w*|\bwif\b|\bob\b',
    r'\bculled\b|\bcolo(u)?red\b',
    r'\bI[’\']s\b|\byo[’\']|\bmah\b|\bdah\b',
]

BLOCKS['MINSTRELSY'] = [   # batch 3
    r'minstrel\w*', r'\binterlocutor\w*', r'\bdarktown\b|\bsenegambian\b',
    r'blackface|burnt[- ]cork', r'\bplantation\w*', r'\bcakewalk\w*',
    r'\bmammy\b', r'\bend[- ]?men\b', r'\bbanjo\w*', r'\btambourine\w*',
]

BLOCKS['SEXUAL_REGISTER'] = [   # batch 3; surfaces, does not sentence
    r'voluptu\w*', r'\bwanton\w*', r'\blascivi\w*', r'\bsensual\w*',
    # BATCH 25: `lust\w*` was UNBOUNDED and fired inside illustrious,
    # illustrated, blustering, clustered. In The Prince and the Pauper that
    # was 11 of 15 SEXUAL_REGISTER hits - the block was 73% noise, and every
    # one had to be read to be dismissed. THIS IS THE EXACT BUG 15a FIXED FOR
    # `cock` ("\b ADDED - was firing in weathercock/peacock") and it sat two
    # lines away for ten batches. When a fix is applied to one token in a
    # list, CHECK THE WHOLE LIST for the same shape.
    r'\bcarnal\w*', r'\blust\w*', r'\bravish\w*', r'\blanguorous\w*',
    r'\bpanting\b|\bheaving\b',
]

# ══════════════════════════════════════════════════════════════════════════════
# ⚠️ BATCH 25 - §16a IS CLOSED. Open since batch 16, described in TOOLKIT.md as
# "the highest-value short job in the project", and untouched for nine batches.
#
# The complaint was that this file ships hard-bounded literals like
# r'\bpecker\b', which violate THE REGEX RULE and cannot match `peckers`.
#
# ⚠️ THE REASON NOBODY FIXED IT IS THAT THE OBVIOUS FIX IS WRONG. THE REGEX RULE
# SAYS `\w*`, AND `\bass\w*` MATCHES assistant, assume, assembly, assassin - on
# any novel that is hundreds of hits, which is the 23a cry-wolf failure at a
# scale that would make the whole ANATOMY block unreadable. The rule was written
# for stems like `gay`/`cock` where the inflections are few and the noise is
# glanceable. It does not generalise to short words that are also prefixes of
# common ones, and this file has been quietly right to resist it.
#
# So: PLURALS, not `\w*`. `plural()` adds exactly the English noun plural forms
# and nothing else, which is the entire gap §16a actually named. `assistant` is
# still not matched; `peckers` now is.
#
# ⚠️ DELIBERATELY NOT PLURALISED, and each for a reason:
#   dialect function words (dat, dem, dey, dis, den, ob, wif, mah, dah, dar,
#     heah, wheah, thah, suah, troof, gwine, gwan, chile, culled, marse, massa)
#       - not nouns; a plural form does not exist
#   ass, balls, crack, nip, den, hell
#       - already listed with their plural, or the plural sense is a different
#         word whose false-positive rate is worse than the miss
#   iroquois, sioux, chinese, japanese
#       - invariant in English; `sioux(?:es)?` proposes a form nobody wrote
#   adjectives: brave (has `braves`), deformed, insane, lame, shiftless,
#     thriftless, officious, lymphatic, niggardly, panting, heaving, fagged,
#     fagging
#       - the noun-plural transform is meaningless on them
#   mass nouns: laudanum, morphine, morphia, haram
#
# Harness: `python3 scan.py --selftest`. It asserts BOTH directions - the plural
# now matches AND the prefix-collision word still does not - because a fix that
# only proves the first half is how `\bass\w*` gets shipped by a future
# instance reading THE REGEX RULE and not this comment.
PLURALISE = ('pecker', 'fanny', 'wop', 'sambo', 'pygmy', 'pigmy', 'hussy',
             'madhouse', 'dummy', 'chinee', 'mammy', 'suicide', 'senegambian',
             'shanty', 'goth', 'hun', 'yid', 'booby', 'darktown', 'dutchman')


def plural(word):
    r"""r'\bword\b' -> r'\bword(?:...)?\b' covering only real English plurals."""
    w = word
    if w.endswith('y') and len(w) > 2 and w[-2] not in 'aeiou':
        alt = w[:-1] + 'ies'
    elif w.endswith('man'):
        alt = w[:-3] + 'men'
    elif w.endswith('o'):
        # ⚠️ -o is genuinely irregular in English (potatoes but pianos), and the
        # harness caught this: `sambo` was pluralised to `samboes` ONLY, so
        # `sambos` - the form actually attested in period text - still missed.
        # Emit both rather than guessing which one an 1890s author used.
        alt = [w + 's', w + 'es']
    elif w.endswith(('s', 'sh', 'ch', 'x', 'z')):
        alt = [w + 'es']
    else:
        alt = [w + 's']
    if isinstance(alt, str):
        alt = [alt]
    return r'\b(?:' + '|'.join(re.escape(a) for a in [w] + alt) + r')\b'


def _restem(pats):
    """Rewrite any \\bX\\b in a pattern list where X is in PLURALISE."""
    out = []
    for p in pats:
        for w in PLURALISE:
            p = p.replace(r'\b' + w + r'\b', plural(w))
        out.append(p)
    return out


BLOCKS['ANATOMY'] = [
    r'\bboob\w*', r'\bbooby\b|\bboobies\b', r'\btits?\b|titty|titties',
    r'\bbosom\w*', r'\bnipple\w*',
    r'\bcock\w*',            # batch 15a: \b ADDED - was firing in weathercock/peacock
    r'\bpecker\b', r'\bfanny\b', r'\barse\w*',
    r'\bass\b|\basses\b|jackass\w*', r'\bballs\b', r'\bcrack\b',
    r'\berect\w*', r'\bmembers?\b', r'\bloins?\b',
    r'\bharlot\w*|\bstrumpet\w*|\bhussy\b',
    r'\bconcubine\w*', r'\bmistress\w*', r'\bbastard\w*',
    r'\bseduc\w*|\bdeflower\w*', r'\bnaked\w*|\bundress\w*',
]

BLOCKS['DISABILITY'] = [   # batch 14b: defining label vs adjective-in-passing
    r'\bidiot\w*', r'\blunatic\w*', r'\bimbecile\w*', r'\bcripple\w*',
    r'\bfeeble[- ]?minded\b', r'\bhalf[- ]?witted\b|\bhalf[- ]?wit\b',
    r'\bweak[- ]?minded\b', r'\bsimpleton\w*', r'\bmoron\w*', r'\bdeaf[- ]?mute\w*',
    r'\bdumb\b|\bdummy\b', r'\blame\b|\blameness\b', r'\bhunchback\w*|\bdeformed\b',
    r'\bmadhouse\b|\basylum\w*|\binsane\b|\bmaniac\w*',
]

BLOCKS['CLASS_CONTEMPT'] = [   # batch 14g
    r'\bdegree of intelligence\b|\bof (that|this) class\b|\bbetter class\b|\blower class\b',
    r'\bcommon people\b|\bsuch people\b|\bthese people\b|\bpeople of (that|this|his|her) sort\b',
    r'\bhovel\w*|\btenement\w*|\bshanty\b|\bshanties\b|\bshacks?\b',
    r'\bidle (children|women|men|poor)\b|\bofficious\b|\bshiftless\b|\bthriftless\b|\bslip-?shod\b',
    r'\bill-?looking\b|\bworse dressed\b|\bdreadful looking\b|\bcoarse (face|features)\b',
    r'\blymphatic\b|\bthe likes of\b|\bbetters\b|\bvulgar\w*',
    r'\btramp\w*|\bbeggar\w*|\bgutter[- ]?snipe\w*|\bragamuffin\w*',
]

BLOCKS['VIOLENCE_SUBSTANCE'] = [
    r'\bsuicide\b|\bself-slaughter\b|\bmade away with h',
    r'\bhang(ed|ing)? h(im|er)self',
    r'\bopium\w*|\blaudanum\b|\bmorphia\b|\bmorphine\b',
    r'\bdamn\w*|\bhell\b|\bdevil\w*', r'\bdrunk\w*|\bwhisk(e)?y\b|\bliquor\w*',
]

# ------------------------------------------------------------------- machinery
def load_spine(dumpfile):
    """Return list of (filename, text) from a dump.py output."""
    text = open(dumpfile, encoding='utf-8').read()
    parts = re.split(r'\n\n===== FILE: (.+?) =====\n', text)
    out = []
    # parts[0] is preamble (usually empty); then name, body, name, body...
    for i in range(1, len(parts), 2):
        out.append((parts[i], parts[i + 1]))
    return out

def dedupe(matches):
    """batch 15a: keep the longest match at each start; drop spans fully covered."""
    by_start = {}
    for m in matches:
        s = m.start()
        if s not in by_start or len(m.group(0)) > len(by_start[s].group(0)):
            by_start[s] = m
    kept = sorted(by_start.values(), key=lambda m: (m.start(), -len(m.group(0))))
    out = []
    for m in kept:
        covered = any(o.start() <= m.start() and m.end() <= o.end() and o is not m
                      for o in out)
        if not covered:
            out.append(m)
    return out

def scan_book(dumpfile, blocks=None, show_context=False, width=100):
    spine = load_spine(dumpfile)
    blocks = blocks or BLOCKS
    results = defaultdict(lambda: defaultdict(list))  # block -> form -> [(file, pos)]
    for fname, body in spine:
        for bname, pats in blocks.items():
            ms = []
            for p in pats:
                ms.extend(re.finditer(p, body, re.I))
            for m in dedupe(ms):
                results[bname][m.group(0).lower()].append((fname, m.start()))
    return results, spine

# ⚠️ BATCH 25: applied to EVERY block, not just ANATOMY. The bounded literals
# are spread across MINSTRELSY, TIER1_CORE, EYE_DIALECT and DISABILITY too, and
# fixing only the block named in the §16a write-up would have left the same bug
# in four other places - which is exactly how `/\bpecker\b/` survived fifteen
# batches inside a file whose header documents the rule it breaks.
for _b in BLOCKS:
    BLOCKS[_b] = _restem(BLOCKS[_b])


def selftest():
    """⚠️ Both directions. See the PLURALISE comment."""
    MUST_MATCH = ['peckers', 'wops', 'pygmies', 'hussies', 'mammies',
                  'suicides', 'madhouses', 'dummies', 'sambos', 'fannies',
                  'goths', 'huns', 'yids', 'shanties', 'dutchmen', 'boobies']
    # ⚠️ `cocktail` BELONGS IN MUST_MATCH, and the first version of this harness
    # had it in MUST_NOT. That was my error and it is worth leaving recorded,
    # because it is the precise regression THE HANDOFF PREDICTS: 11b took
    # `cocked`/`cocking` off the always-fix list "and `cocktail` with it", and a
    # skim of that line reads as "the scanner should not see cocktail". It
    # should. 23c overruled 11b on exactly this point - THE STANDARD IS THE
    # ROOM, NOT THE ETYMOLOGY, because a 13-year-old types it one letter at a
    # time - and in any case SCANNING is not RULING. The scan surfaces; Jake
    # decides at review. A harness that asserts a scanner must be BLIND to a
    # token is asserting a ruling, which is not this file's job.
    MUST_MATCH += ['cocktail']
    MUST_NOT   = ['assistant', 'assume', 'assassin', 'assembly',
                  'peacock', 'passistant', 'hunger', 'hungry', 'gothic',
                  'suicidal', 'dummied']
    every = [p for pats in BLOCKS.values() for p in pats]
    ok = True
    for w in MUST_MATCH:
        hit = any(re.search(p, w, re.I) for p in every)
        if not hit:
            ok = False
        print(f'  {"OK  " if hit else "FAIL"} matches   {w}')
    for w in MUST_NOT:
        hit = [p for p in every if re.search(p, w, re.I)]
        if hit:
            ok = False
        print(f'  {"OK  " if not hit else "FAIL"} no match  {w}'
              + (f'   <- caught by {hit}' if hit else ''))
    print(f'\n{len(MUST_MATCH) + len(MUST_NOT)} cases ran')
    print('SELFTEST PASS' if ok else '*** SELFTEST FAILED ***')
    return ok


def report(dumpfile, blocks=None):
    results, spine = scan_book(dumpfile, blocks)
    total = 0
    for bname in (blocks or BLOCKS):
        forms = results.get(bname, {})
        n = sum(len(v) for v in forms.values())
        total += n
        if not n:
            print(f'\n## {bname}: 0')
            continue
        print(f'\n## {bname}: {n} tokens, {len(forms)} distinct forms')
        c = Counter({k: len(v) for k, v in forms.items()})
        for form, cnt in c.most_common():
            files = Counter(f for f, _ in forms[form])
            fs = ', '.join(f'{f.replace(".xhtml","")}×{c2}' for f, c2 in files.most_common(6))
            print(f'   {form:28s} {cnt:4d}   [{fs}]')
    print(f'\nTOTAL (deduped): {total}')

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        sys.exit(0 if selftest() else 1)
    report(sys.argv[1])
