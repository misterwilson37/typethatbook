#!/usr/bin/env python3
"""rawcheck.py 1.0.0 - cross-check the RAW XHTML against what the dump shows.

Ran unshipped through batches 17, 18 and 19. Written to disk in batch 20.

⚠️ WHY THIS IS A SEPARATE TOOL FROM scan.py: `scan.py` reads `dump.py` output,
which is tag-stripped. Anything living in an attribute is invisible to it -
which is how batch 16 nearly shipped `Cock Robin` in five `alt` attributes while
the body text read clean (16d). And `stemaudit.py` audits the PATTERN LIST;
this audits the PATH. Different failure, different tool.

It also answers the question that opens every session on a re-processed file:
WHAT DID THE PREVIOUS PASS ALREADY DO? Batch 17's whole first third was spent
fingerprinting a merged pass by hand. `--fingerprint` does it in one command.

USAGE
  python3 rawcheck.py BOOK/                     # always-fix tokens, raw source
  python3 rawcheck.py BOOK/ --attrs             # ONLY attribute text (16d)
  python3 rawcheck.py BOOK/ --fingerprint       # traces of a previous pass
  python3 rawcheck.py BOOK/ --diff book.txt     # raw counts vs dump counts
"""
import re, sys, os, glob, html

VERSION = '1.0.0'

# the standing always-fix list, as literal stems. Deliberately NOT imported from
# scan.py: the point is to check the book with a second, independent instrument.
ALWAYS_FIX = [
    'nigg', 'coon', 'darky', 'darkies', 'sambo', 'negro', 'negress', 'mulatto',
    'quadroon', 'octoroon', 'pickaninn', 'wench', 'chinaman', 'chinee', 'chink',
    'jap', 'coolie', 'half-breed', 'gips', 'gyps', 'injun', 'redskin', 'squaw',
    'savage', 'heathen', 'hottentot', 'kaffir', 'dago', 'wop', 'greaser',
    'sheeny', 'polack', 'red indian', 'street arab', 'blackamoor',
    'gay', 'gayly', 'gayest', 'gayety', 'ejaculat', 'intercourse', 'damn',
    'cock', 'ass', 'pecker', 'faggot', 'mammy', 'oriental', 'niggard',
]
# ⚠️ 18h: absent from every scan.py block, all fired in batch 18-19
STILL_ABSENT = [
    'black girl', 'black boy', 'black child', 'black man', 'black woman',
    'copper-coloured', 'copper-colored', 'dusky', 'swarthy', 'woolly',
    'dwarf', 'crookback', 'leper', 'lepros', 'breast',
    'mahoun', 'mahound', 'termagant', 'paynim',
]
# strings that mean a PREVIOUS pass already edited this file
FINGERPRINTS = {
    'rooster':      'cock -> rooster (batch 3/11 swap)',
    'chump':        'ass -> chump (Barbour register, CALIBRATION)',
    'Robin Redbreast': 'Cock Robin -> Robin Redbreast (batch 16)',
    'kidnappers':   'gipsies -> kidnappers (batch 16, Magic City)',
    'Native American': 'Red Indians -> Native Americans (batch 16)',
    'porcelain-men': 'china-men -> porcelain-men (batch 16)',
    'chimney-sweeps': 'little Arabs -> little chimney-sweeps (batch 16)',
    'Classroom edition.': 'a classroom note is already present',
    'CC0 1.0 Universal': 'the CC0 dedication is already present',
}


def term_pattern(t):
    """⚠️ BATCH 20 BUG: the first draft did
           t.replace(' ', r'[\\s-]+').replace('-', r'[- ]')
       and the SECOND replace ate the hyphen inside the FIRST one's character
       class, producing `[\\s[- ]]+` and a regex compile error. Chained
       .replace() on regex source is a trap: each call sees the previous call's
       metacharacters. Tokenise once instead."""
    parts = re.split(r'[\s-]+', t.strip())
    return r'\b' + r'[\s-]+'.join(re.escape(p) for p in parts) + r'\w*'


def files(root):
    for pat in ('OEBPS/*.xhtml', 'epub/text/*.xhtml', 'epub/*.xhtml'):
        hit = sorted(glob.glob(os.path.join(root, pat)))
        if hit:
            return hit
    return sorted(glob.glob(os.path.join(root, '**', '*.xhtml'), recursive=True))


def counts(root, terms, attrs_only=False):
    tot, forms, where = {}, {}, {}
    for f in files(root):
        raw = open(f, encoding='utf-8').read()
        if attrs_only:
            raw = ' '.join(re.findall(r'(?:alt|title|aria-label|content)="([^"]*)"', raw))
        raw = html.unescape(raw)
        for t in terms:
            pat = term_pattern(t)
            ms = re.findall(pat, raw, re.I)
            if ms:
                tot[t] = tot.get(t, 0) + len(ms)
                forms.setdefault(t, set()).update(m.lower() for m in ms)
                where.setdefault(t, set()).add(os.path.basename(f))
    return tot, forms, where


def report(root, terms, label, attrs_only=False):
    tot, forms, where = counts(root, terms, attrs_only)
    print(f'\n########## {root} - {label} ##########')
    if not tot:
        print('  no hits')
        return tot
    for t in terms:
        if t in tot:
            fs = ', '.join(sorted(forms[t]))[:80]
            wh = ', '.join(sorted(where[t]))[:60]
            print(f'  {t:18s} {tot[t]:4d}  forms: {fs:40s} [{wh}]')
    return tot


def fingerprint(root):
    print(f'\n########## {root} - PREVIOUS-PASS FINGERPRINTS ##########')
    found = False
    for f in files(root):
        raw = open(f, encoding='utf-8').read()
        for s, meaning in FINGERPRINTS.items():
            n = raw.count(s)
            if n:
                found = True
                print(f'  {os.path.basename(f):24s} {s!r} x{n}  -> {meaning}')
    if not found:
        print('  none - this looks like a first content pass')
    else:
        print('\n  \u26a0\ufe0f A LOW SCAN COUNT ON A PREVIOUSLY-PROCESSED FILE IS EVIDENCE')
        print('     ABOUT THE PREVIOUS PASS, NOT ABOUT THE BOOK (17a).')
    return found


def diff_dump(root, dumpfile):
    """Raw-XHTML counts vs dump counts. A gap means the dump is hiding something
    (attributes, or a spine file dump.py could not resolve)."""
    from measure import load_spine_dump
    dtxt = html.unescape(''.join(b for _, b in load_spine_dump(dumpfile)))
    rtot, _, _ = counts(root, ALWAYS_FIX + STILL_ABSENT)
    print(f'\n########## {root} - RAW vs DUMP ##########')
    gaps = 0
    for t, n in sorted(rtot.items()):
        pat = term_pattern(t)
        d = len(re.findall(pat, dtxt, re.I))
        if d != n:
            gaps += 1
            print(f'  *** {t:18s} raw {n:4d}  dump {d:4d}  '
                  f'(delta {n - d:+d}) - CHECK ATTRIBUTES / SPINE')
    print(f'  {len(rtot)} terms compared, {gaps} discrepanc{"y" if gaps == 1 else "ies"}')
    return gaps


if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    root = sys.argv[1]
    flags = sys.argv[2:]
    if '--fingerprint' in flags:
        fingerprint(root)
    elif '--attrs' in flags:
        report(root, ALWAYS_FIX + STILL_ABSENT, 'ATTRIBUTE TEXT ONLY (16d)', True)
    elif '--diff' in flags:
        diff_dump(root, flags[flags.index('--diff') + 1])
    else:
        report(root, ALWAYS_FIX, 'ALWAYS-FIX TOKENS, RAW XHTML')
        report(root, STILL_ABSENT, 'STEMS ABSENT FROM scan.py (18h)')
        fingerprint(root)
