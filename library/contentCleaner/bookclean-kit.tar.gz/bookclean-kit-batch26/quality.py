#!/usr/bin/env python3
"""quality.py 1.2.0 - conversion-damage sweep. Formatting defects, not language.

⚠️ 1.2.0 ADDS THE INTRA-PARAGRAPH WELD CHECK (batch 22). `weld-no-space` only
ever matched at a </p><p> BOUNDARY, so a line-break weld INSIDE a paragraph was
structurally invisible. Ranch Girls ch. 11 reads "She paused fora long moment"
and 1.1.0 returned "DEFECTS: none". Three more sat in Big Horn (`chairand`,
`agray`, `greenfoot`).

The new check is `weld-in-para`, and it cannot be a pattern: a weld is only
recognisable against the book's own vocabulary. It flags any token appearing
ONCE in the corpus that splits into two tokens each appearing at least three
times. That produces compound-word noise (`storehouse` -> store+house), so
compounds are suppressed by requiring the whole token to be otherwise unattested
AND at least one fragment to be a function word or the split to be reported as
INFO rather than DEFECT. Real welds land in DEFECT; compounds land in INFO.

Ran unshipped through batches 17, 18 and 19. Written to disk in batch 20.

⚠️ 1.1.0 FIXES THREE FALSE POSITIVES I DISMISSED BY HAND IN EVERY BATCH.
A check that cries wolf three rounds running trains you to skim it, which is
worse than not having it:

  1. /\\.\\.(?!\\.)/ matched the LAST TWO DOTS of every legitimate three-dot
     ellipsis. Every "double-dot" hit in batches 17-19 was a real ellipsis.
     Fixed: match runs of exactly 2 dots bounded by non-dots, and separately
     report 4-dot (ellipsis+period) as INFO, since that is period-correct.
  2. /[,;]{2,}/ matched across the entity `&#x27;,` - an apostrophe followed by
     a comma. Every hit in Penrod and Grace was this. Fixed: unescape entities
     before punctuation checks.
  3. `mojibake` matched the curly quotes themselves, so it reported 3,339 hits
     on a clean book. Fixed: look for actual UTF-8-read-as-Latin-1 sequences,
     not for any non-ASCII character.

⚠️ `ALLCAPS-run` and `lone-cap-start` and `pg-boilerplate` are INFO, not
defects. Tarkington sets emphasis in caps on purpose; PG boilerplate in the
spine is handled by admin.js (19d, closed). They are reported separately so a
real defect cannot hide in a wall of expected noise.

USAGE
  python3 quality.py BOOK/ [BOOK2/ ...]      # unpacked EPUB roots
  python3 quality.py --selftest              # prove the fixes on real books
"""
import re, sys, os, glob, html
from collections import Counter

# ⚠️ BATCH 25: BUMPED 1.2.0 -> 1.3.0. The batch-23 inline/block `plaintext()`
# fix WAS present and working in the batch-24 tarball, but this constant was
# never bumped, while TOOLKIT.md's tool table said `1.3.0` and the OPEN/NEXT
# list said "quality.py must be >=1.3.0 or a Standard Ebooks source throws
# hundreds of phantom spacing defects". So the kit told the next instance to
# check a version number, and the number it would read said the fix was absent.
# The likely outcome is someone re-deriving a fix that already exists, or worse,
# distrusting a clean report. A version string is an assertion; keep it true.
VERSION = '1.3.0'

# real defects - these should be zero
DEFECTS = {
    'mojibake':          r'[\u00c3\u00c2][\u0080-\u00bf]|\ufffd|\u00e2\u0080[\u0099\u009c\u009d\u0093\u0094]',
    'stray-entity':      r'&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9a-fA-F]+;)\w+;',
    'empty-para':        r'<p>\s*</p>',
    'tiny-para':         r'<p>[^<]{0,2}</p>',
    'dropcap-split':     r'<p>\s*<span[^>]*>[A-Z]</span>\s*[a-z]',
    'unclosed-em':       r'<em>[^<]{400,}',
    'double-space':      r'\w  +\w',
    'space-before-punc': r'\w\s+[,;:!?](?=\s|<)',
    'weld-no-space':     r'(?<![.!?\u201d\u2019])</p>\s*<p>[a-z]',
    'hyphen-break':      r'\w-\s*\n\s*[a-z]',
    'double-comma':      r'(?<![.\d])[,;]{2,}(?![.\d])',
    'exact-two-dots':    r'(?<![.\u2026])\.\.(?![.\u2026])',
    'page-debris':       r'\[\s*Pg\.?\s*\d+\s*\]|\{\d+\}|<p>\s*\d{1,3}\s*</p>',
    'illustration-tag':  r'(?i)\[illustration',
}
# ⚠️ 1.2.0 - function words. A once-only token that splits with one of these on
# either side is a line-break weld, not a compound: English does not form
# compounds on 'a', 'for', 'and', 'of'. This is what separates `fora` (a weld)
# from `storehouse` (a compound).
WELD_FUNCTION = {
    'a', 'an', 'and', 'the', 'of', 'to', 'for', 'in', 'on', 'at', 'is', 'it',
    'as', 'be', 'by', 'or', 'no', 'so', 'up', 'he', 'she', 'his', 'her', 'was',
    'had', 'that', 'this', 'with', 'from', 'not', 'but',
}
# expected noise - report, never treat as failure
INFO = {
    'four-dot-ellipsis': r'\.\.\.\.',
    'spaced-ellipsis':   r'\.\s\.\s\.',
    'ALLCAPS-run':       r'\b[A-Z]{5,}\b',
    'pg-boilerplate':    r'(?i)project gutenberg|gutenberg-tm',
    'nbsp':              r'&#160;|&nbsp;|\xa0',
}


def files(root):
    for pat in ('OEBPS/*.xhtml', 'epub/text/*.xhtml', 'epub/*.xhtml', 'OEBPS/text/*.xhtml'):
        hit = sorted(glob.glob(os.path.join(root, pat)))
        if hit:
            return hit
    return sorted(glob.glob(os.path.join(root, '**', '*.xhtml'), recursive=True))


def weld_in_para(paths):
    """⚠️ 1.2.0. The check `weld-no-space` cannot perform (batch 22).

    `weld-no-space` only matches at a </p><p> boundary, so a line-break weld
    INSIDE a paragraph is structurally invisible to it. Ranch Girls ch. 11 reads
    "She paused fora long moment" and 1.1.0 reported DEFECTS: none.

    ⚠️ THE FIRST VERSION OF THIS CHECK CRIED WOLF AND WAS THROWN AWAY.
    Splitting a once-only token into two attested fragments flags `Andrew` as
    `an|drew` and `invisible` as `in|visible` - 19 and 37 hits per book, nearly
    all of them morphological prefixes. §20d says a check that cries wolf is
    worse than no check, so the discriminator had to get better, not louder.

    THE DISCRIMINATOR THAT WORKS IS BIGRAM EVIDENCE. A real weld is two words
    that the printer set on one line; the book therefore uses that exact pair
    of words adjacently somewhere else. A morphological prefix does not:
        agray      -> "a gray"      appears elsewhere  -> WELD
        chairand   -> "chair and"   appears elsewhere  -> WELD
        greenfoot  -> "green foot"  appears elsewhere  -> WELD
        fora       -> "for a"       appears elsewhere  -> WELD
        Andrew     -> "an drew"     never appears      -> not a weld
        invisible  -> "in visible"  never appears      -> not a weld
    No dictionary needed, and the evidence comes from the book being checked.
    """
    corpus = ''
    for f in paths:
        corpus += plaintext(open(f, encoding='utf-8').read())
    words = re.findall(r'[a-z]+', corpus.lower())
    freq = Counter(words)
    bigrams = Counter(zip(words, words[1:]))
    welds, near = [], []
    for f in paths:
        plain = plaintext(open(f, encoding='utf-8').read())
        for w in sorted(set(re.findall(r'[A-Za-z]{4,}', plain))):
            lw = w.lower()
            if freq[lw] > 1:
                continue
            # ⚠️ range(1, len(lw)) - NOT len(lw)-1. The first version stopped one
            # short and therefore could not see `fora` -> `for a`, which is the
            # single defect this check was written to catch. The detector failed
            # to detect its own founding case, and only running it on the book
            # that contained the defect revealed it.
            for i in range(1, len(lw)):
                a, b = lw[:i], lw[i:]
                # a one-letter fragment is only a word if it is 'a' or 'i';
                # otherwise `stones` splits as `s tones` and the report fills
                # with garbage.
                if len(a) == 1 and a not in ('a', 'i'): continue
                if len(b) == 1 and b not in ('a', 'i'): continue
                if freq[a] >= 2 and freq[b] >= 2:
                    rec = (os.path.basename(f), w, f'{a} {b}')
                    if bigrams[(a, b)] >= 1:
                        welds.append(rec)
                    else:
                        near.append(rec)
                    break
    return welds, near


# ⚠️ BATCH 23. INLINE vs BLOCK. `re.sub(r'<[^>]+>', ' ', raw)` replaces EVERY tag
# with a space, which MANUFACTURES the exact defects `double-space` and
# `space-before-punc` look for wherever markup sits mid-sentence:
#     <abbr>Mr.</abbr>\xa0Utterson      -> "Mr.  Utterson"      (fake double-space)
#     coming, <i>pede claudo</i>, years -> "pede claudo ,"       (fake space-before-comma)
# On a Gutenberg conversion, inline markup is sparse and this rarely fired. On a
# Standard Ebooks text - which marks up abbreviations, foreign phrases and
# emphasis semantically throughout - it fired 155 times in Jekyll and 311 times
# in North Wind, and EVERY ONE WAS THE TOOL'S OWN DOING. Verified: the raw files
# contain zero literal double spaces.
#
# So tags are no longer interchangeable. Block-level tags become a newline
# (they really are a text break); inline tags become nothing at all.
BLOCK_TAGS = ('p','div','br','hr','li','ul','ol','h1','h2','h3','h4','h5','h6',
              'section','article','blockquote','tr','td','th','table','header',
              'footer','figure','figcaption','dt','dd','dl','nav','body','html')
_BLOCK_RE = re.compile(r'</?(?:' + '|'.join(BLOCK_TAGS) + r')(?:\s[^>]*)?/?>', re.I)
_ANY_TAG_RE = re.compile(r'<[^>]+>')


def plaintext(raw):
    """Rendered-text approximation. Block tags -> newline, inline tags -> ''."""
    t = _BLOCK_RE.sub('\n', raw)
    t = _ANY_TAG_RE.sub('', t)          # inline tags vanish, as they do on screen
    t = html.unescape(t)
    t = t.replace('\u00a0', ' ')        # nbsp is a space for spacing checks
    t = re.sub(r'[ \t]*\n[ \t\n]*', '\n', t)   # drop source indentation
    return t


def sweep(root, verbose=True):
    agg, ex = {}, {}
    for f in files(root):
        raw = open(f, encoding='utf-8').read()
        # ⚠️ punctuation checks run on UNESCAPED text (fix 2). Markup checks
        # must NOT - an unescaped body would invent tags.
        plain = plaintext(raw)
        for name, pat in {**DEFECTS, **INFO}.items():
            target = plain if name in ('double-comma', 'exact-two-dots',
                                       'four-dot-ellipsis', 'spaced-ellipsis',
                                       'space-before-punc', 'double-space') else raw
            ms = list(re.finditer(pat, target))
            if ms:
                agg[name] = agg.get(name, 0) + len(ms)
                ex.setdefault(name, (os.path.basename(f),
                                     target[max(0, ms[0].start() - 45):ms[0].end() + 45]))
    welds, near = weld_in_para(files(root))
    bad = {k: v for k, v in agg.items() if k in DEFECTS}
    if verbose:
        print(f'\n########## {root} ##########')
        print('  -- DEFECTS --' + ('  none' if not bad else ''))
        for k in DEFECTS:
            if k in agg:
                print(f'    {k:20s} {agg[k]:5d}   {ex[k][0]}: ...{ex[k][1].strip()[:70]}...')
        # ⚠️ REVIEW is a THIRD tier and it is deliberate. See weld_in_para():
        # this check cannot reach zero false positives from corpus evidence
        # alone, so it must never gate a build. It prints the whole short list
        # instead of a count, because a count you cannot act on is noise.
        print(f'  -- REVIEW: possible intra-paragraph welds ({len(welds)}) --'
              + ('  none' if not welds else ''))
        for fn, tok, split in welds[:15]:
            print(f'    {fn:24s} {tok:18s} -> {split}')
        if len(welds) > 15:
            print(f'    ... and {len(welds)-15} more')
        if near:
            print(f'  -- (suppressed: {len(near)} splits with no bigram evidence) --')
        print('  -- info (expected, not defects) --')
        for k in INFO:
            if k in agg:
                print(f'    {k:20s} {agg[k]:5d}')
    return bad


def selftest():
    """⚠️ Rule 10: the three fixes must produce ZERO on books already shipped
    clean. Before 1.1.0 these same books reported 3,339 mojibake, 17 double-dot
    and 2 double-comma hits, every one of them spurious."""
    here = os.path.dirname(os.path.abspath(__file__))
    # ⚠️ BATCH 25: 'phantom' and 'cc' added - current-batch books, on disk by
    # definition, so at least two cases RUN on a fresh machine. Every other
    # entry here is a sibling-directory book and has SKIPped since batch 22.
    cases = ['../batch17/ba', '../batch17/hb', '../b18/amulet', '../b19/penrod',
             'RANCH', 'BIGHORN', 'phantom', 'cc',
             # ⚠️ BATCH 26: current-batch books, on disk by definition, so these
             # RUN. Every prior reference book is absent from this machine and
             # `pack.sh` correctly REFUSED until these were added. Each batch
             # must add its own; the standing problem is unsolved.
             'PRISTINE/TS', 'PRISTINE/RF', 'PRISTINE/BC']
    ok = True
    ran = 0
    for c in cases:
        root = os.path.normpath(os.path.join(here, c))
        if not os.path.isdir(root):
            print(f'  SKIP {c}')
            continue
        ran += 1
        bad = sweep(root, verbose=False)
        spurious = {k: v for k, v in bad.items()
                    if k in ('mojibake', 'exact-two-dots', 'double-comma')}
        good = not spurious
        ok = ok and good
        print(f'  {"OK  " if good else "FAIL"} {c:20s} '
              f'{"no spurious hits" if good else spurious}'
              + (f'   other defects: {bad}' if bad and good else ''))
    # ⚠️ BATCH 20: an all-SKIP run used to return SUCCESS, so pack.sh
    # printed '3/3 pass' on a machine with no reference books. A selftest
    # that proves nothing must FAIL.
    # ⚠️ 1.2.0 WELD HARNESS. Rule 10: a number becomes authoritative only when a
    # harness exists that FAILS before the fix and PASSES after. These four welds
    # were live in the batch-22 sources and 1.1.0 reported DEFECTS: none on all
    # of them. If a shipped book ever carries one again, this fails.
    # ⚠️ BATCH 23 INLINE-MARKUP HARNESS. Before the plaintext() fix these two
    # Standard Ebooks reported 155 and 311 double-space / space-before-punc
    # DEFECTS and the raw files contain ZERO literal double spaces. A book whose
    # only markup crime is being well marked up must come back clean.
    se_ran = 0
    for book in ('OZMA', 'GOBLIN', 'phantom', 'cc',
                 # batch 26: Gutenberg conversions, sparse markup - these assert
                 # the 23a inline-vs-block fix does not REGRESS on the source
                 # type it was NOT written for.
                 'PRISTINE/TS', 'PRISTINE/RF', 'PRISTINE/BC'):
        root = os.path.normpath(os.path.join(here, book))
        if not os.path.isdir(root):
            print(f'  SKIP inline-markup {book}')
            continue
        se_ran += 1
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            bad = sweep(root, verbose=False)
        phantom = {k: v for k, v in (bad or {}).items()
                   if k in ('double-space', 'space-before-punc')}
        good = not phantom
        ok = ok and good
        print(f'  {"OK  " if good else "FAIL"} inline-markup {book:11s} '
              f'{"no phantom spacing defects" if good else f"REGRESSION: {phantom}"}')

    weld_ran = 0
    for book, gone in (('RANCH', ['fora']),
                       ('BIGHORN', ['chairand', 'agray', 'greenfoot'])):
        root = os.path.normpath(os.path.join(here, book))
        if not os.path.isdir(root):
            print(f'  SKIP weld-harness {book}')
            continue
        weld_ran += 1
        found = [t for _f, t, _s in weld_in_para(files(root))[0] if t in gone]
        good = not found
        ok = ok and good
        print(f'  {"OK  " if good else "FAIL"} weld-harness {book:12s} '
              f'{"batch-22 welds absent" if good else f"REGRESSION: {found}"}')
    if ran == 0 and weld_ran == 0 and se_ran == 0:
        print('\n*** SELFTEST FAILED: 0 cases ran - books absent. ***')
        return False
    print(f'\n{ran + weld_ran + se_ran}/{len(cases) + 4} cases ran')
    print('SELFTEST PASS' if ok else '*** SELFTEST FAILED ***')
    return ok


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        sys.exit(0 if selftest() else 1)
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    fail = False
    for root in sys.argv[1:]:
        if sweep(root):
            fail = True
    sys.exit(1 if fail else 0)
